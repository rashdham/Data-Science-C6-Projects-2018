#TIME SERIES CASE STUDY#
#By:
#1. Harsha Parthasarthy
#2. Rashul Dhamija
#3. Sindhu Bhat
#4. Ujwala Ishwarappagol

###################################################################################################################################
#Libraries Used in Case Study

library(car)
library(MASS)
library(GGally)
library(ggplot2)
library(caTools)
library(forecast)
library(caret)
library(dplyr)
library(tseries)
require(graphics)
library(stats)

###################################################################################################################################

#-------------------------------1. BUSINESS UNDERSTANDING ------------------------------#
#"Global Mart" is an online store super giant having worldwide operations.
#It takes orders & delivers across the globe, deals with all the major product categories - consumer, corporate & home office.
#The store caters to 7 different market segments and in 3 major categories(so data would be subset into 7*3=21 buckets).
#Not all of these 21 market buckets are important from the store's point of view.

#WHAT OUTPUT IS EXPECTED?
#Want to forecast the sales and demand for the next 6 months, that would help manage the revenue and inventory accordingly.
#Find out 2 most profitable (and consistent) segment from the 21 buckets and forecast the sales and demand for these segments.

#-------------------------------2. DATA UNDERSTANDING ------------------------------#

#First we will load the data into the R enviounment and name it Gstore

Gstore <- read.csv("Global Superstore.csv",stringsAsFactors = F)

# View the dataset
View(Gstore)

#There are 51290 observations in the dataset
#We have 24 variables related to each transaction
#The data currently has the transaction level data, where each row represents a particular order made online


# View the structure of the dataset.
str(Gstore)
# It is the combination of character and continous variables. 17 character variable and 7 continous variable


#Factorise the market column to understand the levels
Gstore$Market <- as.factor(Gstore$Market)

#verify the levels of markets
#The "Market" attribute has 7-factor levels representing the geographical market sector that the customer belongs to:
levels(Gstore$Market)

#1. Africa
#2. APAC
#3. Canada
#4. EMEA
#5. EU
#6. LATAM
#7. US

#Similarly factorise the segment column to understand the levels
Gstore$Segment <- as.factor(Gstore$Segment)

#verify the levels of segment
#The "Segment" attribute tells which of the 3 segments that customer belongs to:
levels(Gstore$Segment)

#1. Consumer
#2. Corporate
#3. Home Office

#-------------------------------3. DATA PREPARATION/CLEANING ------------------------------#
# Correcting the Column names
colnames(Gstore)[1] <- "RowID" 
colnames(Gstore)[2] <- "OrderID"
colnames(Gstore)[3] <- "OrderDate"
colnames(Gstore)[4] <- "ShipDate"
colnames(Gstore)[5] <- "ShipMode"
colnames(Gstore)[6] <- "CustomerID"
colnames(Gstore)[7] <- "CustomerName"
colnames(Gstore)[12] <- "PostalCode"
colnames(Gstore)[15] <- "ProductID"
colnames(Gstore)[17] <- "SubCategory"
colnames(Gstore)[18] <- "ProductName"
colnames(Gstore)[23] <- "ShippingCost"
colnames(Gstore)[24] <- "OrderPriority"
View(Gstore)

# check the NA values in the data sets
sapply(Gstore, function(x) sum(is.na(x)))

#Postal code has 41296 NA values.It is a unique identifier of district and even being an integer will not be used in any calculation.
#we will replace the NA it with 0.It is observed that postal code is not available for non-USA addresses

Gstore[which(is.na(Gstore$PostalCode)),12] <- 0

sum(is.na(Gstore))

View(Gstore)

#Check for duplicates
x <- unique(Gstore)
View(x)

# No duplicate rows found in the data


#Change the date type and order the data before creating the segments

#Update the Date type(Converting dates into standard format of %d-%m-%Y)
Gstore$OrderDate <- as.Date(Gstore$OrderDate, "%d-%m-%Y")
Gstore$ShipDate <- as.Date(Gstore$ShipDate, "%d-%m-%Y")

#Order the data based on Order Date.
Gstore <- Gstore[with(Gstore,order(OrderDate)),]
View(Gstore)


write.csv(Gstore, "Gstore.csv")

#Thus, we would need to aggregate the 3 attributes over the Order Date to arrive at monthly values for these attributes:
#i.e. Sales, Quantity & Profit


#-------------------------------4. EXPLORATORY DATA ANALYSIS  ------------------------------#
# Finding TotalProfit, AvgSalesAmount, TotalSalesAmount, NumOfSales on Market and Segment

TP<-aggregate(Gstore$Profit, by=list(Gstore$Market,Gstore$Segment), FUN=sum)
names(TP)<-list("Market","Segment","TotalProfit")

AS<-aggregate(Gstore$Sales, by=list(Gstore$Market,Gstore$Segment), FUN=mean)
names(AS)<-list("Market","Segment","AvgSalesAmount")

TS<-aggregate(Gstore$Sales, by=list(Gstore$Market,Gstore$Segment), FUN=sum)
names(TS)<-list("Market","Segment","TotalSalesAmount")

NS<-aggregate(Gstore$Quantity, by=list(Gstore$Market,Gstore$Segment), FUN=length)
names(NS)<-list("Market","Segment","NumOfSales")

Sales_Summary<-data.frame(TP,AS,TS,NS)
Sales_Summary<-Sales_Summary[,c(1,2,3,6,9,12)]
View(Sales_Summary)

# Adding Profit as a percentage of Sales amount to the dataframe
Sales_Summary$PPercent<-round((Sales_Summary$TotalProfit/Sales_Summary$TotalSalesAmount)*100,digit=2)
View(Sales_Summary)


# Analysis of TotalMonthlyProfit, AvgMonthlySales, TotalMonthlySales, NoOfMonthlySales on Market, Segment, Month and Year
#for each of the segment

MQ<-aggregate(Gstore$Quantity, by=list(Gstore$Market,Gstore$Segment,format(as.Date(Gstore$OrderDate), "%Y%m")), FUN=sum)
names(MQ)<-list("Market","Segment","Month","TotalMonthlyQty")

MP<-aggregate(Gstore$Profit, by=list(Gstore$Market,Gstore$Segment,format(as.Date(Gstore$OrderDate), "%Y%m")), FUN=mean)
names(MP)<-list("Market","Segment","Month","TotalMonthlyProfit")

AVGMS<-aggregate(Gstore$Sales, by=list(Gstore$Market,Gstore$Segment,format(as.Date(Gstore$OrderDate), "%Y%m")), FUN=mean)
names(AVGMS)<-list("Market","Segment","Month","AvgMonthlySales")

MS<-aggregate(Gstore$Sales, by=list(Gstore$Market,Gstore$Segment,format(as.Date(Gstore$OrderDate), "%Y%m")), FUN=sum)
names(MS)<-list("Market","Segment","Month","TotalMonthlySales")

QuanMS<-aggregate(Gstore$Quantity, by=list(Gstore$Market,Gstore$Segment,format(as.Date(Gstore$OrderDate), "%Y%m")), FUN=length)
names(QuanMS)<-list("Market","Segment","Month","NoOfMonthlySales")

Monthly_Summary<-data.frame(MQ,MP,AVGMS,MS,QuanMS)

Monthly_Summary<-Monthly_Summary[,c(1,2,3,4,8,12,16,20)]
View(Monthly_Summary)

# Add Monthly profit as a percentage of monthly sales
Monthly_Summary$MonthlyPPercent<-round((Monthly_Summary$TotalMonthlyProfit/Monthly_Summary$TotalMonthlySales)*100,digit=2)

Monthly_Summary<-Monthly_Summary[order(Monthly_Summary$TotalMonthlySales,decreasing=TRUE),]
View(Monthly_Summary)

write.csv(Monthly_Summary, "monthsummary.csv")

# Finding standard deviation of monthly profit percentage across Market and Segment to calculate the coeeficient variation
AvgMPPercent<-aggregate(Monthly_Summary$MonthlyPPercent, by=list(Monthly_Summary$Market,Monthly_Summary$Segment), FUN=mean)
names(AvgMPPercent)<-list("Market","Segment","AvgMonthlyProfitPercent")
View(AvgMPPercent)

MPPStD<-aggregate(Monthly_Summary$MonthlyPPercent, by=list(Monthly_Summary$Market,Monthly_Summary$Segment), FUN=sd)
names(MPPStD)<-list("Market","Segment","MonthlyProfitPercentSD")
View(MPPStD)

# Adding SD of monthly profit percentage to the Sales_Summary
Sales_Summary<-data.frame(Sales_Summary,AvgMPPercent,MPPStD)
Sales_Summary<-Sales_Summary[,-c(8,9,11,12)]
Sales_Summary$CVMonthlyProfitPercent<-round(Sales_Summary$MonthlyProfitPercentSD/Sales_Summary$AvgMonthlyProfitPercent, digit = 2)

# Order on Total profit to find the most profitable and consistent Market Segment 

Sales_Summary<-Sales_Summary[order(Sales_Summary$TotalProfit,decreasing=TRUE),]
View(Sales_Summary)

write.csv(Sales_Summary, "SalesSummary.csv")

#-------------------------------5. PLOTS FOR BETTER UNDERSTANDING ------------------------------#

# Plotting Market Segment against Total Profit

# Market and Segment generating most profit
plot1<-ggplot(Sales_Summary,aes(x=Sales_Summary$Market,y=Sales_Summary$TotalProfit,fill=Sales_Summary$Segment))
plot1+geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("Profit")+ggtitle("Total Profit")

# Plotting Market Segment against Total Sales

plot2<-ggplot(Sales_Summary,aes(x=Sales_Summary$Market,y=Sales_Summary$TotalSalesAmount,fill=Sales_Summary$Segment))
plot2+geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("Sales")+ggtitle("Total Sales")

# Plotting Market Segment against Quantity

plot3<-ggplot(Sales_Summary,aes(x=Sales_Summary$Market,y=Sales_Summary$NumOfSales,fill=Sales_Summary$Segment))
plot3+geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("Quantity")+ggtitle("Total Quantity")

# Market and Segment having most profit margin
plot4<-ggplot(Sales_Summary,aes(x=Sales_Summary$Market,y=Sales_Summary$PPercent,fill=Sales_Summary$Segment))
plot4+geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("Profit %age")+ggtitle("Profit percent")

# Market and Segment having most profit margin based on CV
plot5<-ggplot(Sales_Summary,aes(x=Sales_Summary$Market,y=Sales_Summary$CVMonthlyProfitPercent,fill=Sales_Summary$Segment))
plot5<-plot5+geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("Coeff. of variance of monthly profit")
plot5+ggtitle("Coeff. of variance in monthly profit Vs. Market Segment")

#INFERENCE: Based on the understanding from the plots of Coefficient of Variation, 2 most consistently profitable segments are:
#1. Corporate
      #APAC
      #EU  
#2. Consumer
      #APAC
      #LATAM
      #EU

#ASSUMPTIONS:Since there is no business benchmark set for Coefficient of Variation as to what are the permissible ranges
#to be considered,we assume that CoV < 15-16% is good to go for further analysis(lesser the CoV, better the results)
#We now need to create subsets of market segments based on 7 markets across 2 segments

###################################################################################################################################
#Creating Subsets

#####APAC#####
APAC_ConSales<-subset(Monthly_Summary,(Monthly_Summary$Market == "APAC" & Monthly_Summary$Segment == "Consumer"))
APAC_ConSales<-APAC_ConSales[order(APAC_ConSales$Month),]
APAC_ConSales$MonthNum<-c(1:nrow(APAC_ConSales))
View(APAC_ConSales)

APAC_CorSales<-subset(Monthly_Summary,(Monthly_Summary$Market == "APAC" & Monthly_Summary$Segment == "Corporate"))
APAC_CorSales<-APAC_CorSales[order(APAC_CorSales$Month),]
APAC_CorSales$MonthNum<-c(1:nrow(APAC_CorSales))
View(APAC_CorSales)


#####EU#####
EU_ConSales<-subset(Monthly_Summary,(Monthly_Summary$Market == "EU" & Monthly_Summary$Segment == "Consumer"))
EU_ConSales<-EU_ConSales[order(EU_ConSales$Month),]
EU_ConSales$MonthNum<-c(1:nrow(EU_ConSales))
View(EU_ConSales)

EU_CorSales<-subset(Monthly_Summary,(Monthly_Summary$Market == "EU" & Monthly_Summary$Segment == "Corporate"))
EU_CorSales<-EU_CorSales[order(EU_CorSales$Month),]
EU_CorSales$MonthNum<-c(1:nrow(EU_CorSales))
View(EU_CorSales)

#####LATAM#####
Lat_ConSales<-subset(Monthly_Summary,(Monthly_Summary$Market == "LATAM" & Monthly_Summary$Segment == "Consumer"))
Lat_ConSales<-Lat_ConSales[order(Lat_ConSales$Month),]
Lat_ConSales$MonthNum<-c(1:nrow(Lat_ConSales))
View(Lat_ConSales)

###############################################################################################################################

#-------------------------------6. MODEL BUILDING ------------------------------#
#Technique used Classical decomposition and ARIMA for 2 most profitable segments across markets

# Model based on Sales for selected segment

#*************************************************
############APAC_Consumer############
#*************************************************

nrow(APAC_ConSales)
#48

#Let's create the model using the first 42 rows.
#Then we can test the model on the remaining 6 rows later

total_timeser <- ts(APAC_ConSales$AvgMonthlySales)
indata <- APAC_ConSales[1:42,]
View(indata)
timeser <- ts(indata$AvgMonthlySales)
plot(timeser)

# Decompose timeseries to see the components
# Added frequency = 12 because decomposition can't happen with frequency = 1
APAC.Consumer.sales.timeser.d<-ts(timeser,frequency=12)
APAC.Consumer.sales.timeser.d <- decompose(APAC.Consumer.sales.timeser.d)
plot(APAC.Consumer.sales.timeser.d)


#Smoothing the series - Moving Average Smoothing
w <-1
smoothedseries <- stats::filter(timeser, filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)

#Smoothing left end of the time series
diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series
n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

View(smoothedseries)

#Plot the smoothed time series
timevals_in <- indata$MonthNum
View(timevals_in)
lines(smoothedseries, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')
View(smootheddf)

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)

adf.test(resi,alternative = "stationary")
kpss.test(resi)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- APAC_ConSales[43:48,]
View(outdata)
timevals_out <- outdata$MonthNum
global_pred_out <- predict(lmfit,Month=timevals_out)
summary(global_pred_out)


fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE


MAPE_class_dec <- accuracy(fcast,outdata[,6])[5]
MAPE_class_dec

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,6])[5]
MAPE_auto_arima

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")


#########End of Analysis for APAC Consumer Segment###########

#*************************************************
############APAC_Corporate############
#*************************************************

nrow(APAC_CorSales)
#48

#Let's create the model using the first 42 rows.
#Then we can test the model on the remaining 6 rows later

total_timeser <- ts(APAC_CorSales$AvgMonthlySales)
indata <- APAC_CorSales[1:42,]
View(indata)
timeser <- ts(indata$AvgMonthlySales)
plot(timeser)

# Decompose timeseries to see the components
# Added frequency = 12 because decomposition can't happen with frequency = 1
APAC.Corporate.sales.timeser.d<-ts(timeser,frequency=12)
APAC.Corporate.sales.timeser.d <- decompose(APAC.Corporate.sales.timeser.d)
plot(APAC.Corporate.sales.timeser.d)

#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries <- stats::filter(timeser, filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

View(smoothedseries)

#Plot the smoothed time series
timevals_in <- indata$MonthNum
View(timevals_in)
lines(smoothedseries, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')
View(smootheddf)

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)

adf.test(resi,alternative = "stationary")
kpss.test(resi)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- APAC_CorSales[43:48,]
View(outdata)
timevals_out <- outdata$MonthNum
global_pred_out <- predict(lmfit,Month=timevals_out)
summary(global_pred_out)


fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE


MAPE_class_dec <- accuracy(fcast,outdata[,6])[5]
MAPE_class_dec

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,6])[5]
MAPE_auto_arima

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")


#########End of Analysis for APAC Corporate Segment###########


#*************************************************
##############EU_Consumer############
#*************************************************

nrow(EU_ConSales)
#48

#Let's create the model using the first 42 rows.
#Then we can test the model on the remaining 6 rows later

total_timeser <- ts(EU_ConSales$AvgMonthlySales)
indata <- EU_ConSales[1:42,]
View(indata)
timeser <- ts(indata$AvgMonthlySales)
plot(timeser)



#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries <- stats::filter(timeser, filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

View(smoothedseries)

#Plot the smoothed time series
timevals_in <- indata$MonthNum
View(timevals_in)
lines(smoothedseries, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')
View(smootheddf)

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)

adf.test(resi,alternative = "stationary")
kpss.test(resi)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- EU_ConSales[43:48,]
View(outdata)
timevals_out <- outdata$MonthNum
global_pred_out <- predict(lmfit,Month=timevals_out)
summary(global_pred_out)


fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE


MAPE_class_dec <- accuracy(fcast,outdata[,6])[5]
MAPE_class_dec

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,6])[5]
MAPE_auto_arima

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")

#########End of Analysis for EU Consumer Segment###########

#*************************************************
##########EU_Corporate############
#*************************************************

nrow(EU_CorSales)
#48

#Let's create the model using the first 42 rows.
#Then we can test the model on the remaining 6 rows later

total_timeser <- ts(EU_CorSales$AvgMonthlySales)
indata <- EU_CorSales[1:42,]
View(indata)
timeser <- ts(indata$AvgMonthlySales)
plot(timeser)



#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries <- stats::filter(timeser, filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

View(smoothedseries)

#Plot the smoothed time series
timevals_in <- indata$MonthNum
View(timevals_in)
lines(smoothedseries, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')
View(smootheddf)

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)

adf.test(resi,alternative = "stationary")
kpss.test(resi)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- EU_CorSales[43:48,]
View(outdata)
timevals_out <- outdata$MonthNum
global_pred_out <- predict(lmfit,Month=timevals_out)
summary(global_pred_out)


fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE


MAPE_class_dec <- accuracy(fcast,outdata[,6])[5]
MAPE_class_dec

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,6])[5]
MAPE_auto_arima

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")

#########End of Analysis for EU Corporate Segment###########

#*************************************************
###########Latam_Consumer############
#*************************************************

nrow(Lat_ConSales)
#48

#Let's create the model using the first 42 rows.
#Then we can test the model on the remaining 6 rows later

total_timeser <- ts(Lat_ConSales$AvgMonthlySales)
indata <- Lat_ConSales[1:42,]
View(indata)
timeser <- ts(indata$AvgMonthlySales)
plot(timeser)



#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries <- stats::filter(timeser, filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

View(smoothedseries)

#Plot the smoothed time series
timevals_in <- indata$MonthNum
View(timevals_in)
lines(smoothedseries, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')
View(smootheddf)

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)

adf.test(resi,alternative = "stationary")
kpss.test(resi)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- Lat_ConSales[43:48,]
View(outdata)
timevals_out <- outdata$MonthNum
global_pred_out <- predict(lmfit,Month=timevals_out)
summary(global_pred_out)


fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE


MAPE_class_dec <- accuracy(fcast,outdata[,6])[5]
MAPE_class_dec

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,6])[5]
MAPE_auto_arima

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")

#########End of Analysis for Latam Consumer Segment###########

#**************************************************
#**************************************************

# Model based on Quantity for selected segment

#*************************************************
############APAC_Consumer############
#*************************************************

nrow(APAC_ConSales)
#48

#Let's create the model using the first 42 rows.
#Then we can test the model on the remaining 6 rows later

total_timeser <- ts(APAC_ConSales$TotalMonthlyQty)
indata <- APAC_ConSales[1:42,]
View(indata)
timeser <- ts(indata$TotalMonthlyQty)
plot(timeser)

# Decompose timeseries to see the components
# Added frequency = 12 because decomposition can't happen with frequency = 1
APAC.Consumer.sales.timeser.d<-ts(timeser,frequency=12)
APAC.Consumer.sales.timeser.d <- decompose(APAC.Consumer.sales.timeser.d)
plot(APAC.Consumer.sales.timeser.d)

#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries <- stats::filter(timeser, filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

View(smoothedseries)

#Plot the smoothed time series
timevals_in <- indata$MonthNum
View(timevals_in)
lines(smoothedseries, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')
View(smootheddf)

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)

adf.test(resi,alternative = "stationary")
kpss.test(resi)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- APAC_ConSales[43:48,]
View(outdata)
timevals_out <- outdata$MonthNum
global_pred_out <- predict(lmfit,Month=timevals_out)
summary(global_pred_out)


fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE


MAPE_class_dec <- accuracy(fcast,outdata[,4])[5]
MAPE_class_dec

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,4])[5]
MAPE_auto_arima

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")


#########End of Analysis for APAC Consumer Segment###########

#*************************************************
#############APAC_Corporate############
#*************************************************

nrow(APAC_CorSales)
#48

#Let's create the model using the first 42 rows.
#Then we can test the model on the remaining 6 rows later

total_timeser <- ts(APAC_CorSales$TotalMonthlyQty)
indata <- APAC_CorSales[1:42,]
View(indata)
timeser <- ts(indata$TotalMonthlyQty)
plot(timeser)

# Decompose timeseries to see the components
# Added frequency = 12 because decomposition can't happen with frequency = 1
APAC.Corporate.sales.timeser.d<-ts(timeser,frequency=12)
APAC.Corporate.sales.timeser.d <- decompose(APAC.Corporate.sales.timeser.d)
plot(APAC.Corporate.sales.timeser.d)

#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries <- stats::filter(timeser, filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

View(smoothedseries)

#Plot the smoothed time series
timevals_in <- indata$MonthNum
View(timevals_in)
lines(smoothedseries, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')
View(smootheddf)

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)

adf.test(resi,alternative = "stationary")
kpss.test(resi)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- APAC_CorSales[43:48,]
View(outdata)
timevals_out <- outdata$MonthNum
global_pred_out <- predict(lmfit,Month=timevals_out)
summary(global_pred_out)


fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE


MAPE_class_dec <- accuracy(fcast,outdata[,4])[5]
MAPE_class_dec

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,4])[5]
MAPE_auto_arima

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")


#########End of Analysis for APAC Corporate Segment###########


#*************************************************
###########EU_Consumer############
#*************************************************

nrow(EU_ConSales)
#48

#Let's create the model using the first 42 rows.
#Then we can test the model on the remaining 6 rows later

total_timeser <- ts(EU_ConSales$TotalMonthlyQty)
indata <- EU_ConSales[1:42,]
View(indata)
timeser <- ts(indata$TotalMonthlyQty)
plot(timeser)

# Decompose timeseries to see the components
# Added frequency = 12 because decomposition can't happen with frequency = 1
#EU.Consumer.sales.timeser.d<-ts(timeser,frequency=12)
#EU.Consumer.timeser.d <- decompose(EU.Consumer.sales.timeser.d)
#plot(EU.Consumer.sales.timeser.d)

#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries <- stats::filter(timeser, filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

View(smoothedseries)

#Plot the smoothed time series
timevals_in <- indata$MonthNum
View(timevals_in)
lines(smoothedseries, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')
View(smootheddf)

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)

adf.test(resi,alternative = "stationary")
kpss.test(resi)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- EU_ConSales[43:48,]
View(outdata)
timevals_out <- outdata$MonthNum
global_pred_out <- predict(lmfit,Month=timevals_out)
summary(global_pred_out)


fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE


MAPE_class_dec <- accuracy(fcast,outdata[,4])[5]
MAPE_class_dec

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,4])[5]
MAPE_auto_arima

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")

#########End of Analysis for EU Consumer Segment###########

#*************************************************
#########EU_Corporate############
#*************************************************

nrow(EU_CorSales)
#48

#Let's create the model using the first 42 rows.
#Then we can test the model on the remaining 6 rows later

total_timeser <- ts(EU_CorSales$TotalMonthlyQty)
indata <- EU_CorSales[1:42,]
View(indata)
timeser <- ts(indata$TotalMonthlyQty)
plot(timeser)

# Decompose timeseries to see the components
# Added frequency = 12 because decomposition can't happen with frequency = 1
#EU.Corporate.sales.timeser.d<-ts(timeser,frequency=12)
#EU.Corporate.timeser.d <- decompose(EU.Corporate.sales.timeser.d)
#plot(EU.Corporate.sales.timeser.d)

#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries <- stats::filter(timeser, filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

View(smoothedseries)

#Plot the smoothed time series
timevals_in <- indata$MonthNum
View(timevals_in)
lines(smoothedseries, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')
View(smootheddf)

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)

adf.test(resi,alternative = "stationary")
kpss.test(resi)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- EU_CorSales[43:48,]
View(outdata)
timevals_out <- outdata$MonthNum
global_pred_out <- predict(lmfit,Month=timevals_out)
summary(global_pred_out)


fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE


MAPE_class_dec <- accuracy(fcast,outdata[,4])[5]
MAPE_class_dec

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,4])[5]
MAPE_auto_arima

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")

#########End of Analysis for EU Corporate Segment###########

#*************************************************
##########Latam_Consumer############
#*************************************************

nrow(Lat_ConSales)
#48

#Let's create the model using the first 42 rows.
#Then we can test the model on the remaining 6 rows later

total_timeser <- ts(Lat_ConSales$TotalMonthlyQty)
indata <- Lat_ConSales[1:42,]
View(indata)
timeser <- ts(indata$TotalMonthlyQty)
plot(timeser)

# Decompose timeseries to see the components
# Added frequency = 12 because decomposition can't happen with frequency = 1
#Lat.Consumer.sales.timeser.d<-ts(timeser,frequency=12)
#Lat.Consumer.timeser.d <- decompose(Lat.Consumer.sales.timeser.d)
#plot(Lat.Consumer.sales.timeser.d)

#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries <- stats::filter(timeser, filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

View(smoothedseries)

#Plot the smoothed time series
timevals_in <- indata$MonthNum
View(timevals_in)
lines(smoothedseries, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')
View(smootheddf)

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)

adf.test(resi,alternative = "stationary")
kpss.test(resi)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- Lat_ConSales[43:48,]
View(outdata)
timevals_out <- outdata$MonthNum
global_pred_out <- predict(lmfit,Month=timevals_out)
summary(global_pred_out)


fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE


MAPE_class_dec <- accuracy(fcast,outdata[,4])[5]
MAPE_class_dec

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,4])[5]
MAPE_auto_arima

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")

#########End of Analysis for Latam Consumer Segment###########

################################################################################################################################
#-------------------------------7. CONCLUSION ------------------------------#

#Most profitable and consistent market segments are:
#APAC-Consumer
#EU-Consumer
#APAC Corporate
#EU Corporate
#For all further inferences and forecasts, kindly go through the detailed presentation attached with the R file.