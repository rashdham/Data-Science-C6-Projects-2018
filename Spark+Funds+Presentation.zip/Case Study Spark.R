library(dplyr)
library(tidyr)
library(stringr)
library(stringi)
library(compare)
library(data.table)

#Checkpoint 1
companies <- read.delim("companies.txt", header = TRUE, sep = "\t", stringsAsFactors = FALSE)
rounds2 <- read.csv("rounds2.csv", stringsAsFactors = FALSE)
str(companies)
str(rounds2)

# renamed the colname in rounds2 to make it same as companies column name
names(rounds2)[names(rounds2) == "company_permalink"] <- "permalink"
View(rounds2)

# changing the common column values to lower case
companies$permalink <- tolower(companies$permalink)
rounds2$permalink <- tolower(rounds2$permalink)
View(companies)
View(rounds2)

#Table-1.1 Checkpoint1 - Data Cleaning 1
#Understand the Data Set

# 1. How many unique companies are present in rounds2?
unique_inrounds2 <- n_distinct(rounds2$permalink)
View(unique_inrounds2)


#2. How many unique companies are present in the companies file?
unique_incompanies2 <- n_distinct(companies$permalink)
View(unique_incompanies2)

#3 In the companies data frame, which column can be used as the unique key for each company? 
#Write the name of the column.

#permalink

#4 Are there any companies in the rounds2 file which are not present in companies ? Answer Y/N.

comparison <- compare(rounds2, companies, allowAll = TRUE)
View(comparison)
# No


#Merge the two data frames so that all variables (columns) in the companies dataframe are added to the rounds2 data frame.
#Name the merged frame master_frame.How many observations are present in master_frame ? 

master_frame<- merge(rounds2, companies, by = "permalink")
master_frame$raised_amount_usd[is.na(master_frame$raised_amount_usd)] <- 0
View(master_frame)

#export the merge filed as this needs to be used henceforth
write.table(master_frame,"mf.txt", row.names = FALSE, sep ="\t")




#Table-2.1	Checkpoint 2 - Funding Type Analysis
#Average Values of Investments for Each of these Funding Types		


#1.Average funding amount of venture type
mf_venture <- summarise(filter(master_frame, funding_round_type == "venture"), avg_fund_raise = mean(raised_amount_usd, na.rm = TRUE))
View(mf_venture)

#2. Average funding amount of angel type
mf_angel <- summarise(filter(master_frame, funding_round_type == "angel"), avg_fund_raise = mean(raised_amount_usd, na.rm = TRUE))
View(mf_angel)

#3. Average funding amount of seed type
mf_seed <- summarise(filter(master_frame, funding_round_type == "seed"), avg_fund_raise = mean(raised_amount_usd, na.rm = TRUE))
View(mf_seed)

#4. Average funding amount of private equity type
mf_pe <- summarise(filter(master_frame, funding_round_type == "private_equity"), avg_fund_raise = mean(raised_amount_usd, na.rm = TRUE))
View(mf_pe)

#5.Considering that Spark Funds wants to invest between 5 to 15 million USD per investment round, which investment type is the most suitable for them?
invest<- data.frame(mf_venture,mf_angel,mf_seed,mf_pe)
colnames(invest) <- c("avg_venture","avg_angel","avg_seed","avg_pe")
View(invest)

# The best suited investment type is venture


#Table -  3.1 Checkpoint3 - Country Analysis

#Analysing the Top 3 English-Speaking Countries
#All codes for data frame top9 across ALL sectors for the chosen investment type

mf_ven_subset<- subset(master_frame, master_frame$funding_round_type == "venture")
View(mf_ven_subset)

top9 <- group_by(mf_ven_subset, country_code)  
top9 <- arrange(summarise(top9, invest = sum (raised_amount_usd)),desc(invest))
View(top9)

# removed the investment with blank country code
top9 <- top9[!(top9$country_code == ""),]
top9 <- head(top9,9)
View(top9)

write.table(top9, "top9.txt", row.names = FALSE, sep ="\t")

# 1.Top English speaking country
#USA
# 2.Second English speaking country
#GBR
# 3.Third English speaking country
#IND


#Checkpoint 4: Sector Analysis 1

map_sector <- read.csv("mapping.csv", stringsAsFactors = FALSE)
View(map_sector)

# replace 0 with na in the category list of column of mappring file
map_sector$category_list <- str_replace_all(map_sector$category_list, "0", "Na")
View(map_sector)

# converted the data from wide to narrow format
map_sector <- gather(map_sector, main_sector, my_val, 2:10)
View(map_sector)


# delimited the categopry list to seperate the primary sector for preferred funded type "venture"
psector_incompanies <- str_split_fixed(master_frame$category_list,pattern = "\\|", n = Inf)
View(psector_incompanies)


# combined the preferred funded type subset frame with the delimited category list
new_mf <- cbind(master_frame, psector_incompanies)
View(new_mf)


#removed the unwanted columns in master frame
new_mf <- select(new_mf, -category_list)
View(new_mf)

# renamed the colname in master frame 
names(new_mf)[names(new_mf) == "1"] <- "category_list"
View(new_mf)

# selecting only the required column with premary and main sector
new_mf<- new_mf %>% dplyr::select(permalink:category_list)
View(new_mf)

# change category list to lower case in master and mapping file
map_sector$category_list <- tolower(map_sector$category_list)
View(map_sector)
new_mf$category_list <- tolower(new_mf$category_list)
View(map_sector)

#merged the gather data from mapping file with master_list to map the main sector
new_mf <- merge(new_mf,map_sector, by = "category_list" )
View(new_mf)

#removed the unwanted rows for each compnies which is not a main sector 
new_mf <- new_mf[!(new_mf$my_val == 0),]
View(new_mf)

# removed the blanks sector which is not the part of 8 main sector
new_mf <- new_mf[!(new_mf$main_sector == "Blanks"),]
View(new_mf)


#exported the final cleaned file for reference
write.table(new_mf, "new_mf_inf.txt", row.names = FALSE , sep = "\t")


# Checkpoint 5: Sector Analysis 2

#Create three separate data frames D1, D2 and D3 

#filter the entries between the range of 5000000 and 15000000
new_mf <- filter(new_mf,new_mf$raised_amount_usd >= 5000000 & new_mf$raised_amount_usd <= 15000000)


# Top english speaking country with choosen FT between the range and na values removed
new_mf <- filter(new_mf,new_mf$funding_round_type == "venture")
View(new_mf)

#exported the final cleaned file for reference
write.table(new_mf, "new_mf_venture.txt", row.names = FALSE , sep = "\t")


# Dataframe for the top english speaking country grouped by main sector for total number and amount of investment
eng_top_country <- new_mf[(new_mf$country_code == "USA"),]
eng_top_country <- group_by(eng_top_country, main_sector)
D1 <- arrange(summarise(eng_top_country, t_count_ms = sum(my_val), t_amt_invested = sum(raised_amount_usd)), desc(t_count_ms))
View(eng_top_country)
View(D1)


#exported the table for reference
write.table(eng_top_country, "etop.txt", row.names = FALSE , sep = "\t")
write.table(D1, "D1.txt", row.names = FALSE , sep = "\t")

#For point 3 (top sector count-wise), which company received the highest investment for Others sector
eng_top_sector <- eng_top_country[(eng_top_country$main_sector == "Others"),]
eng_top_grp <- group_by(eng_top_sector, name)
eng_top_agg <- arrange(summarise(eng_top_grp, t_amt_invested = sum(raised_amount_usd)), desc(t_amt_invested))
View(eng_top_agg)

# Find the company with highest investment for top sector
tc_company_other_sector <- eng_top_agg$name[which.max(eng_top_agg$t_amt_invested)]
View(tc_company_other_sector)


#For point 4 (second best sector count-wise), which company received the highest investment for SFAA sector
eng_second_sector <- eng_top_country[(eng_top_country$main_sector == "Social.Finance.Analytics.Advertising"),]
eng_second_grp <- group_by(eng_second_sector, name)
eng_second_grp <- arrange(summarise(eng_second_grp, t_amt_invested = sum(raised_amount_usd)), desc(t_amt_invested))
View(eng_second_grp)

# Find the company with highest investment for second sector
tc_company_SFAA_sector <- eng_second_grp$name[which.max(eng_second_grp$t_amt_invested)]
View(tc_company_SFAA_sector)


# second english speaking country with FT between the range and na values removed
# Dataframe for the second english speaking country grouped by main sector for total number and amount of investment
eng_second_country <- new_mf[(new_mf$country_code == "GBR"),] 
eng_second_country <- group_by(eng_second_country, main_sector)
D2 <- arrange(summarise(eng_second_country, t_count_ms = sum(my_val), t_amt_invested = sum(raised_amount_usd)), desc(t_count_ms))
View(eng_second_country)
View(D2)

#exported the table for reference
write.table(eng_second_country, "esecond.txt", row.names = FALSE , sep = "\t")
write.table(D2, "D2.txt", row.names = FALSE , sep = "\t")



#For point 3 (top sector count-wise), which company received the highest investment for Others sector
eng_top_sector <- eng_second_country[(eng_second_country$main_sector == "Others"),]
eng_top_grp <- group_by(eng_top_sector, name)
eng_top_agg <- arrange(summarise(eng_top_grp, t_amt_invested = sum(raised_amount_usd)), desc(t_amt_invested))
View(eng_top_agg)

# Find the company with highest investment for top sector
sc_company_other_sector <- eng_top_agg$name[which.max(eng_top_agg$t_amt_invested)]
View(sc_company_other_sector)


#For point 4 (top sector count-wise), which company received the highest investment for SFAA sector
eng_second_sector <- eng_second_country[(eng_second_country$main_sector == "Social.Finance.Analytics.Advertising"),]
eng_second_grp <- group_by(eng_second_sector, name)
eng_second_grp <- arrange(summarise(eng_second_grp,  t_amt_invested = sum(raised_amount_usd)), desc(t_amt_invested))
View(eng_second_grp)

# Find the company with highest investment for second sector
sc_company_SFAA_sector <- eng_second_grp$name[which.max(eng_second_grp$t_amt_invested)]
View(sc_company_SFAA_sector)


# third english speaking country with FT between the range and na values removed
# Dataframe for the third english speaking country grouped by main sector for total number and amount of investment
eng_third_country <- new_mf[(new_mf$country_code == "IND"),] 
eng_third_country <- group_by(eng_third_country, main_sector)
D3 <- arrange(summarise(eng_third_country, t_count_ms = sum(my_val), t_amt_invested = sum(raised_amount_usd)), desc(t_count_ms))
View(eng_third_country)
View(D3)

#exported the table for reference
write.table(eng_third_country, "ethird.txt", row.names = FALSE , sep = "\t")
write.table(D3, "D3.txt", row.names = FALSE , sep = "\t")

#For point 3 (top sector count-wise), which company received the highest investment for Others sector
eng_top_sector <- eng_third_country[(eng_third_country$main_sector == "Others"),]
eng_top_grp <- group_by(eng_top_sector, name)
eng_top_agg <- arrange(summarise(eng_top_grp, t_amt_invested = sum(raised_amount_usd)),desc(t_amt_invested))
View(eng_top_agg)

# Find the company with highest investment for top sector
thc_company_other_sector <- eng_top_agg$name[which.max(eng_top_agg$t_amt_invested)]
View(thc_company_other_sector)


#For point 4 (top sector count-wise), which company received the highest investment for SFAA sector
eng_second_sector <- eng_third_country[(eng_third_country$main_sector == "Social.Finance.Analytics.Advertising"),]
eng_second_grp <- group_by(eng_second_sector, name)
eng_second_grp <- arrange(summarise(eng_second_grp,  t_amt_invested = sum(raised_amount_usd)), desc(t_amt_invested))
View(eng_second_grp)

# Find the company with highest investment for second sector
thc_company_SFAA_sector <- eng_second_grp$name[which.max(eng_second_grp$t_amt_invested)]
View(thc_company_SFAA_sector)

