##################################### BUSINESS UNDERSTANDING ###############################################
#1. ElecKart is an e-commerce firm specialising in electronic products. 
#2. Over the last one year, they had spent a significant amount of money in marketing. 
#3. Occasionally, they had also offered big-ticket promotions (similar to the Big Billion Day). 
#4. They are about to create a marketing budget for the next year which includes spending on commercials, 
#   online campaigns, and pricing & promotion strategies. 
#5. The CFO feels that the money spent over last 12 months on marketing was not sufficiently impactful 
#6. They can either cut on the budget or reallocate it optimally across marketing levers to improve the revenue response.
#7. Need to develop a market mix model to observe the actual impact of different marketing variables over the last year
#8. We have to recommend the optimal budget allocation for different marketing levers for the next year

#################################### DATA UNDERSTANDING ####################################################
#1. The data from July 2015 to June 2016 only should be considered
#2. Order level data dictionary:
#FSN ID: The unique identification of each SKU
#Order Date: Date on which the order was placed
#Order ID: The unique identification number of each order
#Order item ID: Suppose you order 2 different products under the same order, it generates 2 different order Item IDs under the same order ID; orders are tracked by the Order Item ID.
#GMV: Gross Merchandise Value or Revenue
#Units: Number of units of the specific product sold
#Order payment type: How the order was paid - prepaid or cash on delivery
#SLA: Number of days it typically takes to deliver the product
#Cust id: Unique identification of a customer
#Product MRP: Maximum retail price of the product
#Product procurement SLA: Time typically taken to procure the product

##################################################################################################################

## Load required packages ##

library(DataCombine)
library(scales)
library(glmnet)
library(DAAG)
library(caret)
library(GGally)
library(corrplot)
library(lubridate)
library(gdata)
library(ggplot2)
library(dplyr)
library(reshape)
library(tidyr)
library(data.table)
library(MASS)
library(car)


#*******************************
# Input and read the data details 
#*******************************

perl <- "C:\\Perl64\\bin\\perl.exe"
#set perl location above for any other location being used before running the next line

adver_data <- read.xls("Media data and other information.xlsx", sheet = 2, header = TRUE, skip = 1, verbose = FALSE, perl = "perl")
View(adver_data)
adver_data$year_month <- paste(adver_data$Year , adver_data$Month , sep = '-')
adver_data$Year <- as.numeric(adver_data$Year)
adver_data$Month <- as.numeric(adver_data$Month)

adver_data$year_month <- factor(adver_data$year_month, levels = adver_data$year_month[order(adver_data$Year , adver_data$Month)])

ggplot(adver_data, aes(x = year_month, y = Total.Investment)) + geom_bar(stat = "identity")

## advertising Spend  is lowest for aug
## advertising Spend is high in Sep,Oct,Dec,Mar


#Investments Radio and others is assigned 0 for NA values
sapply(adver_data , function(x) sum(is.na(x)))
adver_data[which(is.na(adver_data$Radio)), "Radio"] <- 0 
adver_data[which(is.na(adver_data$Other)), "Other"] <- 0

adver_data_l <- gather(adver_data, Medium, Spend, 3:12)

ggplot(adver_data_l, aes (x = Month, y = Spend, colour = Medium)) + geom_line(size = 1) + 
  scale_x_discrete(name="Months since May 2015", limits=seq(1,12,1))

#Removing Total investments from data, as it is the sum of all the mediums and converted to crore value
adver_data$Total.Investment <- NULL
adver_data[,3:11] <- adver_data[,3:11] * 10000000


#*****************************
# Import the original data set
#*****************************
consumer_elect <- read.csv ( "ConsumerElectronics.csv" , header = T , stringsAsFactors = F)
nrow(consumer_elect)  ##1648824 observations and 20 columns
str(consumer_elect)
summary(consumer_elect)

####### Data Checks ##########


## No issue with case sensitivity
sapply(consumer_elect, function(x) length(unique(toupper(x)))-length(unique(tolower(x)))) 

## NA values are there in gmv, cust_id, pincode. 4904 missing values in each column
sapply(consumer_elect, function(x){sum(is.na(x))})   

filter(consumer_elect , consumer_elect$gmv < 0 )  ## 0 row
filter(consumer_elect , consumer_elect$gmv == 0 ) ## 1349 rows 


## All rows for gmv only have 0 value

conselect_units0 <- filter(consumer_elect , consumer_elect$units < 0 )  ## 0 row
View(conselect_units0)
conselect_units  <- filter(consumer_elect , consumer_elect$units == 0 ) ## 0 row
View(conselect_units)
# All rows for unit only have 0 value

bdaysdelivery <- table(consumer_elect$deliverybdays)   
View(bdaysdelivery)
cdaysdelivery <- table(consumer_elect$deliverycdays)  
View(cdaysdelivery)

## rows with negative as well as very high deliverybdays
## rows with negative as well as very high deliverycdasy

unique(consumer_elect$s1_fact.order_payment_type)  
## Two payment type available - COD , Prepaid 
payment <- table(consumer_elect$s1_fact.order_payment_type)  
## COD is preferred one 

sla <- table(consumer_elect$sla)  
View(sla)

##There are same day deliveries as we have 0 sla. Few rows with high sla

# how many pincode and cust_id are there in the data
length(unique(consumer_elect$pincode)) 
## 7565 unique pincodes 
length(unique(consumer_elect$cust_id)) 
## 1201090 distinct customers 

# Identifying the unique segments 
unique(consumer_elect$product_analytic_super_category) ## Single value CE 
unique(consumer_elect$product_analytic_sub_category)   ## 14 distinct values 
unique(consumer_elect$product_analytic_category)       ## 5 distinct values 
unique(consumer_elect$product_analytic_vertical)       ## 74 distinct values 

# check for subcategory on category
mainsubcategory <- filter ( consumer_elect ,consumer_elect$product_analytic_sub_category %in% c("CameraAccessory", "GamingAccessory", "HomeAudio")) %>% group_by(product_analytic_sub_category , product_analytic_vertical)%>% summarise(  count = n()) 
View(mainsubcategory)
## 51 product_analytic_vertical under CameraAccessory", "GamingAccessory", "HomeAudio"

# check on the mrp value of products
# no product with less then 0 value while some have mrp as 0
filter(consumer_elect , consumer_elect$product_mrp < 0 )  ## 0 row
nrow(filter(consumer_elect , consumer_elect$product_mrp == 0 )) ## 5308 row


min(consumer_elect$order_date) 
## "2015-05-19 13:42:09"
max(consumer_elect$order_date) 
## "2016-07-25 01:19:45"

## Create a year-month variable 
consumer_elect$year_month <- paste(consumer_elect$Year, consumer_elect$Month , sep = '-')
consumer_elect$order_date <- as.Date(consumer_elect$order_date)
consumer_elect$start_week_date <-   floor_date(as.Date(consumer_elect$order_date), unit="week" , week_start = getOption("lubridate.week.start", 1))
consumer_elect[which(consumer_elect$start_week_date < '2015-07-01'),"start_week_date"] <- '2015-07-01'

View(consumer_elect)

## Finding the week number from a date
consumer_elect$week_no <- strftime( consumer_elect$start_week_date ,format="%V")
## add a year-month variable 
consumer_elect$year_month <- paste(consumer_elect$Year, consumer_elect$Month , sep = '-')
## Filter on date range July 2015 to June 2016
consumer_elect <- subset(consumer_elect, consumer_elect$order_date >= '2015-07-01' & consumer_elect$order_date < '2016-07-01')
## Filter out the rows  having missing values 
row.has.na <- apply(consumer_elect, 1, function(x){any(is.na(x))})
sum(row.has.na) 
#4904
## Remove the missing values 
consumer_elect <- consumer_elect[!row.has.na,]
consumer_elect$week_no <- as.numeric(consumer_elect$week_no)
View(consumer_elect)
## Add a varaiable to specify month number as per week start date 
consumer_elect$month_asper_week_startdate <- format(consumer_elect$start_week_date , "%m")
consumer_elect$month_asper_week_startdate <- as.numeric(consumer_elect$month_asper_week_startdate)
## Number the week from 1 to 53
## July 1st week will be 1 and june last week will be 53 
View(consumer_elect)

consumer_elect$week_no[consumer_elect$Year == 2015 ] <- (consumer_elect$week_no[consumer_elect$Year == 2015 ]) -26
consumer_elect$week_no[consumer_elect$Year == 2016 & consumer_elect$week_no !=53 ] <- (consumer_elect$week_no[consumer_elect$Year == 2016 & consumer_elect$week_no !=53 ]) +27
consumer_elect[which(consumer_elect$Year == 2016 & consumer_elect$Month==1 &consumer_elect$week_no == 53 ), "week_no"] <- consumer_elect[which(consumer_elect$Year == 2016 & consumer_elect$Month==1 &consumer_elect$week_no == 53 ), "week_no"] - 26

View(consumer_elect)

## Filter out the rows having mrp value 0 
consumer_elect <- consumer_elect[!consumer_elect$product_mrp == 0,]

consumer_elect$deliverybdays[consumer_elect$deliverybdays < 0] = 0
consumer_elect$deliverycdays[consumer_elect$deliverycdays < 0] = 0
consumer_elect$product_procurement_sla [consumer_elect$product_procurement_sla <0 ] =0

consumer_elect$deliverybdays <- as.numeric(consumer_elect$deliverybdays)
consumer_elect$deliverycdays <- as.numeric(consumer_elect$deliverycdays)
consumer_elect$sla <- as.numeric(consumer_elect$sla)
consumer_elect$delivery_on_time <- consumer_elect$sla - (consumer_elect$deliverybdays+consumer_elect$deliverycdays+consumer_elect$product_procurement_sla)
consumer_elect$delivery_status[consumer_elect$delivery_on_time < 0] <- 'Delayed'
consumer_elect$delivery_status[consumer_elect$delivery_on_time == 0] <- 'On time'
consumer_elect$delivery_status[consumer_elect$delivery_on_time > 0] <- 'Early'

View(consumer_elect)
#export the file
write.csv(consumer_elect, "consumer_elect.csv", row.names = FALSE)

#######################################################################

#*******************************
##  Read the promotional details 
#*******************************
ssale_cal<- read.xls("Media data and other information.xlsx", sheet = 3, header = TRUE ,stringsAsFactors = F)
ssale_cal$Year[1:6] <- 2015
ssale_cal$Year[7:12] <- 2016
ssale_cal$X <- NULL
View(ssale_cal)


#Derived manually from holidays
ssale_cal$start_week_no <- c(3,7,9,16,19,26,30,32,34,33,37,48)
ssale_cal$end_week_no <- c(3,8,9,16,20,27,30,32,34,34,37,48)
ssale_cal$promotion_type <- trim(sapply(ssale_cal$Sales.Calendar, function(x) substr(x , 1,  (regexpr("\\(", x[1])-1 ))))
ssale_cal$Sales.Calendar <- NULL
ssale_cal_wno <- gather ( ssale_cal, week_type , week_no , 2:3)
ssale_cal_wno$week_type <- NULL

View(ssale_cal)
View(ssale_cal_wno)
#******************************
## Read the satisfaction score 
#******************************
monthly_nps <- read.xls("Media data and other information.xlsx", sheet = 4, header = TRUE)
str(monthly_nps)
monthly_nps <- monthly_nps[2:13]
trans_monthly_nps <- transpose(monthly_nps)
trans_monthly_nps$Month <- c(seq(7,12,1),seq(1,6,1))
colnames(trans_monthly_nps)[1] <- "NPS"

View(trans_monthly_nps)

#****************************************************************************
### Aggragate the multiple dataset to create a master dataset at weekly level 
#****************************************************************************

## Group the data at weekly level 
weekly_consumer_elect <- consumer_elect %>% group_by ( Year, month_asper_week_startdate,  product_analytic_category,product_analytic_sub_category, product_analytic_vertical,year_month , week_no)%>% summarise( prepaid_cnt =  sum(ifelse (s1_fact.order_payment_type =='Prepaid' , 1 , 0)) ,cod_cnt =  sum(ifelse (s1_fact.order_payment_type =='COD' , 1,0)) ,delayed_delivery_cnt =sum(ifelse (delivery_status =='Delayed' , 1 , 0)), early_delivery_cnt =sum(ifelse (delivery_status =='Early' , 1 , 0)), onetime_delivery_cnt =sum(ifelse (delivery_status =='On time' , 1 , 0)), tot_gmv = sum(gmv) , tot_units = sum(units) , tot_product_mrp = sum( as.numeric (product_mrp)), avg_gmv = mean(gmv) , avg_mrp = mean(product_mrp) , no_of_customer = length(unique(cust_id)), no_of_orders = length(unique(order_id)) , list_price = (tot_gmv/tot_units) , avg_price = mean(list_price) )

colnames(weekly_consumer_elect)[2] <- "Month"

## Merge the ad data with weekly data 
weekly_consumer_adv_data <- merge(weekly_consumer_elect ,adver_data , by=c("Year" , "Month"))
View(weekly_consumer_adv_data)

## remove the unwanted variable
weekly_consumer_adv_data$year_month.y <- NULL 

## Merge the NPS data  
weekly_consumer_adv_data <- merge(weekly_consumer_adv_data ,trans_monthly_nps , by=c(  "Month"))

## Find out how many entries are there in a month  
week_in_month <- weekly_consumer_adv_data %>% group_by( Month ) %>% summarize (  tot_week = length(unique(week_no)) )

weekly_consumer_adv_data <- merge(weekly_consumer_adv_data ,week_in_month, by = c ( "Month") )

rows_in_week <- weekly_consumer_adv_data %>% group_by( week_no ) %>% summarize ( total_row = n())

weekly_consumer_adv_data <- merge(weekly_consumer_adv_data ,rows_in_week, by = c ( "week_no") )

View(weekly_consumer_adv_data)

#######################################################

## Convert monthly ad spend into weekly ad spend 
weekly_consumer_adv_data[,c(22:30)] <- weekly_consumer_adv_data[,c(22:30)]/(weekly_consumer_adv_data$tot_week*weekly_consumer_adv_data$total_row)

View(weekly_consumer_adv_data)

#**********************************************
## Add the promotional sale name in dataset

weekly_consumer_adv_data$promotion_type <- NULL
for (row_no  in 1:nrow(ssale_cal) ) {
  for (week in ssale_cal[row_no,2] : ssale_cal[row_no,3] ){
    print(paste("The week is", week))
    weekly_consumer_adv_data[which(weekly_consumer_adv_data$week_no==week),"promotion_type"]  <-   ssale_cal[row_no,4]
  }
}


#************************
## New Derived variables 
#**********************
weekly_consumer_adv_data$discounted_mrp <- (weekly_consumer_adv_data$tot_product_mrp-weekly_consumer_adv_data$tot_gmv)/weekly_consumer_adv_data$tot_product_mrp
weekly_consumer_adv_data$Holiday_week <- ifelse (is.na(weekly_consumer_adv_data$promotion_type) , 'N','Y' )
weekly_consumer_adv_data[which(is.na(weekly_consumer_adv_data$promotion_type)), "promotion_type"] <- "No_promotion"
weekly_consumer_adv_data$value_per_visitor <- weekly_consumer_adv_data$tot_gmv/weekly_consumer_adv_data$no_of_customer

View(weekly_consumer_adv_data)

#****************************************
### Perform EDA on weekly_consumer_adv_data, adver_data and consumer_elect
## It will help identify the need for different ad spend for each product category 
#****************************************

## Month wise advertisment spend details 
ggplot(adver_data_l, aes (x = Month, y = Spend, colour = Medium)) + geom_line() + 
  scale_x_discrete(name="Months since May 2015", limits=seq(1,12,1))

## Create week wise sale and ad spend details for various sub category level 
adver_sale_data <- weekly_consumer_adv_data %>% group_by (product_analytic_sub_category, week_no)%>% 
  summarise(tot_sales = sum(tot_gmv) ,
            tot_tv_spend = sum (TV), tot_digit_spend = sum (Digital), 
            tot_spons_spend = sum(Sponsorship) , tot_content_spend = sum(Content.Marketing),
            tot_online_spend = sum(Online.marketing) ,tot_aff_spend = sum(X.Affiliates),
            tot_sem_spend = sum(SEM) ,tot_radio_spend = sum(Radio), 
            tot_other_spend = sum(Other))


## weekly sale details for different sub category 
p <- ggplot(adver_sale_data , aes ( x = week_no , y = tot_sales))+ geom_line()
p + facet_wrap( ~ adver_sale_data$product_analytic_sub_category, nrow =2, ncol = 7) + labs(x = "week", y = "Sales " ) + ggtitle ( " Sales  vs Total Ad spend")

## Total TV adver spend vs sales details
p <- ggplot(adver_sale_data , aes ( x = tot_tv_spend , y = tot_sales))+ geom_line()
p + facet_wrap( ~ adver_sale_data$product_analytic_sub_category, nrow =2, ncol = 7) + labs(x = "Ad spend", y = "Sales ") + ggtitle ( " Sale vs TV Ad")

## Total Digital adver spend vs sales details
p <- ggplot(adver_sale_data , aes ( x = tot_digit_spend , y = tot_sales))+ geom_line()
p + facet_wrap( ~ adver_sale_data$product_analytic_sub_category, nrow =2, ncol = 7) + labs(x = "Ad spend", y = "Sales ") + ggtitle ( " Sale vs Digital Ad")

## Total Sponser adver spend vs sales details
p <- ggplot(adver_sale_data , aes ( x = tot_spons_spend , y = tot_sales))+ geom_line()
p + facet_wrap( ~ adver_sale_data$product_analytic_sub_category, nrow =2, ncol = 7) + labs(x = "Ad spend", y = "Sales ") + ggtitle ( " Sale vs Sponsor Ad")

## Total content adver spend vs sales details
p <- ggplot(adver_sale_data , aes ( x = tot_content_spend , y = tot_sales))+ geom_line()
p + facet_wrap( ~ adver_sale_data$product_analytic_sub_category, nrow =2, ncol = 7) + labs(x = "Ad spend", y = "Sales ") + ggtitle ( " Sale vs Content Ad")

## Total Online adver spend vs sales details
p <- ggplot(adver_sale_data , aes ( x = tot_online_spend , y = tot_sales))+ geom_line()
p + facet_wrap( ~ adver_sale_data$product_analytic_sub_category, nrow =2, ncol = 7) + labs(x = "Ad spend", y = "Sales ") + ggtitle ( " Sale vs Online Ad")

## Total affiliated adver spend vs sales details
p <- ggplot(adver_sale_data , aes ( x = tot_aff_spend , y = tot_sales))+ geom_line()
p + facet_wrap( ~ adver_sale_data$product_analytic_sub_category, nrow =2, ncol = 7) + labs(x = "Ad spend", y = "Sales ") + ggtitle ( " Sale vs Affiliate Ad")

## Total SEM adver spend vs sales details
p <- ggplot(adver_sale_data , aes ( x = tot_sem_spend , y = tot_sales))+ geom_line()
p + facet_wrap( ~ adver_sale_data$product_analytic_sub_category, nrow =2, ncol = 7) + labs(x = "Ad spend", y = "Sales ") + ggtitle ( " Sale vs SEM Ad")

## Total Radio adver spend vs sales details
p <- ggplot(adver_sale_data , aes ( x = tot_radio_spend , y = tot_sales))+ geom_line()
p + facet_wrap( ~ adver_sale_data$product_analytic_sub_category, nrow =2, ncol = 7) + labs(x = "Ad spend", y = "Sales ") + ggtitle ( " Sale vs Radio Ad")

## Total Other adver spend vs sales details
p <- ggplot(adver_sale_data , aes ( x = tot_other_spend , y = tot_sales))+ geom_line()
p + facet_wrap( ~ adver_sale_data$product_analytic_sub_category, nrow =2, ncol = 7) + labs(x = "Ad spend", y = "Sales ") + ggtitle ( " Sale vs Other Ad")

## Sale in different promotional and non promotional weeks
weekly_consumer_adv_data %>% group_by ( promotion_type) %>% summarise( Avg_sale = mean(tot_gmv)) %>% ggplot( aes ( x=promotion_type, y =Avg_sale  )) + geom_bar(stat = "identity")

## Sale in different promotional weeks for different sub categories 
weekly_consumer_adv_data %>% group_by ( product_analytic_sub_category ,promotion_type) %>% summarise( Avg_sale = mean(tot_gmv)) %>% ggplot( aes ( x=promotion_type, y =Avg_sale  )) + geom_bar(stat = "identity") +facet_wrap( ~ product_analytic_sub_category, nrow =2, ncol = 7)+theme(axis.text.x=element_text(angle = -90, hjust = 0))

## weekly advertisment spend vs sales 
sale_vs_week_adver <- weekly_consumer_adv_data %>% group_by ( week_no) %>% summarise(tot_sales = sum(tot_gmv) , ad_spend = sum(TV+Digital+Sponsorship+Content.Marketing+Online.marketing+X.Affiliates+SEM+Radio+Other))
sale_vs_week_adver_l <- gather(sale_vs_week_adver, Type, Spend, 2:3)
ggplot(sale_vs_week_adver_l, aes ( x= week_no , y = Spend , color = Type))+geom_line(size = 1)

### Disocunt percentage vs average sales

discount_vs_sales <- weekly_consumer_adv_data[,c("tot_gmv" , "discounted_mrp")]
discount_vs_sales$discount_range <- ifelse (discount_vs_sales$discounted_mrp <= .1 , 'up to 10', ifelse ( discount_vs_sales$discounted_mrp > .1 & discount_vs_sales$discounted_mrp <= .3 , 'up to 30', ifelse(discount_vs_sales$discounted_mrp > .3 & discount_vs_sales$discounted_mrp <= .5 , 'up to 50','>50') ))
discount_vs_sales %>% group_by(discount_range) %>% summarise( avg_sale = mean(tot_gmv)) %>% ggplot(aes ( x=discount_range , y =avg_sale  )) + geom_bar(stat = "identity")

## Avg discount at different promotional and non promotional week
weekly_consumer_adv_data %>% group_by(promotion_type) %>% summarise(avg_disc = mean(discounted_mrp)) %>% ggplot(aes(x= promotion_type, y =avg_disc )) + geom_bar(stat = "identity")

## Nps vs week
weekly_consumer_adv_data %>% group_by(week_no) %>% summarise(nps = mean(NPS)) %>% ggplot(aes(x= week_no, y =nps )) + geom_bar(stat = "identity")

## payment type vs number of orders
consumer_elect %>% group_by ( s1_fact.order_payment_type) %>% summarise(order_cnt = n()) %>% ggplot(aes(x= s1_fact.order_payment_type, y =order_cnt )) + geom_bar(stat = "identity")

## delivery_status  vs number of orders
consumer_elect %>% group_by ( delivery_status) %>% summarise(order_cnt = n()) %>% ggplot(aes(x= delivery_status, y =order_cnt )) + geom_bar(stat = "identity")


#**********************************************************************
###create 3 different data set per requried sub category & add the derived KPI
#**********************************************************************
unique(weekly_consumer_adv_data$product_analytic_category)
## Since model needs to be built at sub category level, this varaiable is needed 
weekly_consumer_adv_data$product_analytic_category <- NULL 
weekly_consumer_adv_data$year_month.x <- NULL 

## Create a dataset  for Home audio , camera accessory and gaming accessories 
weekly_consumer_adv_data <- filter ( weekly_consumer_adv_data ,weekly_consumer_adv_data$product_analytic_sub_category %in% c("CameraAccessory", "GamingAccessory", "HomeAudio")) 

## Dummy variable creation for character data types 
weekly_consumer_adv_data_chr <- weekly_consumer_adv_data[,c(5,32,34)]
weekly_consumer_adv_data_fact <- data.frame(sapply(weekly_consumer_adv_data_chr, function(x) factor(x)))
str(weekly_consumer_adv_data_fact)

# creating dummy variables for factor attributes
dummies<- data.frame(sapply(weekly_consumer_adv_data_fact, 
                            function(x) data.frame(model.matrix(~x-1,data =weekly_consumer_adv_data_fact))[,-1]))

## Create master data set by appending dummies with main data set 
weekly_consumer_adv_complete <- cbind(weekly_consumer_adv_data[,c(1:4,6:31,33,35)],dummies) 
View(weekly_consumer_adv_complete) 

#export the file
write.csv(weekly_consumer_adv_complete, "weekly_consumer_adv_complete.csv", row.names = FALSE)

#******************************
### Outlier treatment 
#******************************


boxplot(weekly_consumer_adv_complete$tot_gmv )
boxplot(weekly_consumer_adv_complete$tot_units)
boxplot(weekly_consumer_adv_complete$tot_product_mrp)
boxplot(weekly_consumer_adv_complete$TV)
boxplot(weekly_consumer_adv_complete$Digital)
boxplot(weekly_consumer_adv_complete$Sponsorship)
boxplot(weekly_consumer_adv_complete$Content.Marketing)
boxplot(weekly_consumer_adv_complete$Online.marketing)
boxplot(weekly_consumer_adv_complete$X.Affiliates)
boxplot(weekly_consumer_adv_complete$SEM)
boxplot(weekly_consumer_adv_complete$Radio)
boxplot(weekly_consumer_adv_complete$Other)


## Since there are lots of outliers  in dataset, they cant be removed. 
## So they have been capped by appropiate quantile decided by looking at data spread

overall_quantile <- sapply(weekly_consumer_adv_complete[,c("tot_gmv","tot_units", "tot_product_mrp" , "TV" ,"Digital",
                                                           "Sponsorship", "Content.Marketing", "Online.marketing" ,"X.Affiliates", "SEM" ,"Radio" , "Other" )], 
                           function(x) quantile(x,seq(0,1,.01),na.rm = T)) 

## remove_outliers function for capping the value to specific quantile

remove_outliers <- function(x , lower_quantile, upper_quantile) {
  qnt <- quantile(x, probs=c(lower_quantile, upper_quantile), na.rm = T)
  H <- 1.5 * IQR(x, na.rm = T)
  y <- x
  y[x < qnt[1]] <- qnt[1]
  y[x > qnt[2]] <- qnt[2]
  y
}

weekly_consumer_adv_complete$tot_gmv <- remove_outliers (weekly_consumer_adv_complete$tot_gmv,0, .97 ) 
weekly_consumer_adv_complete$tot_units <- remove_outliers (weekly_consumer_adv_complete$tot_units,0, .97 ) 
weekly_consumer_adv_complete$tot_product_mrp <- remove_outliers (weekly_consumer_adv_complete$tot_product_mrp,0, .97 ) 
weekly_consumer_adv_complete$TV <- remove_outliers (weekly_consumer_adv_complete$TV,0, .98 ) 
weekly_consumer_adv_complete$Digital <- remove_outliers (weekly_consumer_adv_complete$Digital,0, .95 ) 
weekly_consumer_adv_complete$Sponsorship <- remove_outliers (weekly_consumer_adv_complete$Sponsorship,0, .95 ) 
weekly_consumer_adv_complete$Content.Marketing <- remove_outliers (weekly_consumer_adv_complete$Content.Marketing,0, .95 ) 
weekly_consumer_adv_complete$SEM <- remove_outliers (weekly_consumer_adv_complete$SEM,0, .95 ) 
weekly_consumer_adv_complete$Radio <- remove_outliers (weekly_consumer_adv_complete$Radio,0, .95 ) 
weekly_consumer_adv_complete$Other <- remove_outliers (weekly_consumer_adv_complete$Other,0, .95 )

## Find out  how many distinct values are there  for different columns
sapply(weekly_consumer_adv_complete, function(x) length(unique(x)))

weekly_consumer_adv_complete$total_row <- NULL
weekly_consumer_adv_complete$tot_week <- NULL

##  Take back up of master dataset weekly_consumer_adv_complete

weekly_consumer_adv_complete2 <- weekly_consumer_adv_complete

## Check the correlation among multiple varaiables to decide which varaiables are highly corelated with each other
## Column 4 has been excluded as it contains sub category 

corr <- cor(weekly_consumer_adv_complete2[,-c (4)])

##Depending on higher corelation or since there vars are direct proxy to sales , so taking them out
weekly_consumer_adv_complete$avg_mrp <- NULL
weekly_consumer_adv_complete$avg_price <- NULL
weekly_consumer_adv_complete$tot_units <- NULL
weekly_consumer_adv_complete$no_of_orders <- NULL
weekly_consumer_adv_complete$tot_product_mrp <- NULL
weekly_consumer_adv_complete$avg_gmv <- NULL
weekly_consumer_adv_complete$value_per_visitor <- NULL
weekly_consumer_adv_complete$Year <- NULL
weekly_consumer_adv_complete$no_of_customer <- NULL
weekly_consumer_adv_complete$delayed_delivery_cnt <- NULL
weekly_consumer_adv_complete$early_delivery_cnt <- NULL
weekly_consumer_adv_complete$onetime_delivery_cnt <- NULL
weekly_consumer_adv_complete$cod_cnt <- NULL
weekly_consumer_adv_complete$prepaid_cnt <- NULL

## Create 3 data set HomeAudio, GamingAccessory and CameraAccessory  for model building. 
list2env(split( weekly_consumer_adv_complete[,-3], weekly_consumer_adv_complete$product_analytic_sub_category), envir = .GlobalEnv)
str(HomeAudio)
str(GamingAccessory)
str(CameraAccessory)

nrow(HomeAudio)
nrow(GamingAccessory)
nrow(CameraAccessory)

#########################################################################################################

#################################### LINEAR MODELLING #########################################
#################### 1. PRODUCT SUB CATEGORY: HOME AUDIO ###########################
#Creating a back up of HomeAudio df
home_audio_lm <- HomeAudio

#Let us exclude week_no and month from the df
home_audio_lm$week_no <- NULL
home_audio_lm$Month <- NULL

#Scaling all columns with numeric values
home_audio_lm[,1:13] <- data.frame(scale(home_audio_lm[,1:13], center = TRUE))

set.seed(100)
trainindices= sample(1:nrow(home_audio_lm), 0.7*nrow(home_audio_lm))

#Generating the training data set
train_home_audio = home_audio_lm[trainindices,]

#Generating test data set
test_home_audio = home_audio_lm[-trainindices,]
#______________________________________________________________________________________________________#
#Let us start building the model using backward selection first
home_audio_model1 <-  lm(tot_gmv~., train_home_audio)
summary(home_audio_model1)

#Using stepAIC to estimate the model
step_home_audio <- stepAIC(home_audio_model1, direction = "both")

# using last step of AIC for finalisation of our next model, keep all variables with - sign
home_audio_model2 <- lm(tot_gmv~ promotion_type.xBSD.5 + product_analytic_vertical.xHiFiSystem +
                          product_analytic_vertical.xSoundMixer + Online.marketing + promotion_type.xBig.Diwali.Sale +
                          X.Affiliates + NPS + product_analytic_vertical.xDJController + Other + promotion_type.xEid...Rathayatra.sale +
                          product_analytic_vertical.xDock + Sponsorship + product_analytic_vertical.xDockingStation + Content.Marketing +
                          Digital + product_analytic_vertical.xFMRadio + product_analytic_vertical.xHomeAudioSpeaker, data = train_home_audio)
summary(home_audio_model2)

vif(home_audio_model2)

#Remove variables product_analytic_vertical.xHiFiSystem and product_analytic_vertical.xSoundMixer
#as they have high p-value

home_audio_model3 <- lm(tot_gmv~ promotion_type.xBSD.5 +  Online.marketing + promotion_type.xBig.Diwali.Sale +
                          X.Affiliates + NPS + product_analytic_vertical.xDJController + Other + promotion_type.xEid...Rathayatra.sale +
                          product_analytic_vertical.xDock + Sponsorship + product_analytic_vertical.xDockingStation + Content.Marketing +
                          Digital + product_analytic_vertical.xFMRadio + product_analytic_vertical.xHomeAudioSpeaker, data = train_home_audio)
summary(home_audio_model3)

vif(home_audio_model3)

#Remove Online.marketing as it has high p-value and vifX.Affiliates
home_audio_model4 <- lm(tot_gmv~ promotion_type.xBSD.5 + promotion_type.xBig.Diwali.Sale +
                          X.Affiliates + NPS + product_analytic_vertical.xDJController + Other + promotion_type.xEid...Rathayatra.sale +
                          product_analytic_vertical.xDock + Sponsorship + product_analytic_vertical.xDockingStation + Content.Marketing +
                          Digital + product_analytic_vertical.xFMRadio + product_analytic_vertical.xHomeAudioSpeaker, data = train_home_audio)
summary(home_audio_model4)

vif(home_audio_model4)

#Remove variables promotion_type.xBSD.5 and X.Affiliates
home_audio_model5 <- lm(tot_gmv~ promotion_type.xBig.Diwali.Sale +
                          NPS + product_analytic_vertical.xDJController + Other + promotion_type.xEid...Rathayatra.sale +
                          product_analytic_vertical.xDock + Sponsorship + product_analytic_vertical.xDockingStation + Content.Marketing +
                          Digital + product_analytic_vertical.xFMRadio + product_analytic_vertical.xHomeAudioSpeaker, data = train_home_audio)
summary(home_audio_model5)

vif(home_audio_model5)

#Remove the other variable
home_audio_model6 <- lm(tot_gmv~ promotion_type.xBig.Diwali.Sale +
                          NPS + product_analytic_vertical.xDJController  + promotion_type.xEid...Rathayatra.sale +
                          product_analytic_vertical.xDock + Sponsorship + product_analytic_vertical.xDockingStation + Content.Marketing +
                          Digital + product_analytic_vertical.xFMRadio + product_analytic_vertical.xHomeAudioSpeaker, data = train_home_audio)
summary(home_audio_model6)

vif(home_audio_model6)

#Remove variables NPS and product_analytic_vertical.xDJController since they have low significance
home_audio_model7 <- lm(tot_gmv~ promotion_type.xBig.Diwali.Sale +
                          promotion_type.xEid...Rathayatra.sale +
                          product_analytic_vertical.xDock + Sponsorship + product_analytic_vertical.xDockingStation + Content.Marketing +
                          Digital + product_analytic_vertical.xFMRadio + product_analytic_vertical.xHomeAudioSpeaker, data = train_home_audio)
summary(home_audio_model7)

vif(home_audio_model7)

#Remove variables product_analytic_vertical.xDock and check
home_audio_model8 <- lm(tot_gmv~ promotion_type.xBig.Diwali.Sale +
                          promotion_type.xEid...Rathayatra.sale +
                          Sponsorship + product_analytic_vertical.xDockingStation + Content.Marketing +
                          Digital + product_analytic_vertical.xFMRadio + product_analytic_vertical.xHomeAudioSpeaker, data = train_home_audio)
summary(home_audio_model8)

vif(home_audio_model8)

#Remove variables promotion_type.xEid...Rathayatra.sale and product_analytic_vertical.xDockingStation
home_audio_model9 <- lm(tot_gmv~ promotion_type.xBig.Diwali.Sale +
                          Sponsorship + Content.Marketing +
                          Digital + product_analytic_vertical.xFMRadio + product_analytic_vertical.xHomeAudioSpeaker, data = train_home_audio)
summary(home_audio_model9)

vif(home_audio_model9)

#Remove variables promotion_type.xBig.Diwali.Sale and Content.Marketing
home_audio_model10 <- lm(tot_gmv~ Sponsorship + 
                           Digital + product_analytic_vertical.xFMRadio + product_analytic_vertical.xHomeAudioSpeaker, data = train_home_audio)
summary(home_audio_model10)

vif(home_audio_model10)

#Remove variable Digital
home_audio_model11 <- lm(tot_gmv~ Sponsorship + 
                           product_analytic_vertical.xFMRadio + product_analytic_vertical.xHomeAudioSpeaker, data = train_home_audio)
summary(home_audio_model11)

vif(home_audio_model11)


final_home_audio_model <- home_audio_model11
#R squared = 0.861
#highly significant variables are:
#1. product_analytic_vertical.xFMRadio 
#2. product_analytic_vertical.xHomeAudioSpeaker
#3. Sponsorship

#______________________________________________________________________________________________________#
#prediction on test data

home_audio_prediction <- predict(final_home_audio_model, test_home_audio)
test_home_audio$predicted_gmv <- home_audio_prediction

home_r <- cor(test_home_audio$tot_gmv, test_home_audio$predicted_gmv)
home_rsquared <- home_r^2
home_rsquared
#R squared = 0.77

#____________________________________________________________________________________________________#
#Let us find out the elasticity
elasticity <- function(var) {
  x <- as.numeric(final_home_audio_model$coefficients[var])
  return(x)
}

var_list <- list()

for(i in 2:length(final_home_audio_model$coefficients)) {
  var_list[i-1] <- elasticity(names(final_home_audio_model$coefficients)[i])
}

elasticity.outputs.home <- data.frame(names(final_home_audio_model$coefficients[2:length(final_home_audio_model$coefficients)]))
elasticity.outputs.home <- cbind(elasticity.outputs.home,do.call(rbind.data.frame, var_list))
colnames(elasticity.outputs.home) <- c("Variable","Elasticity")

elasticity.outputs.home$direction <- ifelse(elasticity.outputs.home$Elasticity > 0, "Positive", "Negative")

ggplot(data=elasticity.outputs.home, aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Home Audio - Linear Model") +xlab("Variables")


#_____________________________________________________________________________________________________________#
home_lm_cv <- cv.lm(data = train_home_audio , form.lm = formula(tot_gmv~ product_analytic_vertical.xFMRadio + 
                                                                  product_analytic_vertical.xHomeAudioSpeaker), m=15)


#overall ms = 0.145



#################################### LINEAR MODELLING #########################################
#################### 2. PRODUCT SUB CATEGORY: CAMERA ACCESSORY ###########################
#Creating a back up of CameraAccessory df
camera_accessory_lm <- CameraAccessory

#Let us exclude week_no and month from the df
camera_accessory_lm$week_no <- NULL
camera_accessory_lm$Month <- NULL

#Scaling all columns with numeric values
camera_accessory_lm[,1:13] <- data.frame(scale(camera_accessory_lm[,1:13], center = TRUE))

set.seed(100)
trainindices= sample(1:nrow(camera_accessory_lm), 0.7*nrow(camera_accessory_lm))

#Generating the training data set
train_camera_accessory = camera_accessory_lm[trainindices,]

#Generating test data set
test_camera_accessory = camera_accessory_lm[-trainindices,]

#______________________________________________________________________________________________________#
#Let us start building the model using backward selection first
camera_acc_model1 <-  lm(tot_gmv~., train_camera_accessory)
summary(home_audio_model1)

#Using stepAIC to estimate the model
step_camera_acc <- stepAIC(camera_acc_model1, direction = "both")


# using last step of AIC for finalisation of our next model, keep all variables with - sign
camera_acc_model2 <- lm(tot_gmv~product_analytic_vertical.xCameraBag + list_price + promotion_type.xEid...Rathayatra.sale 
                        + Content.Marketing + product_analytic_vertical.xCameraTripod + 
                          discounted_mrp + product_analytic_vertical.xCameraBattery + NPS + TV +
                          promotion_type.xNo_promotion + product_analytic_vertical.xFlash + 
                          promotion_type.xDaussera.sale + product_analytic_vertical.xTeleconverter +
                          product_analytic_vertical.xFlashShoeAdapter + promotion_type.xChristmas...New.Year.Sale +
                          product_analytic_vertical.xCameraLEDLight + product_analytic_vertical.xReflectorUmbrella +
                          SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                          Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                          product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                          product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                          product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                          product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                          product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model2)

vif(camera_acc_model2)

#Remove variables Content.Marketing as it has low significance and high vif
camera_acc_model3 <- lm(tot_gmv~product_analytic_vertical.xCameraBag + list_price + promotion_type.xEid...Rathayatra.sale 
                        + product_analytic_vertical.xCameraTripod + 
                          discounted_mrp + product_analytic_vertical.xCameraBattery + NPS + TV +
                          promotion_type.xNo_promotion + product_analytic_vertical.xFlash + 
                          promotion_type.xDaussera.sale + product_analytic_vertical.xTeleconverter +
                          product_analytic_vertical.xFlashShoeAdapter + promotion_type.xChristmas...New.Year.Sale +
                          product_analytic_vertical.xCameraLEDLight + product_analytic_vertical.xReflectorUmbrella +
                          SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                          Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                          product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                          product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                          product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                          product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                          product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)

summary(camera_acc_model3)
vif(camera_acc_model3)

#Remove variable NPS as it has low significance and high vif
camera_acc_model4 <- lm(tot_gmv~product_analytic_vertical.xCameraBag + list_price + promotion_type.xEid...Rathayatra.sale 
                        + product_analytic_vertical.xCameraTripod + 
                          discounted_mrp + product_analytic_vertical.xCameraBattery  + TV +
                          promotion_type.xNo_promotion + product_analytic_vertical.xFlash + 
                          promotion_type.xDaussera.sale + product_analytic_vertical.xTeleconverter +
                          product_analytic_vertical.xFlashShoeAdapter + promotion_type.xChristmas...New.Year.Sale +
                          product_analytic_vertical.xCameraLEDLight + product_analytic_vertical.xReflectorUmbrella +
                          SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                          Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                          product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                          product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                          product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                          product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                          product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)

summary(camera_acc_model4)
vif(camera_acc_model4)

#Remove variables list_price and product_analytic_vertical.xCameraTripod
#as it has low significance and high vif
camera_acc_model5 <- lm(tot_gmv~product_analytic_vertical.xCameraBag +  promotion_type.xEid...Rathayatra.sale 
                        + discounted_mrp + product_analytic_vertical.xCameraBattery  + TV +
                          promotion_type.xNo_promotion + product_analytic_vertical.xFlash + 
                          promotion_type.xDaussera.sale + product_analytic_vertical.xTeleconverter +
                          product_analytic_vertical.xFlashShoeAdapter + promotion_type.xChristmas...New.Year.Sale +
                          product_analytic_vertical.xCameraLEDLight + product_analytic_vertical.xReflectorUmbrella +
                          SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                          Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                          product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                          product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                          product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                          product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                          product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)

summary(camera_acc_model5)
vif(camera_acc_model5)

#Remove variables discounted_mrp as it has low significance and high vif
camera_acc_model6 <- lm(tot_gmv~product_analytic_vertical.xCameraBag +  promotion_type.xEid...Rathayatra.sale 
                        + product_analytic_vertical.xCameraBattery  + TV +
                          promotion_type.xNo_promotion + product_analytic_vertical.xFlash + 
                          promotion_type.xDaussera.sale + product_analytic_vertical.xTeleconverter +
                          product_analytic_vertical.xFlashShoeAdapter + promotion_type.xChristmas...New.Year.Sale +
                          product_analytic_vertical.xCameraLEDLight + product_analytic_vertical.xReflectorUmbrella +
                          SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                          Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                          product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                          product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                          product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                          product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                          product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)

summary(camera_acc_model6)
vif(camera_acc_model6)

#Remove variable product_analytic_vertical.xCameraBag as it has low significance
camera_acc_model7 <- lm(tot_gmv~  promotion_type.xEid...Rathayatra.sale 
                        + product_analytic_vertical.xCameraBattery  + TV +
                          promotion_type.xNo_promotion + product_analytic_vertical.xFlash + 
                          promotion_type.xDaussera.sale + product_analytic_vertical.xTeleconverter +
                          product_analytic_vertical.xFlashShoeAdapter + promotion_type.xChristmas...New.Year.Sale +
                          product_analytic_vertical.xCameraLEDLight + product_analytic_vertical.xReflectorUmbrella +
                          SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                          Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                          product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                          product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                          product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                          product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                          product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model7)
vif(camera_acc_model7)

#remove variable TV which has low significance and high vif
camera_acc_model8 <- lm(tot_gmv~  promotion_type.xEid...Rathayatra.sale 
                        + product_analytic_vertical.xCameraBattery  + 
                          promotion_type.xNo_promotion + product_analytic_vertical.xFlash + 
                          promotion_type.xDaussera.sale + product_analytic_vertical.xTeleconverter +
                          product_analytic_vertical.xFlashShoeAdapter + promotion_type.xChristmas...New.Year.Sale +
                          product_analytic_vertical.xCameraLEDLight + product_analytic_vertical.xReflectorUmbrella +
                          SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                          Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                          product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                          product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                          product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                          product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                          product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model8)
vif(camera_acc_model8)

#remove variable product_analytic_vertical.xCameraBattery and product_analytic_vertical.xFlash
#as they have low significance
camera_acc_model9 <- lm(tot_gmv~  promotion_type.xEid...Rathayatra.sale + 
                          promotion_type.xNo_promotion +  
                          promotion_type.xDaussera.sale + product_analytic_vertical.xTeleconverter +
                          product_analytic_vertical.xFlashShoeAdapter + promotion_type.xChristmas...New.Year.Sale +
                          product_analytic_vertical.xCameraLEDLight + product_analytic_vertical.xReflectorUmbrella +
                          SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                          Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                          product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                          product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                          product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                          product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                          product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)

summary(camera_acc_model9)
vif(camera_acc_model9)

#remove promotion_type.xEid...Rathayatra.sale which has low significance
camera_acc_model10 <- lm(tot_gmv~  
                           promotion_type.xNo_promotion +  
                           promotion_type.xDaussera.sale + product_analytic_vertical.xTeleconverter +
                           product_analytic_vertical.xFlashShoeAdapter + promotion_type.xChristmas...New.Year.Sale +
                           product_analytic_vertical.xCameraLEDLight + product_analytic_vertical.xReflectorUmbrella +
                           SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                           Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                           product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                           product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)

summary(camera_acc_model10)
vif(camera_acc_model10)

#remove promotion_type.xDaussera.sale as it has low significance
camera_acc_model11 <- lm(tot_gmv~  
                           promotion_type.xNo_promotion +  
                           product_analytic_vertical.xTeleconverter +
                           product_analytic_vertical.xFlashShoeAdapter + promotion_type.xChristmas...New.Year.Sale +
                           product_analytic_vertical.xCameraLEDLight + product_analytic_vertical.xReflectorUmbrella +
                           SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                           Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                           product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                           product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)

summary(camera_acc_model11)
vif(camera_acc_model11)

#remove  product_analytic_vertical.xTeleconverter and product_analytic_vertical.xFlashShoeAdapter 
camera_acc_model12 <- lm(tot_gmv~  
                           promotion_type.xNo_promotion +  
                           promotion_type.xChristmas...New.Year.Sale +
                           product_analytic_vertical.xCameraLEDLight + product_analytic_vertical.xReflectorUmbrella +
                           SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                           Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                           product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                           product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model12)
vif(camera_acc_model12)

#remove product_analytic_vertical.xCameraLEDLight 
camera_acc_model13 <- lm(tot_gmv~  
                           promotion_type.xNo_promotion +  
                           promotion_type.xChristmas...New.Year.Sale +
                           product_analytic_vertical.xReflectorUmbrella +
                           SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                           Sponsorship + product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                           product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                           product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model13)
vif(camera_acc_model13)

#remove Sponsorship as it has high vif 
camera_acc_model14 <- lm(tot_gmv~  
                           promotion_type.xNo_promotion +  
                           promotion_type.xChristmas...New.Year.Sale +
                           product_analytic_vertical.xReflectorUmbrella +
                           SEM + X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                           product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                           product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                           product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model14)
vif(camera_acc_model14)

#Remove SEM + promotion_type.xChristmas...New.Year.Sale as they have high p value
camera_acc_model15 <- lm(tot_gmv~  
                           promotion_type.xNo_promotion +  
                           product_analytic_vertical.xReflectorUmbrella +
                           X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                           product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                           product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                           product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model15)
vif(camera_acc_model15)

#Remove promotion_type.xNo_promotion + product_analytic_vertical.xReflectorUmbrella as they have high p value
camera_acc_model16 <- lm(tot_gmv~  
                           X.Affiliates + product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraFilmRolls +
                           product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                           product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                           product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model16)
vif(camera_acc_model16)

#Remove product_analytic_vertical.xSoftbox + product_analytic_vertical.xCameraHousing as they have high p value
camera_acc_model17 <- lm(tot_gmv~  
                           X.Affiliates +  product_analytic_vertical.xCameraFilmRolls +
                           promotion_type.xRakshabandhan.Sale +
                           product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                           product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xCameraMount + product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model17)
vif(camera_acc_model17)

#Remove product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraBatteryGrip +
#product_analytic_vertical.xCameraFilmRolls as they have high vif
camera_acc_model18 <- lm(tot_gmv~  
                           X.Affiliates +  
                           promotion_type.xRakshabandhan.Sale +
                           product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                           product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model18)
vif(camera_acc_model18)

#Remove X.Affiliates + promotion_type.xRakshabandhan.Sale as they have high p value
camera_acc_model19 <- lm(tot_gmv~  
                           product_analytic_vertical.xCameraBatteryCharger +  product_analytic_vertical.xFilter+
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                           product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model19)
vif(camera_acc_model19)

#Remove product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter as they have high p value
camera_acc_model20 <- lm(tot_gmv~  
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraMicrophone +
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + product_analytic_vertical.xExtensionTube +
                           product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model20)
vif(camera_acc_model20)

#Remove product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xExtensionTube as it has high p value
camera_acc_model21 <- lm(tot_gmv~  
                           product_analytic_vertical.xCameraEyeCup + 
                           product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                           product_analytic_vertical.xCameraAccessory  + 
                           product_analytic_vertical.xTelescope + 
                           product_analytic_vertical.xLens, data = train_camera_accessory)
summary(camera_acc_model21)
vif(camera_acc_model21)
#Multiple R-squared:  0.636,	Adjusted R-squared:  0.633 

final_camera_acc_model <- camera_acc_model21


#______________________________________________________________________________________________________#
#prediction on test data

camera_acc_prediction <- predict(final_camera_acc_model, test_camera_accessory)
test_camera_accessory$predicted_gmv <- camera_acc_prediction

camera_r <- cor(test_camera_accessory$tot_gmv, test_camera_accessory$predicted_gmv)
camera_rsquared <- camera_r^2
camera_rsquared
#R squared = 0.694

#____________________________________________________________________________________________________#
#Let us find out the elasticity
elasticity_cam <- function(var) {
  x <- as.numeric(final_camera_acc_model$coefficients[var])
  return(x)
}

var_list_cam <- list()

for(i in 2:length(final_camera_acc_model$coefficients)) {
  var_list_cam[i-1] <- elasticity_cam(names(final_camera_acc_model$coefficients)[i])
}

elasticity.outputs.cam <- data.frame(names(final_camera_acc_model$coefficients[2:length(final_camera_acc_model$coefficients)]))
elasticity.outputs.cam <- cbind(elasticity.outputs.cam,do.call(rbind.data.frame, var_list_cam))
colnames(elasticity.outputs.cam) <- c("Variable","Elasticity")

elasticity.outputs.cam$direction <- ifelse(elasticity.outputs.cam$Elasticity > 0, "Positive", "Negative")

ggplot(data=elasticity.outputs.cam, aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Camera Accessory - Linear Model") +xlab("Variables")


#_____________________________________________________________________________________________________________#
cam_lm_cv <- cv.lm(data = train_camera_accessory , form.lm = formula(tot_gmv~product_analytic_vertical.xCameraEyeCup + 
                                                                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + 
                                                                       product_analytic_vertical.xCameraAccessory  + 
                                                                       product_analytic_vertical.xTelescope + 
                                                                       product_analytic_vertical.xLens), m=10)
#ms = 0.344



################################### LINEAR MODELLING #########################################
#################### 3. PRODUCT SUB CATEGORY: GAMING ACCESSORY ###########################
#Creating a back up of GamingAccessory df
game_Acess_lm <- GamingAccessory
View(game_Acess_lm)
#Let us exclude week_no and month from the df
game_Acess_lm$week_no <- NULL
game_Acess_lm$Month <- NULL

#Scaling all columns with numeric values
game_Acess_lm[,1:13] <- data.frame(scale(game_Acess_lm[,1:13], center = TRUE))

set.seed(100)
trainindices= sample(1:nrow(game_Acess_lm), 0.7*nrow(game_Acess_lm))

#Generating the training data set
train_game_Acess = game_Acess_lm[trainindices,]
View(train_game_Acess)
#Generating test data set
test_game_Acess = game_Acess_lm[-trainindices,]
View(test_game_Acess)
#---------------------------------------------------------------------------------------------------

#Let us start building the model using backward selection first
game_Acess_model1 <-  lm(tot_gmv~., train_game_Acess)
summary(game_Acess_model1)

#Using stepAIC to estimate the model
step_game_Acess <- stepAIC(game_Acess_model1, direction = "both")

# using last step of AIC for finalisation of our next model, keep all variables with - sign
game_Acess_model2 <- lm(tot_gmv~ product_analytic_vertical.xGamingAccessoryKit + Digital  +
                          product_analytic_vertical.xMotionController + product_analytic_vertical.xGamingChargingStation + 
                          promotion_type.xChristmas...New.Year.Sale +
                          Radio + SEM + product_analytic_vertical.xJoystickGamingWheel + discounted_mrp +
                          promotion_type.xDaussera.sale + promotion_type.xBSD.5 +
                          product_analytic_vertical.xGamingSpeaker + NPS + TV + Sponsorship + X.Affiliates + 
                          product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                          promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingMouse +
                          product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model2)

vif(game_Acess_model2)

# Removing Digital as vif as well as p value is high
game_Acess_model3 <- lm(tot_gmv~ product_analytic_vertical.xGamingAccessoryKit +
                          product_analytic_vertical.xMotionController + product_analytic_vertical.xGamingChargingStation + 
                          promotion_type.xChristmas...New.Year.Sale +
                          Radio + SEM + product_analytic_vertical.xJoystickGamingWheel + discounted_mrp +
                          promotion_type.xDaussera.sale + promotion_type.xBSD.5 +
                          product_analytic_vertical.xGamingSpeaker + NPS + TV + Sponsorship + X.Affiliates + 
                          product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                          promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingMouse +
                          product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model3)

vif(game_Acess_model3)

# Removing discounted_mrp as it has high p value and vif

game_Acess_model4 <- lm(tot_gmv~ product_analytic_vertical.xGamingAccessoryKit +
                          product_analytic_vertical.xMotionController + product_analytic_vertical.xGamingChargingStation + 
                          promotion_type.xChristmas...New.Year.Sale +
                          Radio + SEM + product_analytic_vertical.xJoystickGamingWheel + 
                          promotion_type.xDaussera.sale + promotion_type.xBSD.5 +
                          product_analytic_vertical.xGamingSpeaker + NPS + TV + Sponsorship + X.Affiliates + 
                          product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                          promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingMouse +
                          product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model4)

vif(game_Acess_model4)

# Removing Radio as it has low significance

game_Acess_model5 <- lm(tot_gmv~ product_analytic_vertical.xGamingAccessoryKit +
                          product_analytic_vertical.xMotionController + product_analytic_vertical.xGamingChargingStation + 
                          promotion_type.xChristmas...New.Year.Sale +
                          SEM + product_analytic_vertical.xJoystickGamingWheel + 
                          promotion_type.xDaussera.sale + promotion_type.xBSD.5 +
                          product_analytic_vertical.xGamingSpeaker + NPS + TV + Sponsorship + X.Affiliates + 
                          product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                          promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingMouse +
                          product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model5)

vif(game_Acess_model5)

# Removing TV as it has high p value and vif

game_Acess_model6 <- lm(tot_gmv~ product_analytic_vertical.xGamingAccessoryKit +
                          product_analytic_vertical.xMotionController + product_analytic_vertical.xGamingChargingStation + 
                          promotion_type.xChristmas...New.Year.Sale +
                          SEM + product_analytic_vertical.xJoystickGamingWheel + 
                          promotion_type.xDaussera.sale + promotion_type.xBSD.5 +
                          product_analytic_vertical.xGamingSpeaker + NPS + Sponsorship + X.Affiliates + 
                          product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                          promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingMouse +
                          product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model6)

vif(game_Acess_model6)

# Removing NPS and sponsorship as they have high vif and low significance


game_Acess_model7 <- lm(tot_gmv~ product_analytic_vertical.xGamingAccessoryKit +
                          product_analytic_vertical.xMotionController + product_analytic_vertical.xGamingChargingStation + 
                          promotion_type.xChristmas...New.Year.Sale +
                          SEM + product_analytic_vertical.xJoystickGamingWheel + 
                          promotion_type.xDaussera.sale + promotion_type.xBSD.5 +
                          product_analytic_vertical.xGamingSpeaker + X.Affiliates + 
                          product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                          promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingMouse +
                          product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model7)

vif(game_Acess_model7)

# Removing product_analytic_vertical.xMotionController and product_analytic_vertical.xGamingSpeaker

game_Acess_model8 <- lm(tot_gmv~ product_analytic_vertical.xGamingAccessoryKit +
                          product_analytic_vertical.xGamingChargingStation + 
                          promotion_type.xChristmas...New.Year.Sale +
                          SEM + product_analytic_vertical.xJoystickGamingWheel + 
                          promotion_type.xDaussera.sale + promotion_type.xBSD.5 +
                          X.Affiliates + 
                          product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                          promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingMouse +
                          product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model8)
vif(game_Acess_model8)

# Removing product_analytic_vertical.xGamingChargingStation and promotion_type.xChristmas...New.Year.Sale 

game_Acess_model9 <- lm(tot_gmv~ product_analytic_vertical.xGamingAccessoryKit +
                          SEM + product_analytic_vertical.xJoystickGamingWheel + 
                          promotion_type.xDaussera.sale + promotion_type.xBSD.5 +
                          X.Affiliates + 
                          product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                          promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingMouse +
                          product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model9)

vif(game_Acess_model9)

# Removing product_analytic_vertical.xJoystickGamingWheel

game_Acess_model10 <- lm(tot_gmv~ product_analytic_vertical.xGamingAccessoryKit +
                           SEM + 
                           promotion_type.xDaussera.sale + promotion_type.xBSD.5 +
                           X.Affiliates + 
                           product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                           promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingMouse +
                           product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model10)

vif(game_Acess_model10)

# Removing product_analytic_vertical.xGamingAccessoryKit

game_Acess_model11 <- lm(tot_gmv~
                           SEM + 
                           promotion_type.xDaussera.sale + promotion_type.xBSD.5 +
                           X.Affiliates + 
                           product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                           promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingMouse +
                           product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model11)

vif(game_Acess_model11)

#Remove SEM and promotion_type.xBSD.5
game_Acess_model12 <- lm(tot_gmv~ promotion_type.xDaussera.sale +
                           X.Affiliates + 
                           product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                           promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingMouse +
                           product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model12)
vif(game_Acess_model12)

#Remove X.Affiliates as it has high vif and p value
game_Acess_model13 <- lm(tot_gmv~ promotion_type.xDaussera.sale +
                           product_analytic_vertical.xGamingKeyboard + promotion_type.xIndependence.Sale +
                           promotion_type.xRakshabandhan.Sale + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingMouse +
                           product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model13)
vif(game_Acess_model13)

#Remove promotion_type.xIndependence.Sale + promotion_type.xRakshabandhan.Sale as it has high  p value
game_Acess_model14 <- lm(tot_gmv~ promotion_type.xDaussera.sale +
                           product_analytic_vertical.xGamingKeyboard +
                           product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingMouse +
                           product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model14)
vif(game_Acess_model14)

#Remove promotion_type.xDaussera.sale + product_analytic_vertical.xGamingKeyboard as it has high  p value
game_Acess_model15 <- lm(tot_gmv~  
                           product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingMouse +
                           product_analytic_vertical.xGamePad, data = train_game_Acess)
summary(game_Acess_model15)
vif(game_Acess_model15)

final_game_Acess_model <- game_Acess_model15
#Multiple R-squared:  0.679,	Adjusted R-squared:  0.67 

#------------------------------------------------------------------------------------------------------------------

#prediction on test data

game_Acess_prediction <- predict(final_game_Acess_model, test_game_Acess)
test_game_Acess$predicted_gmv <- game_Acess_prediction

game_r <- cor(test_game_Acess$tot_gmv, test_game_Acess$predicted_gmv)
game_rsquared <- game_r^2
game_rsquared
#R squared = 0.536

#____________________________________________________________________________________________________#
#Let us find out the elasticity
elasticity_game <- function(var) {
  x <- as.numeric(final_game_Acess_model$coefficients[var])
  return(x)
}

var_list_game <- list()

for(i in 2:length(final_game_Acess_model$coefficients)) {
  var_list_game[i-1] <- elasticity_game(names(final_game_Acess_model$coefficients)[i])
}

elasticity.outputs.game <- data.frame(names(final_game_Acess_model$coefficients[2:length(final_game_Acess_model$coefficients)]))
elasticity.outputs.game <- cbind(elasticity.outputs.game,do.call(rbind.data.frame, var_list_game))
colnames(elasticity.outputs.game) <- c("Variable","Elasticity")

elasticity.outputs.game$direction <- ifelse(elasticity.outputs.game$Elasticity > 0, "Positive", "Negative")

ggplot(data=elasticity.outputs.game, aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Gaming Accessory - Linear Model") +xlab("Variables")

#_____________________________________________________________________________________________________________#
game_lm_cv <- cv.lm(data = train_game_Acess , form.lm = formula(tot_gmv~
                                                                  product_analytic_vertical.xGamingHeadset +
                                                                  product_analytic_vertical.xGamingMouse +
                                                                  product_analytic_vertical.xGamePad), m= 10)
#overall ms = 0.306

#########################################################################################################
#################################### MULTIPLICATIVE MODELLING #########################################
#################### 1. PRODUCT SUB CATEGORY: HOME AUDIO ###########################
#Creating a back up of HomeAudio df
home_audio_mul <- HomeAudio
home_audio_mul$week_no <- NULL
home_audio_mul$Month <- NULL


summary(home_audio_mul)
str(home_audio_mul)


#We can only include numerical variables here as Log(0) is not defined; 
#To handle the Log(0) case,let us convert all zeroes from below original columns to 0.01
home_audio_mul$TV[which(home_audio_mul$TV == 0)] <- 0.01
home_audio_mul$Radio[which(home_audio_mul$Radio == 0)] <- 0.01
home_audio_mul$Other[which(home_audio_mul$Other == 0 )] <- 0.01
home_audio_mul$Content.Marketing[which(home_audio_mul$Content.Marketing == 0)] <- 0.01


#Taking log of the data for multiplicative modeling
home_audio_mul[,1:13] <- data.frame(sign(home_audio_mul[,1:13])*log(abs(home_audio_mul[,1:13])))

#Create train and test data
trainindices_home_mul= sample(1:nrow(home_audio_mul), 0.7*nrow(home_audio_mul))

train_home_mul = home_audio_mul[trainindices_home_mul,]
test_home_mul = home_audio_mul[-trainindices_home_mul,]

#Let us start building the model using backward selection first
mulhome_model1 <- lm(tot_gmv~., data = train_home_mul)
summary(mulhome_model1)
#Multiple R-squared:  0.795,	Adjusted R-squared:  0.774 

#Using stepAIC to estimate the model
mulhome_step <- stepAIC(mulhome_model1, direction = "both")
summary(mulhome_step)
vif(mulhome_step)

# using last step of AIC for finalisation of our next model
#keep all variables with - sign and also keep into account the varaibles from summary and vif
#Remove list_price as it has high vif
mulhome_model2 <- lm(tot_gmv~ TV + Digital + Sponsorship + Content.Marketing + Online.marketing +
                       X.Affiliates + Radio + Other + product_analytic_vertical.xBoomBox +
                       product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                       product_analytic_vertical.xDockingStation + product_analytic_vertical.xFMRadio + 
                       product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                       product_analytic_vertical.xSlingBox + product_analytic_vertical.xSoundMixer + 
                       promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion + 
                       promotion_type.xPacman, data = train_home_mul)
summary(mulhome_model2)
vif(mulhome_model2)

#Remove Radio as it has high vif
mulhome_model3 <- lm(tot_gmv~ TV + Digital + Sponsorship + Content.Marketing + Online.marketing +
                       X.Affiliates +  Other + product_analytic_vertical.xBoomBox +
                       product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                       product_analytic_vertical.xDockingStation + product_analytic_vertical.xFMRadio + 
                       product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                       product_analytic_vertical.xSlingBox + product_analytic_vertical.xSoundMixer + 
                       promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion + 
                       promotion_type.xPacman, data = train_home_mul)
summary(mulhome_model3)
vif(mulhome_model3)

#remove online.marketing as it has high vif
mulhome_model4 <- lm(tot_gmv~ TV + Digital + Sponsorship + Content.Marketing + 
                       X.Affiliates +  Other + product_analytic_vertical.xBoomBox +
                       product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                       product_analytic_vertical.xDockingStation + product_analytic_vertical.xFMRadio + 
                       product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                       product_analytic_vertical.xSlingBox + product_analytic_vertical.xSoundMixer + 
                       promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion + 
                       promotion_type.xPacman, data = train_home_mul)
summary(mulhome_model4)
vif(mulhome_model4)

#Remove X.Affiliates as it has high vif
mulhome_model5 <- lm(tot_gmv~ TV + Digital + Sponsorship + Content.Marketing + 
                       Other + product_analytic_vertical.xBoomBox +
                       product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                       product_analytic_vertical.xDockingStation + product_analytic_vertical.xFMRadio + 
                       product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                       product_analytic_vertical.xSlingBox + product_analytic_vertical.xSoundMixer + 
                       promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion + 
                       promotion_type.xPacman, data = train_home_mul)
summary(mulhome_model5)
vif(mulhome_model5)

#remove TV, Digital and Sponsorship as they have high vif and p value
mulhome_model6 <- lm(tot_gmv~ Content.Marketing + 
                       Other + product_analytic_vertical.xBoomBox +
                       product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                       product_analytic_vertical.xDockingStation + product_analytic_vertical.xFMRadio + 
                       product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                       product_analytic_vertical.xSlingBox + product_analytic_vertical.xSoundMixer + 
                       promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion + 
                       promotion_type.xPacman, data = train_home_mul)
summary(mulhome_model6)
vif(mulhome_model6)

#Even though vif is low for Other and Content.Marketing , they are highly insignificant
mulhome_model7 <- lm(tot_gmv~ product_analytic_vertical.xBoomBox +
                       product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                       product_analytic_vertical.xDockingStation + product_analytic_vertical.xFMRadio + 
                       product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                       product_analytic_vertical.xSlingBox + product_analytic_vertical.xSoundMixer + 
                       promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion + 
                       promotion_type.xPacman, data = train_home_mul)
summary(mulhome_model7)
vif(mulhome_model7)

#Remove promotion_type.xBig.Diwali.Sale and promotion_type.xChristmas...New.Year.Sale as it is insignificant
mulhome_model8 <- lm(tot_gmv~ product_analytic_vertical.xBoomBox +
                       product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                       product_analytic_vertical.xDockingStation + product_analytic_vertical.xFMRadio + 
                       product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                       product_analytic_vertical.xSlingBox + product_analytic_vertical.xSoundMixer + 
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion + 
                       promotion_type.xPacman, data = train_home_mul)
summary(mulhome_model8)
vif(mulhome_model8)

#Remove promotion_type.xPacman and product_analytic_vertical.xBoomBox as it is insignificant
mulhome_model9 <- lm(tot_gmv~ 
                       product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                       product_analytic_vertical.xDockingStation + product_analytic_vertical.xFMRadio + 
                       product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                       product_analytic_vertical.xSlingBox + product_analytic_vertical.xSoundMixer + 
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion , data = train_home_mul)
summary(mulhome_model9)
vif(mulhome_model9)

#Remove product_analytic_vertical.xHiFiSystem and promotion_type.xNo_promotion as it is insignificant
mulhome_model10 <- lm(tot_gmv~ product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                        product_analytic_vertical.xDockingStation + product_analytic_vertical.xFMRadio + 
                        product_analytic_vertical.xHomeAudioSpeaker + promotion_type.xDaussera.sale +
                        product_analytic_vertical.xSlingBox + product_analytic_vertical.xSoundMixer 
                      , data = train_home_mul)
summary(mulhome_model10)
vif(mulhome_model10)

#Remove product_analytic_vertical.xFMRadio as it is highly insignificant and has high vif
mulhome_model11 <- lm(tot_gmv~ product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                        product_analytic_vertical.xDockingStation +  
                        product_analytic_vertical.xHomeAudioSpeaker + promotion_type.xDaussera.sale +
                        product_analytic_vertical.xSlingBox + product_analytic_vertical.xSoundMixer,data = train_home_mul)
summary(mulhome_model11)
vif(mulhome_model11)

#Remove product_analytic_vertical.xSlingBox as it is highly insignificant
mulhome_model12 <- lm(tot_gmv~ product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                        product_analytic_vertical.xDockingStation +  
                        product_analytic_vertical.xHomeAudioSpeaker + promotion_type.xDaussera.sale +
                        product_analytic_vertical.xSoundMixer, data = train_home_mul)
summary(mulhome_model12)
vif(mulhome_model12)

#Remove product_analytic_vertical.xSoundMixer and product_analytic_vertical.xDJController  as it is highly insignificant
mulhome_model13 <- lm(tot_gmv~  product_analytic_vertical.xDock +
                        product_analytic_vertical.xDockingStation +  
                        product_analytic_vertical.xHomeAudioSpeaker + promotion_type.xDaussera.sale 
                      , data = train_home_mul)
summary(mulhome_model13)
vif(mulhome_model13)




final_model_mulhome <- mulhome_model13
#Multiple R-squared:  0.598,	Adjusted R-squared:  0.593 

#___________________________________________________________________________________________________________#
#Let us predict the r squared value on test data
predict_mulhome <- predict(final_model_mulhome, test_home_mul)
test_home_mul$predicted_gmv <- predict_mulhome

# Now, we need to test the r square between actual and predicted sales.
mulhome_r <- cor(test_home_mul$tot_gmv, test_home_mul$predicted_gmv)
mulhome_rsquared <- cor(test_home_mul$tot_gmv, test_home_mul$predicted_gmv)^2
mulhome_rsquared
#0.636

#____________________________________________________________________________________________________________________#

#Let us find the elasticity
elasticity <- function(var) {
  x <- as.numeric(final_model_mulhome$coefficients[var])
  return(x)
}

var_mulhome <- list()

for(i in 2:length(final_model_mulhome$coefficients)) {
  var_mulhome[i-1] <- elasticity(names(final_model_mulhome$coefficients)[i])
}

elasticity_mulhome <- data.frame(names(final_model_mulhome$coefficients[2:length(final_model_mulhome$coefficients)]))
elasticity_mulhome <- cbind(elasticity_mulhome,do.call(rbind.data.frame, var_mulhome))
colnames(elasticity_mulhome) <- c("Variable","Elasticity")

elasticity_mulhome$direction <- ifelse(elasticity_mulhome$Elasticity > 0, "Positive", "Negative")

ggplot(data=elasticity_mulhome, aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Home Audio - Multiplicative Model") +xlab("Variables")

#_________________________________________________________________________________________________________________#
mulhome_cv <- cv.lm(data = train_home_mul , form.lm = formula(tot_gmv~product_analytic_vertical.xDock +
                                                                product_analytic_vertical.xDockingStation +  
                                                                product_analytic_vertical.xHomeAudioSpeaker + promotion_type.xDaussera.sale),
                    m=10)
#ms = 1.37
#########################################################################################################
#################################### MULTIPLICATIVE MODELLING #########################################
#################### 2. PRODUCT SUB CATEGORY: CAMERA ACCESSORY ###########################
#Creating a back up of Camera Accessory df
cam_acc_mul <- CameraAccessory
cam_acc_mul$week_no <- NULL
cam_acc_mul$Month <- NULL


summary(cam_acc_mul)
str(cam_acc_mul)

#We can only include numerical variables here as Log(0) is not defined; 
#To handle the Log(0) case,let us convert all zeroes from below original columns to 0.01
cam_acc_mul$TV[which(cam_acc_mul$TV == 0)] <- 0.01
cam_acc_mul$Radio[which(cam_acc_mul$Radio == 0)] <- 0.01
cam_acc_mul$Other[which(cam_acc_mul$Other == 0 )] <- 0.01
cam_acc_mul$Content.Marketing[which(cam_acc_mul$Content.Marketing == 0)] <- 0.01


#Taking log of the data for multiplicative modeling
cam_acc_mul[,1:13] <- data.frame(sign(cam_acc_mul[,1:13])*log(abs(cam_acc_mul[,1:13])))

#Create train and test data
trainindices_cam_mul= sample(1:nrow(cam_acc_mul), 0.7*nrow(cam_acc_mul))

train_cam_mul = cam_acc_mul[trainindices_cam_mul,]
test_cam_mul = cam_acc_mul[-trainindices_cam_mul,]

#Let us start building the model using backward selection first
mulcam_model1 <- lm(tot_gmv~., data = train_cam_mul)
summary(mulcam_model1)
#Multiple R-squared:  0.823,	Adjusted R-squared:  0.81 

#Using stepAIC to estimate the model
mulcam_step <- stepAIC(mulcam_model1, direction = "both")
summary(mulcam_step)
vif(mulcam_step)

# using last step of AIC for finalisation of our next model, keep all variables with - sign
mulcam_model2 <- lm(tot_gmv~ discounted_mrp + product_analytic_vertical.xCameraBag +
                      promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                      promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                      promotion_type.xNo_promotion + promotion_type.xIndependence.Sale +
                      product_analytic_vertical.xLens + Content.Marketing + Online.marketing + SEM +
                      TV + X.Affiliates + Other + Radio + Sponsorship + product_analytic_vertical.xReflectorUmbrella +
                      product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                      product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                      product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                      product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                      product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                      product_analytic_vertical.xStrap + list_price + product_analytic_vertical.xCameraHousing +
                      product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                      product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                      product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model2)
vif(mulcam_model2)

#Remove online marketing as it is highly insignificant
mulcam_model3 <- lm(tot_gmv~ discounted_mrp + product_analytic_vertical.xCameraBag +
                      promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                      promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                      promotion_type.xNo_promotion + promotion_type.xIndependence.Sale +
                      product_analytic_vertical.xLens + Content.Marketing + SEM +
                      TV + X.Affiliates + Other + Radio + Sponsorship + product_analytic_vertical.xReflectorUmbrella +
                      product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                      product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                      product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                      product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                      product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                      product_analytic_vertical.xStrap + list_price + product_analytic_vertical.xCameraHousing +
                      product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                      product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                      product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model3)
vif(mulcam_model3)

#Remove Radio as it is highly insignificant
mulcam_model4 <- lm(tot_gmv~ discounted_mrp + product_analytic_vertical.xCameraBag +
                      promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                      promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                      promotion_type.xNo_promotion + promotion_type.xIndependence.Sale +
                      product_analytic_vertical.xLens + Content.Marketing + SEM +
                      TV + X.Affiliates + Other + Sponsorship + product_analytic_vertical.xReflectorUmbrella +
                      product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                      product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                      product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                      product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                      product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                      product_analytic_vertical.xStrap + list_price + product_analytic_vertical.xCameraHousing +
                      product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                      product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                      product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model4)
vif(mulcam_model4)

#Remove Sponsership as it is highly insignificant
mulcam_model5 <- lm(tot_gmv~ discounted_mrp + product_analytic_vertical.xCameraBag +
                      promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                      promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                      promotion_type.xNo_promotion + promotion_type.xIndependence.Sale +
                      product_analytic_vertical.xLens + Content.Marketing + SEM +
                      TV + X.Affiliates + Other + product_analytic_vertical.xReflectorUmbrella +
                      product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                      product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                      product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                      product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                      product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                      product_analytic_vertical.xStrap + list_price + product_analytic_vertical.xCameraHousing +
                      product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                      product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                      product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model5)
vif(mulcam_model5)

#Remove TV as it is highly insignificant
mulcam_model6 <- lm(tot_gmv~ discounted_mrp + product_analytic_vertical.xCameraBag +
                      promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                      promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                      promotion_type.xNo_promotion + promotion_type.xIndependence.Sale +
                      product_analytic_vertical.xLens + Content.Marketing + SEM +
                      X.Affiliates + Other + product_analytic_vertical.xReflectorUmbrella +
                      product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                      product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                      product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                      product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                      product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                      product_analytic_vertical.xStrap + list_price + product_analytic_vertical.xCameraHousing +
                      product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                      product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                      product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model6)
vif(mulcam_model6)

#Remove content marketing as it is highly insignificant
mulcam_model7 <- lm(tot_gmv~ discounted_mrp + product_analytic_vertical.xCameraBag +
                      promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                      promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                      promotion_type.xNo_promotion + promotion_type.xIndependence.Sale +
                      product_analytic_vertical.xLens + SEM +
                      X.Affiliates + Other + product_analytic_vertical.xReflectorUmbrella +
                      product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                      product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                      product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                      product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                      product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                      product_analytic_vertical.xStrap + list_price + product_analytic_vertical.xCameraHousing +
                      product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                      product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                      product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model7)
vif(mulcam_model7)


#Remove SEM as they are highly insignificant
mulcam_model8 <- lm(tot_gmv~ discounted_mrp + product_analytic_vertical.xCameraBag +
                      promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                      promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                      promotion_type.xNo_promotion + promotion_type.xIndependence.Sale +
                      product_analytic_vertical.xLens + 
                      X.Affiliates + Other + product_analytic_vertical.xReflectorUmbrella +
                      product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                      product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                      product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                      product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                      product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                      product_analytic_vertical.xStrap + list_price + product_analytic_vertical.xCameraHousing +
                      product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                      product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                      product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model8)
vif(mulcam_model8)

#Remove other as they are highly insignificant
mulcam_model9 <- lm(tot_gmv~ discounted_mrp + product_analytic_vertical.xCameraBag +
                      promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                      promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                      promotion_type.xNo_promotion + promotion_type.xIndependence.Sale +
                      product_analytic_vertical.xLens + 
                      X.Affiliates + product_analytic_vertical.xReflectorUmbrella +
                      product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                      product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                      product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                      product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                      product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                      product_analytic_vertical.xStrap + list_price + product_analytic_vertical.xCameraHousing +
                      product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                      product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                      product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model9)
vif(mulcam_model9)

#Remove No promotion as they are highly insignificant
mulcam_model10 <- lm(tot_gmv~ discounted_mrp + product_analytic_vertical.xCameraBag +
                       promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale +
                       promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                       promotion_type.xIndependence.Sale +
                       product_analytic_vertical.xLens + 
                       X.Affiliates + product_analytic_vertical.xReflectorUmbrella +
                       product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                       product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                       product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                       product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                       product_analytic_vertical.xStrap + list_price + product_analytic_vertical.xCameraHousing +
                       product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                       product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model10)
vif(mulcam_model10)

#Remove product_analytic_vertical.xCameraBag +promotion_type.xBig.Diwali.Sale + promotion_type.xChristmas...New.Year.Sale as they are highly insignificant
mulcam_model11 <- lm(tot_gmv~ discounted_mrp + 
                       promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                       promotion_type.xIndependence.Sale +
                       product_analytic_vertical.xLens + 
                       X.Affiliates + product_analytic_vertical.xReflectorUmbrella +
                       product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                       product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                       product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                       product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                       product_analytic_vertical.xStrap + list_price + product_analytic_vertical.xCameraHousing +
                       product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                       product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model11)
vif(mulcam_model11)

#Remove discounted mrp as they are highly insignificant
mulcam_model12 <- lm(tot_gmv~  
                       promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                       promotion_type.xIndependence.Sale +
                       product_analytic_vertical.xLens + 
                       X.Affiliates + product_analytic_vertical.xReflectorUmbrella +
                       product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                       product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                       product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                       product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                       product_analytic_vertical.xStrap + list_price + product_analytic_vertical.xCameraHousing +
                       product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                       product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model12)
vif(mulcam_model12)


#Remove list price as they are highly insignificant
mulcam_model13 <- lm(tot_gmv~  
                       promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                       promotion_type.xIndependence.Sale +
                       product_analytic_vertical.xLens + 
                       X.Affiliates + product_analytic_vertical.xReflectorUmbrella +
                       product_analytic_vertical.xCameraTripod + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter +
                       product_analytic_vertical.xCameraBattery + product_analytic_vertical.xFlashShoeAdapter +
                       product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                       product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraHousing +
                       product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                       product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model13)
vif(mulcam_model13)

#Remove product_analytic_vertical.xCameraTripod + product_analytic_vertical.xFlash + product_analytic_vertical.xTeleconverter + product_analytic_vertical.xCameraBattery as they are highly insignificant
mulcam_model14 <- lm(tot_gmv~  
                       promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                       promotion_type.xIndependence.Sale +
                       product_analytic_vertical.xLens + 
                       X.Affiliates + product_analytic_vertical.xReflectorUmbrella +
                       product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xFlashShoeAdapter +
                       product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                       product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraHousing +
                       product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                       product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model14)
vif(mulcam_model14)

#Remove dussera sales  as they are highly insignificant
mulcam_model15 <- lm(tot_gmv~  
                       promotion_type.xRakshabandhan.Sale + 
                       promotion_type.xIndependence.Sale +
                       product_analytic_vertical.xLens + 
                       X.Affiliates + product_analytic_vertical.xReflectorUmbrella +
                       product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xFlashShoeAdapter +
                       product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                       product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xTelescope + 
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraHousing +
                       product_analytic_vertical.xCameraMount + product_analytic_vertical.xCameraMicrophone +
                       product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model15)
vif(mulcam_model15)
#even though the variables are significant, they have high vif. 
#so let us remove product_analytic_vertical.xLens + product_analytic_vertical.xTelescope + product_analytic_vertical.xTelescope 

mulcam_model16 <- lm(tot_gmv~  
                       promotion_type.xRakshabandhan.Sale + 
                       promotion_type.xIndependence.Sale +
                       
                       X.Affiliates + product_analytic_vertical.xReflectorUmbrella +
                       product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xFlashShoeAdapter +
                       product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                       product_analytic_vertical.xCameraAccessory +  
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraHousing +
                       product_analytic_vertical.xTelescope +product_analytic_vertical.xCameraMicrophone +
                       product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model16)
vif(mulcam_model16)

#Remove Rakshabandhan  as they are highly insignificant
mulcam_model17 <- lm(tot_gmv~  
                       
                       promotion_type.xIndependence.Sale +
                       
                       X.Affiliates + product_analytic_vertical.xReflectorUmbrella +
                       product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xFlashShoeAdapter +
                       product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraLEDLight +
                       product_analytic_vertical.xCameraAccessory +  
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraHousing +
                       product_analytic_vertical.xTelescope +product_analytic_vertical.xCameraMicrophone +
                       product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraBatteryGrip, data = train_cam_mul)

summary(mulcam_model17)
vif(mulcam_model17)

#remove product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xCameraBatteryGrip
#product_analytic_vertical.xTelescope + product_analytic_vertical.xStrap + product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraLEDLight 
# independence sales and adding back list price , dussara sale
mulcam_model18 <- lm(tot_gmv~  
                       
                       list_price + promotion_type.xDaussera.sale +
                       
                       X.Affiliates + product_analytic_vertical.xReflectorUmbrella +
                       
                       product_analytic_vertical.xFlashShoeAdapter +
                       
                       
                       product_analytic_vertical.xCameraHousing +
                       product_analytic_vertical.xCameraMicrophone +
                       product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                       product_analytic_vertical.xExtensionTube, data = train_cam_mul)

summary(mulcam_model18)
vif(mulcam_model18)

final_model_mulcam <- mulcam_model18
#for model17, Multiple R-squared:  0.439,	Adjusted R-squared:  0.43 

#Let us predict the r squared value on test data
predict_mulcam <- predict(final_model_mulcam, test_cam_mul)
test_cam_mul$predicted_gmv <- predict_mulcam

# Now, we need to test the r square between actual and predicted sales.
mulcam_r <- cor(test_cam_mul$tot_gmv, test_cam_mul$predicted_gmv)
mulcam_rsquared <- cor(test_cam_mul$tot_gmv, test_cam_mul$predicted_gmv)^2
mulcam_rsquared
#0.36

#Let us find the elasticity
elasticity <- function(var) {
  x <- as.numeric(final_model_mulcam$coefficients[var])
  return(x)
}

var_mulcam <- list()

for(i in 2:length(final_model_mulcam$coefficients)) {
  var_mulcam[i-1] <- elasticity(names(final_model_mulcam$coefficients)[i])
}

elasticity_mulcam <- data.frame(names(final_model_mulcam$coefficients[2:length(final_model_mulcam$coefficients)]))
elasticity_mulcam <- cbind(elasticity_mulcam,do.call(rbind.data.frame, var_mulcam))
colnames(elasticity_mulcam) <- c("Variable","Elasticity")

elasticity_mulcam$direction <- ifelse(elasticity_mulcam$Elasticity > 0, "Positive", "Negative")

ggplot(data=elasticity_mulcam, aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Camera Accessory - Multiplicative Model") +xlab("Variables")

#CROSS VALIDATION
mulcam_cv <- cv.lm(data = train_cam_mul , form.lm = formula(tot_gmv~ 
                                                              list_price + promotion_type.xDaussera.sale +
                                                              X.Affiliates + product_analytic_vertical.xReflectorUmbrella +
                                                              product_analytic_vertical.xFlashShoeAdapter+
                                                              product_analytic_vertical.xCameraHousing +
                                                              product_analytic_vertical.xCameraMicrophone +
                                                              product_analytic_vertical.xSoftbox  + product_analytic_vertical.xCameraEyeCup + 
                                                              product_analytic_vertical.xExtensionTube),m =10)
#ms 2.58
#################################### MULTIPLICATIVE MODELLING #########################################
#################### 3. PRODUCT SUB CATEGORY: GAMING ACCESSORY ###########################
#Creating a back up of Gaming Accessory df
game_acc_mul <- GamingAccessory
game_acc_mul$week_no <- NULL
game_acc_mul$Month <- NULL


summary(game_acc_mul)
str(game_acc_mul)

#We can only include numerical variables here as Log(0) is not defined; 
#To handle the Log(0) case,let us convert all zeroes from below original columns to 0.01
game_acc_mul$TV[which(game_acc_mul$TV == 0)] <- 0.01
game_acc_mul$Radio[which(game_acc_mul$Radio == 0)] <- 0.01
game_acc_mul$Other[which(game_acc_mul$Other == 0 )] <- 0.01
game_acc_mul$Content.Marketing[which(game_acc_mul$Content.Marketing == 0)] <- 0.01


#Taking log of the data for multiplicative modeling
game_acc_mul[,1:13] <- data.frame(sign(game_acc_mul[,1:13])*log(abs(game_acc_mul[,1:13])))

#Create train and test data
trainindices_game_mul= sample(1:nrow(game_acc_mul), 0.7*nrow(game_acc_mul))

train_game_mul = game_acc_mul[trainindices_game_mul,]
test_game_mul = game_acc_mul[-trainindices_game_mul,]

#Let us start building the model using backward selection first
mulgame_model1 <- lm(tot_gmv~., data = train_game_mul)
summary(mulgame_model1)
#Multiple R-squared:  0.787,	Adjusted R-squared:  0.77 

#Using stepAIC to estimate the model
mulgame_step <- stepAIC(mulgame_model1, direction = "both")
summary(mulgame_step)
vif(mulgame_step)

# using last step of AIC for finalisation of our next model, keep all variables with - sign
#remove Digital as it is not significant
mulgame_model2 <- lm(tot_gmv~ list_price + discounted_mrp + TV +Sponsorship + Content.Marketing + Online.marketing +
                       X.Affiliates + SEM + Radio + Other + product_analytic_vertical.xCoolingPad +
                       product_analytic_vertical.xGameControlMount + product_analytic_vertical.xGamePad +
                       product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter
                     + product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingGun +
                       product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                       product_analytic_vertical.xJoystickGamingWheel + product_analytic_vertical.xMotionController +
                       promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 +
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion +
                       promotion_type.xRakshabandhan.Sale, data = train_game_mul)
summary(mulgame_model2)
vif(mulgame_model2)

#Remove discounted_mrp  as it not significant 
mulgame_model3 <- lm(tot_gmv~ list_price + TV + Sponsorship + Content.Marketing + Online.marketing +
                       X.Affiliates + SEM + Radio + Other + product_analytic_vertical.xCoolingPad +
                       product_analytic_vertical.xGameControlMount + product_analytic_vertical.xGamePad +
                       product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter
                     + product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingGun +
                       product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                       product_analytic_vertical.xJoystickGamingWheel + product_analytic_vertical.xMotionController +
                       promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 +
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion +
                       promotion_type.xRakshabandhan.Sale, data = train_game_mul)
summary(mulgame_model3)
vif(mulgame_model3)

#Remove product_analytic_vertical.xGamingAdapter as it has high p-value
mulgame_model4 <- lm(tot_gmv~ list_price + TV + Sponsorship + Content.Marketing + Online.marketing +
                       X.Affiliates + SEM + Radio + Other + product_analytic_vertical.xCoolingPad +
                       product_analytic_vertical.xGameControlMount + product_analytic_vertical.xGamePad +
                       product_analytic_vertical.xGamingAccessoryKit + 
                       product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingGun +
                       product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                       product_analytic_vertical.xJoystickGamingWheel + product_analytic_vertical.xMotionController +
                       promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 +
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion +
                       promotion_type.xRakshabandhan.Sale, data = train_game_mul)
summary(mulgame_model4)
vif(mulgame_model4)

#Remove product_analytic_vertical.xJoystickGamingWheel + product_analytic_vertical.xMotionController as they high  p-value
mulgame_model5 <- lm(tot_gmv~ list_price + TV + Sponsorship + Content.Marketing + Online.marketing +
                       X.Affiliates + SEM + Radio + Other + product_analytic_vertical.xCoolingPad +
                       product_analytic_vertical.xGameControlMount + product_analytic_vertical.xGamePad +
                       product_analytic_vertical.xGamingAccessoryKit + 
                       product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingGun +
                       product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                       
                       promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 +
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion +
                       promotion_type.xRakshabandhan.Sale, data = train_game_mul)
summary(mulgame_model5)
vif(mulgame_model5)

#Remove promotion_type.xBSD.5 + promotion_type.xRakshabandhan.Sale as it has high  p-value
mulgame_model6 <- lm(tot_gmv~ list_price + TV + Sponsorship + Content.Marketing + Online.marketing +
                       X.Affiliates + SEM + Radio + Other + product_analytic_vertical.xCoolingPad +
                       product_analytic_vertical.xGameControlMount + product_analytic_vertical.xGamePad +
                       product_analytic_vertical.xGamingAccessoryKit + 
                       product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingGun +
                       product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                       
                       promotion_type.xBig.Diwali.Sale + 
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion
                     , data = train_game_mul)
summary(mulgame_model6)
vif(mulgame_model6)

#Remove Online.marketing as it has high  vif
mulgame_model7 <- lm(tot_gmv~ list_price + TV + Sponsorship + Content.Marketing + 
                       X.Affiliates + SEM + Radio + Other + product_analytic_vertical.xCoolingPad +
                       product_analytic_vertical.xGameControlMount + product_analytic_vertical.xGamePad +
                       product_analytic_vertical.xGamingAccessoryKit + 
                       product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingGun +
                       product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                       
                       promotion_type.xBig.Diwali.Sale + 
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion
                     , data = train_game_mul)
summary(mulgame_model7)
vif(mulgame_model7)

#Remove Sponsorship + Content.Marketing + as it has high p value
mulgame_model8 <- lm(tot_gmv~ list_price + TV +  
                       X.Affiliates + SEM + Radio + Other + product_analytic_vertical.xCoolingPad +
                       product_analytic_vertical.xGameControlMount + product_analytic_vertical.xGamePad +
                       product_analytic_vertical.xGamingAccessoryKit + 
                       product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingGun +
                       product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                       
                       promotion_type.xBig.Diwali.Sale + 
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion
                     , data = train_game_mul)
summary(mulgame_model8)
vif(mulgame_model8)

#Remove X.Affiliates as it has high p value and vif
mulgame_model9 <- lm(tot_gmv~ list_price + TV +  
                       SEM + Radio + Other + product_analytic_vertical.xCoolingPad +
                       product_analytic_vertical.xGameControlMount + product_analytic_vertical.xGamePad +
                       product_analytic_vertical.xGamingAccessoryKit + 
                       product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingGun +
                       product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                       
                       promotion_type.xBig.Diwali.Sale + 
                       promotion_type.xDaussera.sale + promotion_type.xNo_promotion
                     , data = train_game_mul)
summary(mulgame_model9)
vif(mulgame_model9)

#Remove promotion_type.xBig.Diwali.Sale + promotion_type.xDaussera.sale + promotion_type.xNo_promotion as it has high p-value
mulgame_model10 <- lm(tot_gmv~ list_price + TV +  
                        SEM + Radio + Other + product_analytic_vertical.xCoolingPad +
                        product_analytic_vertical.xGameControlMount + product_analytic_vertical.xGamePad +
                        product_analytic_vertical.xGamingAccessoryKit + 
                        product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingGun +
                        product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                        product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker
                      , data = train_game_mul)
summary(mulgame_model10)
vif(mulgame_model10)

#Remove  product_analytic_vertical.xGameControlMount as it has high p-value
mulgame_model11 <- lm(tot_gmv~ list_price + TV +  
                        SEM + Radio + Other + product_analytic_vertical.xCoolingPad +
                        product_analytic_vertical.xGamePad +
                        product_analytic_vertical.xGamingAccessoryKit + 
                        product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingGun +
                        product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                        product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker
                      , data = train_game_mul)
summary(mulgame_model11)
vif(mulgame_model11)

#Remove  Radio + Other +  as it has high vif
mulgame_model12 <- lm(tot_gmv~ list_price + TV +  
                        SEM + product_analytic_vertical.xCoolingPad +
                        product_analytic_vertical.xGamePad +
                        product_analytic_vertical.xGamingAccessoryKit + 
                        product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingGun +
                        product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                        product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker
                      , data = train_game_mul)
summary(mulgame_model12)
vif(mulgame_model12)

#Remove  SEM +product_analytic_vertical.xGamingGun + product_analytic_vertical.xGamingSpeaker 
# + product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xCoolingPad as it has high p-value
mulgame_model13 <- lm(tot_gmv~ list_price + TV +  
                        
                        product_analytic_vertical.xGamePad +
                        product_analytic_vertical.xGamingAccessoryKit + 
                        
                        product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard +
                        product_analytic_vertical.xGamingMouse 
                      , data = train_game_mul)
summary(mulgame_model13)
vif(mulgame_model13)

#Remove  product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingKeyboard as it has high p-value
mulgame_model14 <- lm(tot_gmv~ list_price + TV + product_analytic_vertical.xGamePad +
                        product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingMouse,data = train_game_mul)
summary(mulgame_model14)
vif(mulgame_model14)

final_model_mulgame <- mulgame_model14
#Multiple R-squared:  0.407,	Adjusted R-squared:  0.401 

#Let us predict the r squared value on test data
predict_mulgame <- predict(final_model_mulgame, test_game_mul)
test_game_mul$predicted_gmv <- predict_mulgame

# Now, we need to test the r square between actual and predicted sales.
mulgame_r <- cor(test_game_mul$tot_gmv, test_game_mul$predicted_gmv)
mulgame_rsquared <- cor(test_game_mul$tot_gmv, test_game_mul$predicted_gmv)^2
mulgame_rsquared
#0.377

#Let us find the elasticity
elasticity <- function(var) {
  x <- as.numeric(final_model_mulgame$coefficients[var])
  return(x)
}

var_mulgame <- list()

for(i in 2:length(final_model_mulgame$coefficients)) {
  var_mulgame[i-1] <- elasticity(names(final_model_mulgame$coefficients)[i])
}

elasticity_mulgame <- data.frame(names(final_model_mulgame$coefficients[2:length(final_model_mulgame$coefficients)]))
elasticity_mulgame <- cbind(elasticity_mulgame,do.call(rbind.data.frame, var_mulgame))
colnames(elasticity_mulgame) <- c("Variable","Elasticity")

elasticity_mulgame$direction <- ifelse(elasticity_mulgame$Elasticity > 0, "Positive", "Negative")

ggplot(data=elasticity_mulgame, aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Gaming Accessory - Multiplicative Model") +xlab("Variables")

mulgame_cv <- cv.lm(data = train_game_mul , form.lm = formula(tot_gmv~
                                                                list_price + TV + product_analytic_vertical.xGamePad +
                                                                product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingMouse),m=10)
#ms= 2.28
####################################DISTRIBUTED LAG MODELLING #########################################
#Data creation for lag model

#add sales for last 3 week
weekly_consumer_ad_data_with_lag <- weekly_consumer_adv_data %>% arrange ( week_no) %>% group_by(product_analytic_sub_category ,product_analytic_vertical) %>%  mutate(gmv_lag_1 = lag(tot_gmv, 1))  %>%  mutate(gmv_lag_2 = lag(tot_gmv, 2)) %>%  mutate(gmv_lag_3 = lag(tot_gmv, 3)) 

#add change in sales for last 3 weeks
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% arrange ( week_no) %>% group_by(product_analytic_sub_category ,product_analytic_vertical ) %>%  mutate(gmv_change_from_w1 = (tot_gmv-lag(tot_gmv, 1))/tot_gmv) %>%  mutate(gmv_change_from_w2 = (tot_gmv-lag(tot_gmv, 2))/tot_gmv) %>%  mutate(gmv_change_from_w3 = (tot_gmv-lag(tot_gmv, 3))/tot_gmv) 

#add list price for last 3 weeks
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% arrange ( week_no) %>% group_by(product_analytic_sub_category,product_analytic_vertical ) %>%  mutate(list_price_lag_1 = lag(list_price, 1))  %>%  mutate(list_price_lag_2 = lag(list_price, 2)) %>%  mutate(list_price_lag_3 = lag(list_price, 3)) 

#add list price change  for last 3 weeks
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% arrange ( week_no) %>% group_by(product_analytic_sub_category,product_analytic_vertical ) %>%  mutate(price_change_from_w1 = (list_price-lag(list_price, 1))/list_price) %>%  mutate(list_price_change_from_w2 = (list_price-lag(list_price, 2))/list_price) %>%  mutate(list_price_change_from_w3 = (list_price-lag(list_price, 3))/list_price)

#add TV ad stock, 60% effect of current week is propagating to next week 
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% arrange ( week_no) %>% group_by(product_analytic_sub_category,product_analytic_vertical ) %>%  mutate(tv_ad_stock = TV+ if_else ( is.na (lag(TV, 1)*.6),0, lag(TV, 1)*.6) + if_else ( is.na (lag(TV, 2)*.36),0, lag(TV, 2)*.36) + if_else ( is.na (lag(TV, 3)*.22),0, lag(TV, 3)*.22) + if_else ( is.na (lag(TV, 4)*.13),0, lag(TV, 4)*.13)  + if_else ( is.na (lag(TV, 5)*.07),0, lag(TV, 5)*.07)  + if_else ( is.na (lag(TV, 6)*.05),0, lag(TV, 6)*.05) ) 

#add Digital ad stock, 20% effect of current week is propagating to next week
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% arrange ( week_no) %>% group_by(product_analytic_sub_category,product_analytic_vertical ) %>%  mutate(dig_ad_stock = Digital+ if_else ( is.na (lag(Digital, 1)*.2),0, lag(Digital, 1)*.2) + if_else ( is.na (lag(Digital, 2)*.04),0, lag(Digital, 2)*.04)   )

#add sponsorship ad stock, 20% effect of current week is propagating to next week
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% arrange ( week_no) %>% group_by(product_analytic_sub_category,product_analytic_vertical ) %>%  mutate(spon_ad_stock = Sponsorship+ if_else ( is.na (lag(Sponsorship, 1)*.2),0, lag(Sponsorship, 1)*.2) + if_else ( is.na (lag(Sponsorship, 2)*.04),0, lag(Sponsorship, 2)*.04)   )  

#add content marketing ad stock, 20% effect of current week is propagating to next week
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% arrange ( week_no) %>% group_by(product_analytic_sub_category,product_analytic_vertical ) %>%  mutate(content_ad_stock = Content.Marketing+ if_else ( is.na (lag(Content.Marketing, 1)*.2),0, lag(Content.Marketing, 1)*.2) + if_else ( is.na (lag(Content.Marketing, 2)*.04),0, lag(Content.Marketing, 2)*.04)   ) 

#add online marketing ad stock, 20% effect of current week is propagating to next week
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% arrange ( week_no) %>% group_by(product_analytic_sub_category,product_analytic_vertical ) %>%  mutate(online_ad_stock = Online.marketing+ if_else ( is.na (lag(Online.marketing, 1)*.2),0, lag(Online.marketing, 1)*.2) + if_else ( is.na (lag(Online.marketing, 2)*.04),0, lag(Online.marketing, 2)*.04)   )

#add Radio ad stock, 20% effect of current week is propagating to next week
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% arrange ( week_no) %>% group_by(product_analytic_sub_category,product_analytic_vertical ) %>%  mutate(radio_ad_stock = Radio+ if_else ( is.na (lag(SEM, 1)*.2),0, lag(Radio, 1)*.2) + if_else ( is.na (lag(Radio, 2)*.04),0, lag(Radio, 2)*.04)   )

#add SEM ad stock 
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% arrange ( week_no) %>% group_by(product_analytic_sub_category,product_analytic_vertical ) %>%  mutate(sem_ad_stock = SEM+ if_else ( is.na (lag(SEM, 1)*.2),0, lag(SEM, 1)*.2) + if_else ( is.na (lag(SEM, 2)*.04),0, lag(SEM, 2)*.04)   )

#add Affiliate  ad stock 
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% arrange ( week_no) %>% group_by(product_analytic_sub_category,product_analytic_vertical ) %>%  mutate(affiliate_ad_stock = X.Affiliates+ if_else ( is.na (lag(X.Affiliates, 1)*.2),0, lag(X.Affiliates, 1)*.2) + if_else ( is.na (lag(X.Affiliates, 2)*.04),0, lag(X.Affiliates, 2)*.04)   )

#Filter out CameraAccessory, GamingAccessory and  HomeAudio sub category
weekly_consumer_ad_data_with_lag <- weekly_consumer_ad_data_with_lag %>% filter ( product_analytic_sub_category %in% c("CameraAccessory", "GamingAccessory", "HomeAudio"))

weekly_consumer_ad_data_with_lag <- as.data.frame(weekly_consumer_ad_data_with_lag)

#Convert character variables in factors
weekly_consumer_ad_data_with_lag_chr <- weekly_consumer_ad_data_with_lag[,c(5,32,34)]
weekly_consumer_ad_data_with_lag_chr_fact <- data.frame(sapply(weekly_consumer_ad_data_with_lag_chr, function(x) factor(x)))
str(weekly_consumer_ad_data_with_lag_chr_fact)

#creating dummy variables for the above attributes
dummies_sales<- data.frame(sapply(weekly_consumer_ad_data_with_lag_chr_fact, 
                                  function(x) data.frame(model.matrix(~x-1,data =weekly_consumer_ad_data_with_lag_chr_fact))[,-1]))


#Combine dummies with other varaiables to create master data set 
weekly_consumer_ad_data_with_lag_overall <- cbind ( weekly_consumer_ad_data_with_lag[, -c(5,32,34)], dummies_sales ) 

cor_var <- cor ( weekly_consumer_ad_data_with_lag_overall[-4])
View(cor_var)

#Let us remove these variables since these are highly corelated with sales 
weekly_consumer_ad_data_with_lag_overall$tot_week <- NULL 
weekly_consumer_ad_data_with_lag_overall$total_row <- NULL
weekly_consumer_ad_data_with_lag_overall$avg_mrp <- NULL
weekly_consumer_ad_data_with_lag_overall$avg_price <- NULL
weekly_consumer_ad_data_with_lag_overall$tot_units <- NULL
weekly_consumer_ad_data_with_lag_overall$no_of_orders <- NULL
weekly_consumer_ad_data_with_lag_overall$tot_product_mrp <- NULL
weekly_consumer_ad_data_with_lag_overall$avg_gmv <- NULL
weekly_consumer_ad_data_with_lag_overall$value_per_visitor <- NULL
weekly_consumer_ad_data_with_lag_overall$Year <- NULL
weekly_consumer_ad_data_with_lag_overall$no_of_customer <- NULL
weekly_consumer_ad_data_with_lag_overall$delayed_delivery_cnt <- NULL
weekly_consumer_ad_data_with_lag_overall$early_delivery_cnt <- NULL
weekly_consumer_ad_data_with_lag_overall$onetime_delivery_cnt <- NULL
weekly_consumer_ad_data_with_lag_overall$cod_cnt <- NULL
weekly_consumer_ad_data_with_lag_overall$prepaid_cnt <- NULL

#Create dataset for each sub category
weekly_consumer_ad_lag_camera <- filter ( weekly_consumer_ad_data_with_lag_overall ,weekly_consumer_ad_data_with_lag_overall$product_analytic_sub_category %in% c("CameraAccessory")) 
weekly_consumer_ad_lag_camera$product_analytic_sub_category <- NULL

weekly_consumer_ad_lag_game <- filter ( weekly_consumer_ad_data_with_lag_overall ,weekly_consumer_ad_data_with_lag_overall$product_analytic_sub_category %in% c("GamingAccessory")) 
weekly_consumer_ad_lag_game$product_analytic_sub_category <- NULL

weekly_consumer_ad_lag_home <- filter ( weekly_consumer_ad_data_with_lag_overall ,weekly_consumer_ad_data_with_lag_overall$product_analytic_sub_category %in% c("HomeAudio")) 
weekly_consumer_ad_lag_home$product_analytic_sub_category <- NULL

#Start building models for each sub category

####################################DISTRIBUTED LAG MODELLING #########################################
#################### 1. PRODUCT SUB CATEGORY: HOME AUDIO ###########################
weekly_consumer_ad_lag_home1 <- weekly_consumer_ad_lag_home
weekly_consumer_ad_lag_home <- na.omit(weekly_consumer_ad_lag_home)

weekly_consumer_ad_lag_home [,c(1:35)] <- scale(weekly_consumer_ad_lag_home [,c(1:35)])


set.seed(100)


trainindices= sample(1:nrow(weekly_consumer_ad_lag_home), 0.7*nrow(weekly_consumer_ad_lag_home))
#Generate the train data set
train_home = weekly_consumer_ad_lag_home[trainindices,]

#Similarly store the rest of the observations into an object "test".
test_home = weekly_consumer_ad_lag_home[-trainindices,]


home_model1 <- lm(tot_gmv~. , data = train_home)
summary(home_model1)


step_home_model1 <- stepAIC(home_model1, direction = "both")
summary(step_home_model1)
vif(step_home_model1)

#Remove online_ad_stock due to high vif and high insignificance 
step_home_model2 <- lm( tot_gmv ~ week_no + Digital + Content.Marketing + 
                          Online.marketing + X.Affiliates + Radio + discounted_mrp + 
                          gmv_lag_3 + list_price_change_from_w3 + dig_ad_stock + content_ad_stock + 
                          radio_ad_stock + affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                          product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                          product_analytic_vertical.xHomeAudioSpeaker  + 
                          promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                          promotion_type.xNo_promotion, data = train_home ) 


summary(step_home_model2)
vif(step_home_model2)


# Removed content_ad_stock due to high vif 
step_home_model3 <- lm(tot_gmv ~ week_no + Digital + Content.Marketing + 
                         Online.marketing + X.Affiliates + Radio + discounted_mrp + 
                         gmv_lag_3 + list_price_change_from_w3 + dig_ad_stock  + 
                         radio_ad_stock + affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                         product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                         product_analytic_vertical.xHomeAudioSpeaker  + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                         promotion_type.xNo_promotion, data = train_home ) 


summary(step_home_model3)
vif(step_home_model3)


# Removed X.Affiliates due to high vif 
step_home_model4 <- lm(tot_gmv ~ week_no + Digital + Content.Marketing + 
                         Online.marketing  + Radio + discounted_mrp + 
                         gmv_lag_3 + list_price_change_from_w3 + dig_ad_stock  + 
                         radio_ad_stock + affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                         product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                         product_analytic_vertical.xHomeAudioSpeaker  + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                         promotion_type.xNo_promotion, data = train_home ) 


summary(step_home_model4)
vif(step_home_model4)


# Removed dig_ad_stock due to high vif 
step_home_model5 <- lm(tot_gmv ~ week_no + Digital + Content.Marketing + 
                         Online.marketing  + Radio + discounted_mrp + 
                         gmv_lag_3 + list_price_change_from_w3   + 
                         radio_ad_stock + affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                         product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                         product_analytic_vertical.xHomeAudioSpeaker  + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                         promotion_type.xNo_promotion, data = train_home ) 


summary(step_home_model5)
vif(step_home_model5)



# Removed  radio_ad_stock due to high vif 
step_home_model6 <- lm(tot_gmv ~ week_no + Digital + Content.Marketing + 
                         Online.marketing  + Radio + discounted_mrp + 
                         gmv_lag_3 + list_price_change_from_w3   + 
                         affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                         product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                         product_analytic_vertical.xHomeAudioSpeaker  + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                         promotion_type.xNo_promotion, data = train_home) 


summary(step_home_model6)
vif(step_home_model6)


# Removed Online.marketing due to high vif 
step_home_model7 <- lm(tot_gmv ~ week_no + Digital + Content.Marketing + 
                         Radio + discounted_mrp + 
                         gmv_lag_3 + list_price_change_from_w3   + 
                         affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                         product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                         product_analytic_vertical.xHomeAudioSpeaker  + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                         promotion_type.xNo_promotion, data = train_home ) 


summary(step_home_model7)
vif(step_home_model7)


# Removed Content.Marketing due to high vif 
step_home_model8 <- lm(tot_gmv ~ week_no + Digital  + 
                         Radio + discounted_mrp + 
                         gmv_lag_3 + list_price_change_from_w3   + 
                         affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                         product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                         product_analytic_vertical.xHomeAudioSpeaker  + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                         promotion_type.xNo_promotion, data = train_home ) 


summary(step_home_model8)
vif(step_home_model8)


# Removed promotion_type.xChristmas...New.Year.Sale due to high P 
step_home_model9 <- lm(tot_gmv ~ week_no + Digital  + 
                         Radio + discounted_mrp + 
                         gmv_lag_3 + list_price_change_from_w3   + 
                         affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                         product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                         product_analytic_vertical.xHomeAudioSpeaker  + 
                         promotion_type.xDaussera.sale + 
                         promotion_type.xNo_promotion, data = train_home ) 


summary(step_home_model9)
vif(step_home_model9)


# Removed gmv_lag_3 due to high P 
step_home_model10 <- lm(tot_gmv ~ week_no + Digital  + 
                          Radio + discounted_mrp + 
                          list_price_change_from_w3   + 
                          affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                          product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                          product_analytic_vertical.xHomeAudioSpeaker  + 
                          promotion_type.xDaussera.sale + 
                          promotion_type.xNo_promotion, data = train_home ) 


summary(step_home_model10)
vif(step_home_model10)




# Removed Radio due to high P 
step_home_model11 <- lm(tot_gmv ~ week_no + Digital  + 
                          discounted_mrp + 
                          list_price_change_from_w3   + 
                          affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                          product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                          product_analytic_vertical.xHomeAudioSpeaker  + 
                          promotion_type.xDaussera.sale + 
                          promotion_type.xNo_promotion, data = train_home ) 


summary(step_home_model11)
vif(step_home_model11)

#Removed promotion_type.xNo_promotion due to high p 
step_home_model12 <- lm(tot_gmv ~ week_no + Digital  + 
                          discounted_mrp + 
                          list_price_change_from_w3   + 
                          affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                          product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                          product_analytic_vertical.xHomeAudioSpeaker  + 
                          promotion_type.xDaussera.sale 
                        , data = train_home  ) 


summary(step_home_model12)
vif(step_home_model12)


#Removed Digital due to high p 
step_home_model13 <- lm(tot_gmv ~ week_no   + 
                          discounted_mrp + 
                          list_price_change_from_w3   + 
                          affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                          product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                          product_analytic_vertical.xHomeAudioSpeaker  + 
                          promotion_type.xDaussera.sale 
                        , data = train_home   ) 


summary(step_home_model13)
vif(step_home_model13)


#Removed week_no due to high p 
step_home_model14 <- lm(tot_gmv ~    
                          discounted_mrp + 
                          list_price_change_from_w3   + 
                          affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                          product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                          product_analytic_vertical.xHomeAudioSpeaker  + 
                          promotion_type.xDaussera.sale 
                        , data = train_home  ) 


summary(step_home_model14)
vif(step_home_model14)

#Removed list_price_change_from_w3 due to high p 
step_home_model15 <- lm(tot_gmv ~    
                          discounted_mrp 
                        + 
                          affiliate_ad_stock + product_analytic_vertical.xBoomBox + 
                          product_analytic_vertical.xDock + product_analytic_vertical.xFMRadio + 
                          product_analytic_vertical.xHomeAudioSpeaker  + 
                          promotion_type.xDaussera.sale 
                        , data = train_home  ) 


summary(step_home_model15) 
vif(step_home_model15)

#Removed product_analytic_vertical.xBoomBox due to high vif 
step_home_model16 <- lm(tot_gmv ~    
                          discounted_mrp 
                        + 
                          affiliate_ad_stock + product_analytic_vertical.xDock +
                          product_analytic_vertical.xFMRadio + 
                          product_analytic_vertical.xHomeAudioSpeaker  + 
                          promotion_type.xDaussera.sale 
                        , data = train_home  ) 


summary(step_home_model16) 
vif(step_home_model16)


#Remove product_analytic_vertical.xDock due to high vif
step_home_model17 <- lm(tot_gmv ~    
                          discounted_mrp 
                        + 
                          affiliate_ad_stock + 
                          product_analytic_vertical.xFMRadio + 
                          product_analytic_vertical.xHomeAudioSpeaker  + 
                          promotion_type.xDaussera.sale 
                        , data = train_home  ) 


summary(step_home_model17) 
vif(step_home_model17)

#Remove affiliate_ad_stock  due to high vif
step_home_model18 <- lm(tot_gmv ~    
                          discounted_mrp 
                        + 
                          
                          product_analytic_vertical.xFMRadio + 
                          product_analytic_vertical.xHomeAudioSpeaker  + 
                          promotion_type.xDaussera.sale 
                        , data = train_home  ) 


summary(step_home_model18) 
vif(step_home_model18)

#Multiple R-squared:  0.585,	Adjusted R-squared:  0.579 

#___________________________________________________________________________________________________________#
#Model evalution for distributed lag model - home audio 
gmv_home_prediction <- predict(step_home_model18, test_home[,-3])
test_home$predicted_gmv <- gmv_home_prediction

home_r <- cor(test_home$tot_gmv, test_home$predicted_gmv)
home_rsquared <- home_r^2
home_rsquared   
#Rsquare on test = 0.72

#_________________________________________________________________________________________________________________#
#performing 10 fold Cross validation 

home_lm_cv <- cv.lm(data = weekly_consumer_ad_lag_home , form.lm = step_home_model18, m =10)
#ms = 0.441

#____________________________________________________________________________________________________________________#
# Elasticity plot 
home_final_model <- step_home_model18

elasticity <- function(var) {
  x <- as.numeric(home_final_model$coefficients[var] )
  return(x)
}

var_list <- list()

for(i in 2:length(home_final_model$coefficients)) {
  var_list[i-1] <- elasticity(names(home_final_model$coefficients)[i])
}

elasticity.outputs <- data.frame(names(home_final_model$coefficients[2:length(home_final_model$coefficients)]))
elasticity.outputs <- cbind(elasticity.outputs,do.call(rbind.data.frame, var_list))
colnames(elasticity.outputs) <- c("Variable","Elasticity")

elasticity.outputs$direction <- ifelse(elasticity.outputs$Elasticity > 0, "Positive", "Negative")
elasticity.outputs <- arrange( elasticity.outputs , -Elasticity)

ggplot(data=elasticity.outputs[, ], aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Home Audio -  LagDistributed  Model") +xlab("Variables")

####################################DISTRIBUTED LAG MODELLING #########################################
#################### 2. PRODUCT SUB CATEGORY: CAMERA ACCESSORY ###########################
weekly_consumer_ad_lag_camera1 <- weekly_consumer_ad_lag_camera
weekly_consumer_ad_lag_camera <- na.omit(weekly_consumer_ad_lag_camera)

weekly_consumer_ad_lag_camera [,c(1:35)] <- scale(weekly_consumer_ad_lag_camera [,c(1:35)])


set.seed(200)


trainindices= sample(1:nrow(weekly_consumer_ad_lag_camera), 0.7*nrow(weekly_consumer_ad_lag_camera))

#Generate the train data set
train_camera = weekly_consumer_ad_lag_camera[trainindices,]

#similarly generate test dataset
test_camera = weekly_consumer_ad_lag_camera[-trainindices,]



camera_model1 <- lm(tot_gmv~. , data = train_camera)
summary(camera_model1)


step_camera_model1 <- stepAIC(camera_model1, direction = "both")
summary(step_camera_model1)
vif(step_camera_model1)


# Removed content_ad_stock as high vif
step_camera_model2 <- lm(tot_gmv ~ TV + Sponsorship + Content.Marketing + 
                           X.Affiliates + SEM + Other + NPS + discounted_mrp + list_price_lag_2 + 
                           list_price_lag_3 + list_price_change_from_w2 + list_price_change_from_w3 + 
                           tv_ad_stock  + sem_ad_stock + product_analytic_vertical.xCameraAccessory + 
                           product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip + 
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraFilmRolls + 
                           product_analytic_vertical.xCameraHousing  + 
                           product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                           product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                           product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                           product_analytic_vertical.xLens  + 
                           product_analytic_vertical.xSoftbox + product_analytic_vertical.xStrap + 
                           product_analytic_vertical.xTelescope + promotion_type.xChristmas...New.Year.Sale + 
                           promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                           promotion_type.xNo_promotion, data = train_camera)


summary(step_camera_model2)
vif(step_camera_model2)



# removed sem_ad_stock as high vif
step_camera_model3 <- lm(tot_gmv ~ TV + Sponsorship + Content.Marketing + 
                           X.Affiliates + SEM + Other + NPS + discounted_mrp + list_price_lag_2 + 
                           list_price_lag_3 + list_price_change_from_w2 + list_price_change_from_w3 + 
                           tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                           product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip + 
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraFilmRolls + 
                           product_analytic_vertical.xCameraHousing  + 
                           product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                           product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                           product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                           product_analytic_vertical.xLens  + 
                           product_analytic_vertical.xSoftbox + product_analytic_vertical.xStrap + 
                           product_analytic_vertical.xTelescope + promotion_type.xChristmas...New.Year.Sale + 
                           promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                           promotion_type.xNo_promotion, data = train_camera)


summary(step_camera_model3)
vif(step_camera_model3)

# removed TV due to high vif
step_camera_model4 <- lm(tot_gmv ~   Sponsorship + Content.Marketing + 
                           X.Affiliates + SEM + Other + NPS + discounted_mrp + list_price_lag_2 + 
                           list_price_lag_3 + list_price_change_from_w2 + list_price_change_from_w3 + 
                           tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                           product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip + 
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraFilmRolls + 
                           product_analytic_vertical.xCameraHousing  + 
                           product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                           product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                           product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                           product_analytic_vertical.xLens  + 
                           product_analytic_vertical.xSoftbox + product_analytic_vertical.xStrap + 
                           product_analytic_vertical.xTelescope + promotion_type.xChristmas...New.Year.Sale + 
                           promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                           promotion_type.xNo_promotion, data = train_camera)


summary(step_camera_model4)
vif(step_camera_model4)



# removed Content.Marketing due to high vif
step_camera_model5 <- lm(tot_gmv ~   Sponsorship  + 
                           X.Affiliates + SEM + Other + NPS + discounted_mrp + list_price_lag_2 + 
                           list_price_lag_3 + list_price_change_from_w2 + list_price_change_from_w3 + 
                           tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                           product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip + 
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraFilmRolls + 
                           product_analytic_vertical.xCameraHousing  + 
                           product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                           product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                           product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                           product_analytic_vertical.xLens  + 
                           product_analytic_vertical.xSoftbox + product_analytic_vertical.xStrap + 
                           product_analytic_vertical.xTelescope + promotion_type.xChristmas...New.Year.Sale + 
                           promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                           promotion_type.xNo_promotion, data = train_camera)


summary(step_camera_model5)
vif(step_camera_model5)

#Removed SEM as high vif
step_camera_model6 <- lm(tot_gmv ~   Sponsorship  + 
                           X.Affiliates  + Other + NPS + discounted_mrp + list_price_lag_2 + 
                           list_price_lag_3 + list_price_change_from_w2 + list_price_change_from_w3 + 
                           tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                           product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip + 
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraFilmRolls + 
                           product_analytic_vertical.xCameraHousing  + 
                           product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                           product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                           product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                           product_analytic_vertical.xLens  + 
                           product_analytic_vertical.xSoftbox + product_analytic_vertical.xStrap + 
                           product_analytic_vertical.xTelescope + promotion_type.xChristmas...New.Year.Sale + 
                           promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                           promotion_type.xNo_promotion, data = train_camera)


summary(step_camera_model6)
vif(step_camera_model6)

#Removed other as p is high 
step_camera_model7 <- lm(tot_gmv ~   Sponsorship  + 
                           X.Affiliates   + NPS + discounted_mrp + list_price_lag_2 + 
                           list_price_lag_3 + list_price_change_from_w2 + list_price_change_from_w3 + 
                           tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                           product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip + 
                           product_analytic_vertical.xCameraEyeCup + product_analytic_vertical.xCameraFilmRolls + 
                           product_analytic_vertical.xCameraHousing  + 
                           product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                           product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                           product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                           product_analytic_vertical.xLens  + 
                           product_analytic_vertical.xSoftbox + product_analytic_vertical.xStrap + 
                           product_analytic_vertical.xTelescope + promotion_type.xChristmas...New.Year.Sale + 
                           promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                           promotion_type.xNo_promotion, data = train_camera)


summary(step_camera_model7)
vif(step_camera_model7)

# Removed product_analytic_vertical.xCameraEyeCup as p is high
step_camera_model8 <- lm(tot_gmv ~   Sponsorship  + 
                           X.Affiliates   + NPS + discounted_mrp + list_price_lag_2 + 
                           list_price_lag_3 + list_price_change_from_w2 + list_price_change_from_w3 + 
                           tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                           product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip + 
                           product_analytic_vertical.xCameraFilmRolls + 
                           product_analytic_vertical.xCameraHousing  + 
                           product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                           product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                           product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                           product_analytic_vertical.xLens  + 
                           product_analytic_vertical.xSoftbox + product_analytic_vertical.xStrap + 
                           product_analytic_vertical.xTelescope + promotion_type.xChristmas...New.Year.Sale + 
                           promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                           promotion_type.xNo_promotion, data = train_camera)


summary(step_camera_model8)
vif(step_camera_model8)



# Removed product_analytic_vertical.xSoftbox  , product_analytic_vertical.xCameraFilmRolls due to high p
step_camera_model10 <- lm(tot_gmv ~   Sponsorship  + 
                            X.Affiliates   + NPS + discounted_mrp + list_price_lag_2 + 
                            list_price_lag_3 + list_price_change_from_w2 + list_price_change_from_w3 + 
                            tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope + promotion_type.xChristmas...New.Year.Sale + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                            promotion_type.xNo_promotion, data = train_camera)


summary(step_camera_model10)
vif(step_camera_model10)


# Removed promotion_type.xChristmas...New.Year.Sale due to high p 
step_camera_model11 <- lm(tot_gmv ~   Sponsorship  + 
                            X.Affiliates   + NPS + discounted_mrp + list_price_lag_2 + 
                            list_price_lag_3 + list_price_change_from_w2 + list_price_change_from_w3 + 
                            tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale + 
                            promotion_type.xNo_promotion, data = train_camera)


summary(step_camera_model11)
vif(step_camera_model11)

# Removed promotion_type.xNo_promotion due to high p 
step_camera_model12 <- lm(tot_gmv ~   Sponsorship  + 
                            X.Affiliates   + NPS + discounted_mrp + list_price_lag_2 + 
                            list_price_lag_3 + list_price_change_from_w2 + list_price_change_from_w3 + 
                            tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model12)
vif(step_camera_model12)


# Removed list_price_change_from_w2 due to high vif 
step_camera_model13 <- lm(tot_gmv ~   Sponsorship  + 
                            X.Affiliates   + NPS + discounted_mrp + list_price_lag_2 + 
                            list_price_lag_3  + list_price_change_from_w3 + 
                            tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model13)
vif(step_camera_model13)

# Removed list_price_lag_3 due to high vif 
step_camera_model14 <- lm(tot_gmv ~   Sponsorship  + 
                            X.Affiliates   + NPS + discounted_mrp + list_price_lag_2 + 
                            list_price_change_from_w3 + 
                            tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model14)
vif(step_camera_model14)

# Removed list_price_lag_2 due to high P 
step_camera_model15 <- lm(tot_gmv ~   Sponsorship  + 
                            X.Affiliates   + NPS + discounted_mrp  + 
                            list_price_change_from_w3 + 
                            tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model15)
vif(step_camera_model15)

# Removed list_price_change_from_w3 due to high vif 
step_camera_model16 <- lm(tot_gmv ~   Sponsorship  + 
                            X.Affiliates   + NPS + discounted_mrp   
                          + 
                            tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model16)
vif(step_camera_model16)


# Removed  X.Affiliates due to high vif
step_camera_model17 <- lm(tot_gmv ~   Sponsorship  + 
                            NPS + discounted_mrp   
                          + 
                            tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model17)
vif(step_camera_model17)


# Removed  Sponsorship due to high vif
step_camera_model18 <- lm(tot_gmv ~   
                            NPS + discounted_mrp   
                          + 
                            tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model18)
vif(step_camera_model18)

# Removed  NPS  due to high vif
step_camera_model19 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + 
                            tv_ad_stock   + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model19)
vif(step_camera_model19)

# Removed tv_ad_stock due to high vif
step_camera_model20 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xCameraTripod + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model20)
vif(step_camera_model20)

# Removed product_analytic_vertical.xCameraTripod  due to high vif
step_camera_model21 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            product_analytic_vertical.xCameraHousing  + 
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model21)
vif(step_camera_model21)

# Removed product_analytic_vertical.xCameraHousing due to high vif
step_camera_model22 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model22)
vif(step_camera_model22)

# Removed product_analytic_vertical.xCameraBatteryCharger due to high vif
step_camera_model23 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryGrip  
                          + 
                            
                            product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + 
                            product_analytic_vertical.xExtensionTube + product_analytic_vertical.xFilter + 
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model23)
vif(step_camera_model23)

# Removed product_analytic_vertical.xCameraMicrophone due to high vif
step_camera_model24 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryGrip  
                          + product_analytic_vertical.xFilter
                          
                          + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + 
                            product_analytic_vertical.xExtensionTube +  
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale + promotion_type.xRakshabandhan.Sale 
                          , data = train_camera)


summary(step_camera_model24)
vif(step_camera_model24)


# Removed promotion_type.xRakshabandhan.Sale due to high vif
step_camera_model25 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryGrip  
                          + product_analytic_vertical.xFilter
                          
                          + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + 
                            product_analytic_vertical.xExtensionTube +  
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale  
                          , data = train_camera)


summary(step_camera_model25)
vif(step_camera_model25)

# Removedproduct_analytic_vertical.xFilter due to high vif
step_camera_model26 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryGrip  
                          + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + 
                            product_analytic_vertical.xExtensionTube +  
                            product_analytic_vertical.xLens  + 
                            product_analytic_vertical.xStrap + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale  
                          , data = train_camera)


summary(step_camera_model26)
vif(step_camera_model26)

# Removed product_analytic_vertical.xStrap due to high vif
step_camera_model27 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraAccessory + 
                            product_analytic_vertical.xCameraBatteryGrip  
                          + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + 
                            product_analytic_vertical.xExtensionTube +  
                            product_analytic_vertical.xLens + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale  
                          , data = train_camera)


summary(step_camera_model27)
vif(step_camera_model27)


# Removed product_analytic_vertical.xCameraAccessory  due to high vif
step_camera_model28 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + 
                            product_analytic_vertical.xCameraBatteryGrip  
                          + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + 
                            product_analytic_vertical.xExtensionTube +  
                            product_analytic_vertical.xLens + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale  
                          , data = train_camera)


summary(step_camera_model28)
vif(step_camera_model28)

# Removed  product_analytic_vertical.xCameraBatteryGrip   due to high vif
step_camera_model29 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + 
                            product_analytic_vertical.xExtensionTube +  
                            product_analytic_vertical.xLens + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale  
                          , data = train_camera)


summary(step_camera_model29)
vif(step_camera_model29)

# Removed  product_analytic_vertical.xExtensionTube due to high vif
step_camera_model30 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + 
                            
                            product_analytic_vertical.xLens + 
                            product_analytic_vertical.xTelescope  + 
                            promotion_type.xDaussera.sale  
                          , data = train_camera)


summary(step_camera_model30)
vif(step_camera_model30)

# Removed  product_analytic_vertical.xTelescope due to high vif
step_camera_model31 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraMount + 
                            product_analytic_vertical.xCameraRemoteControl + 
                            
                            product_analytic_vertical.xLens + 
                            
                            promotion_type.xDaussera.sale  
                          , data = train_camera)


summary(step_camera_model31)
vif(step_camera_model31)

# Removed  product_analytic_vertical.xCameraRemoteControl due to high vif
step_camera_model32 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xCameraMount + 
                            
                            
                            product_analytic_vertical.xLens + 
                            
                            promotion_type.xDaussera.sale  
                          , data = train_camera)


summary(step_camera_model32)
vif(step_camera_model32)

# Removed  product_analytic_vertical.xCameraMount  due to high vif
step_camera_model33 <- lm(tot_gmv ~   
                            discounted_mrp   
                          + product_analytic_vertical.xLens + 
                            promotion_type.xDaussera.sale  
                          , data = train_camera)


summary(step_camera_model33)
vif(step_camera_model33)
#Multiple R-squared:  0.574,	Adjusted R-squared:  0.572 

#_______________________________________________________________________________________________________________#
# Model evalution for test data set
gmv_camera_prediction <- predict(step_camera_model33, test_camera[,-3])
test_camera$predicted_gmv <- gmv_camera_prediction

camera_r <- cor(test_camera$tot_gmv, test_camera$predicted_gmv)
camera_rsquared <- camera_r^2
camera_rsquared   
#Rsquared on test = 0.739

#_________________________________________________________________________________________________________________#
#Cross validation 
cam_lm_cv <- cv.lm(data = weekly_consumer_ad_lag_camera , form.lm = step_camera_model33, m =10)
#ms = 0.38
#___________________________________________________________________________________________________________________#

# Plot elasticity 
camera_final_model <- step_camera_model33

elasticity <- function(var) {
  x <- as.numeric(camera_final_model$coefficients[var] )
  return(x)
}

var_list <- list()

for(i in 2:length(camera_final_model$coefficients)) {
  var_list[i-1] <- elasticity(names(camera_final_model$coefficients)[i])
}

elasticity.outputs <- data.frame(names(camera_final_model$coefficients[2:length(camera_final_model$coefficients)]))
elasticity.outputs <- cbind(elasticity.outputs,do.call(rbind.data.frame, var_list))
colnames(elasticity.outputs) <- c("Variable","Elasticity")

elasticity.outputs$direction <- ifelse(elasticity.outputs$Elasticity > 0, "Positive", "Negative")
elasticity.outputs <- arrange( elasticity.outputs , -Elasticity)

ggplot(data=elasticity.outputs[, ], aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Camera Accessory - Lag Model") +xlab("Variables")

####################################DISTRIBUTED LAG MODELLING #########################################
#################### 3. PRODUCT SUB CATEGORY: GAMING ACCESSORY ###########################
weekly_consumer_ad_lag_game <- filter ( weekly_consumer_ad_data_with_lag_overall ,weekly_consumer_ad_data_with_lag_overall$product_analytic_sub_category %in% c("GamingAccessory")) 
weekly_consumer_ad_lag_game$product_analytic_sub_category <- NULL
weekly_consumer_ad_lag_game1 <- weekly_consumer_ad_lag_game
weekly_consumer_ad_lag_game <- na.omit(weekly_consumer_ad_lag_game)

weekly_consumer_ad_lag_game [,c(1:35)] <- scale(weekly_consumer_ad_lag_game [,c(1:35)])


set.seed(100)


trainindices= sample(1:nrow(weekly_consumer_ad_lag_game), 0.7*nrow(weekly_consumer_ad_lag_game))
#Generate the train data set
train_game = weekly_consumer_ad_lag_game[trainindices,]

#Similarly store the rest of the observations into an object "test".
test_game = weekly_consumer_ad_lag_game[-trainindices,]


game_model1 <- lm(tot_gmv~. , data = train_game)

summary(game_model1)


step_game_model1 <- stepAIC(game_model1, direction = "both")
summary(step_game_model1)
vif(step_game_model1)

# Removed online_ad_stock due to high vif 
step_game_model3 <- lm( tot_gmv ~ list_price + Sponsorship + SEM + Radio + 
                          Other + NPS + discounted_mrp + gmv_lag_1 + gmv_change_from_w2 + 
                          gmv_change_from_w3 + list_price_lag_2 + content_ad_stock + 
                          sem_ad_stock + affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                          product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker + 
                          promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 + 
                          promotion_type.xDaussera.sale 
                        + promotion_type.xRepublic.Day, 
                        data = train_game)

summary(step_game_model3)
vif(step_game_model3)

#  sem_ad_stock due to high vif
step_game_model4 <- lm(tot_gmv ~ list_price + Sponsorship + SEM + Radio + 
                         Other + NPS + discounted_mrp + gmv_lag_1 + gmv_change_from_w2 + 
                         gmv_change_from_w3 + list_price_lag_2 + content_ad_stock + 
                         affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                         product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                         product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker + 
                         promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 + 
                         promotion_type.xDaussera.sale 
                       + promotion_type.xRepublic.Day, 
                       data = train_game)

summary(step_game_model4)
vif(step_game_model4)

# Removed Other due to high vif
step_game_model5 <- lm(tot_gmv ~ list_price + Sponsorship + SEM + Radio + 
                         NPS + discounted_mrp + gmv_lag_1 + gmv_change_from_w2 + 
                         gmv_change_from_w3 + list_price_lag_2 + content_ad_stock + 
                         affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                         product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                         product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker + 
                         promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 + 
                         promotion_type.xDaussera.sale 
                       + promotion_type.xRepublic.Day, 
                       data = train_game)

summary(step_game_model5)
vif(step_game_model5)


# Removed content_ad_stock as vif is high 
step_game_model6 <- lm(tot_gmv ~ list_price + Sponsorship + SEM  + Radio +
                         NPS + discounted_mrp + gmv_lag_1 + gmv_change_from_w2 + 
                         gmv_change_from_w3 + list_price_lag_2  + 
                         affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                         product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                         product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker + 
                         promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 + 
                         promotion_type.xDaussera.sale 
                       + promotion_type.xRepublic.Day, 
                       data = train_game)

summary(step_game_model6)
vif(step_game_model6)



# Removed list_price as p is high 
step_game_model7 <- lm(tot_gmv ~   Sponsorship + SEM  + Radio +
                         NPS + discounted_mrp + gmv_lag_1 + gmv_change_from_w2 + 
                         gmv_change_from_w3 + list_price_lag_2  + 
                         affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                         product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                         product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker + 
                         promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 + 
                         promotion_type.xDaussera.sale 
                       + promotion_type.xRepublic.Day, 
                       data = train_game)

summary(step_game_model7)
vif(step_game_model7)

# Removed Radio due to high vif
step_game_model8 <- lm(tot_gmv ~ list_price + Sponsorship + SEM  + 
                         NPS + discounted_mrp + gmv_lag_1 + gmv_change_from_w2 + 
                         gmv_change_from_w3 + list_price_lag_2 + content_ad_stock + 
                         affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                         product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                         product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker + 
                         promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 + 
                         promotion_type.xDaussera.sale 
                       + promotion_type.xRepublic.Day, 
                       data = train_game)

summary(step_game_model8)
vif(step_game_model8)

#Remove SEM
step_game_model9 <- lm(tot_gmv ~ list_price + Sponsorship + 
                         NPS + discounted_mrp + gmv_lag_1 + gmv_change_from_w2 + 
                         gmv_change_from_w3 + list_price_lag_2 + content_ad_stock + 
                         affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                         product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                         product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker + 
                         promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 + 
                         promotion_type.xDaussera.sale 
                       + promotion_type.xRepublic.Day, 
                       data = train_game)

summary(step_game_model9)
vif(step_game_model9)


# Removed promotion_type.xBig.Diwali.Sale as p is high 
step_game_model10 <- lm(tot_gmv ~   Sponsorship + 
                          NPS + discounted_mrp + gmv_lag_1 + gmv_change_from_w2 + 
                          gmv_change_from_w3 + list_price_lag_2  + 
                          affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                          product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker + 
                          promotion_type.xBSD.5 + 
                          promotion_type.xDaussera.sale 
                        + promotion_type.xRepublic.Day, 
                        data = train_game)

summary(step_game_model10)
vif(step_game_model10)

# Removed promotion_type.xBSD.5 and promotion_type.xRepublic.Day as p is high 
step_game_model11 <- lm(tot_gmv ~   Sponsorship + 
                          NPS + discounted_mrp + gmv_lag_1 + gmv_change_from_w2 + 
                          gmv_change_from_w3 + list_price_lag_2  + 
                          affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                          product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker  
                        + 
                          promotion_type.xDaussera.sale 
                        , 
                        data = train_game)

summary(step_game_model11)
vif(step_game_model11)

# Removed list_price_lag_2 as p is high
step_game_model12 <- lm(tot_gmv ~   Sponsorship + 
                          NPS + discounted_mrp + gmv_lag_1 + gmv_change_from_w2 + 
                          gmv_change_from_w3   + 
                          affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                          product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker  
                        + 
                          promotion_type.xDaussera.sale 
                        , 
                        data = train_game)

summary(step_game_model12)
vif(step_game_model12)

# Removed gmv_change_from_w3 and NPS as p is high
step_game_model13 <- lm(tot_gmv ~   Sponsorship +  
                          discounted_mrp + gmv_lag_1 + gmv_change_from_w2 
                        + 
                          affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                          product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker  
                        + 
                          promotion_type.xDaussera.sale 
                        , 
                        data = train_game)

summary(step_game_model13)
vif(step_game_model13)




# Removed  discount_over_mrp as p is  is high
step_game_model14 <- lm(tot_gmv ~   Sponsorship +  
                          gmv_lag_1 + gmv_change_from_w2 
                        + 
                          affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                          product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker  
                        + 
                          promotion_type.xDaussera.sale 
                        , 
                        data = train_game)

summary(step_game_model14)
vif(step_game_model14)


# Removed product_analytic_vertical.xGamingSpeaker as P is  is high
step_game_model15 <- lm(tot_gmv ~   Sponsorship +  
                          gmv_lag_1 + gmv_change_from_w2 
                        + 
                          affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                          product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse   
                        + 
                          promotion_type.xDaussera.sale 
                        , 
                        data = train_game)

summary(step_game_model15)
vif(step_game_model15)



# Removed gmv_lag_1 as P is  is high
step_game_model16 <- lm(tot_gmv ~   Sponsorship +  
                          gmv_change_from_w2 
                        + 
                          affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                          product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse   
                        + 
                          promotion_type.xDaussera.sale 
                        , 
                        data = train_game)

summary(step_game_model16)
vif(step_game_model16)

# Removed gmv_change_from_w2 as P is  is high
step_game_model17 <- lm(tot_gmv ~   Sponsorship +  
                          affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                          product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse   
                        + 
                          promotion_type.xDaussera.sale 
                        , 
                        data = train_game)

summary(step_game_model16)
vif(step_game_model16)

# Removed Sponsorship  as P is  is high
step_game_model17 <- lm(tot_gmv ~ 
                          affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                          product_analytic_vertical.xGamingHeadset + product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse   
                        + 
                          promotion_type.xDaussera.sale 
                        , 
                        data = train_game)

summary(step_game_model17)
vif(step_game_model17)

# product_analytic_vertical.xGamingKeyboard as P is  is high
step_game_model18 <- lm(tot_gmv ~ 
                          affiliate_ad_stock + product_analytic_vertical.xGamePad + 
                          product_analytic_vertical.xGamingHeadset +  
                          product_analytic_vertical.xGamingMouse   
                        + 
                          promotion_type.xDaussera.sale 
                        , 
                        data = train_game)

summary(step_game_model18)
vif(step_game_model18)
#Multiple R-squared:  0.678,	Adjusted R-squared:  0.675 

#________________________________________________________________________________________________________________#

#Model evalution on test data 
gmv_game_prediction <- predict(step_game_model18, test_game[,-3])
test_game$predicted_gmv <- gmv_game_prediction

game_r <- cor(test_game$tot_gmv, test_game$predicted_gmv)
game_rsquared <- game_r^2
game_rsquared   
#Rsquare on test = 0.645

#__________________________________________________________________________________________________________________#
#Cross validation
game_lm_cv <- cv.lm(data = weekly_consumer_ad_lag_game , form.lm = step_game_model18, m =10)

#ms = 0.36

#___________________________________________________________________________________________________________________#
#find elasticity
game_final_model <- step_game_model18

elasticity <- function(var) {
  x <- as.numeric(game_final_model$coefficients[var] )
  return(x)
}

var_list <- list()

for(i in 2:length(game_final_model$coefficients)) {
  var_list[i-1] <- elasticity(names(game_final_model$coefficients)[i])
}

elasticity.outputs <- data.frame(names(game_final_model$coefficients[2:length(game_final_model$coefficients)]))
elasticity.outputs <- cbind(elasticity.outputs,do.call(rbind.data.frame, var_list))
colnames(elasticity.outputs) <- c("Variable","Elasticity")

elasticity.outputs$direction <- ifelse(elasticity.outputs$Elasticity > 0, "Positive", "Negative")
elasticity.outputs <- arrange( elasticity.outputs , -Elasticity)

ggplot(data=elasticity.outputs[, ], aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Gaming  Accessory -  LagDistributed  Model") +xlab("Variables")


#########################################################################################################
#################################### MULTIPLICATIVE LAG MODELLING #########################################
#################### 1. PRODUCT SUB CATEGORY: HOME AUDIO ###########################
weekly_ad_home_mullag <- weekly_consumer_ad_lag_home1
weekly_ad_home_mullag <-na.omit(weekly_ad_home_mullag)

weekly_ad_home_mullag1  <- lapply (weekly_ad_home_mullag[,1:35] ,function(x) ifelse ( x==0 , 0, log(abs(x)))*sign(x) )
weekly_ad_home_mullag <- data.frame( cbind( weekly_ad_home_mullag1 ,weekly_ad_home_mullag[,36:97] ))


set.seed(200)


trainindices= sample(1:nrow(weekly_ad_home_mullag), 0.7*nrow(weekly_ad_home_mullag))
#Generate the train data set
train_home_mullag = weekly_ad_home_mullag[trainindices,]

#Similarly store the rest of the observations into an object "test".
test_home_mullag = weekly_ad_home_mullag[-trainindices,]

model_mullaghome1 <- lm(tot_gmv ~ ., data = train_home_mullag)
summary(model_mullaghome1)
#Multiple R-squared:  0.327,	Adjusted R-squared:  0.191 

model_step_mullag <- stepAIC(model_mullaghome1, direction = "both")
summary(model_step_mullag)
vif(model_step_mullag)

#Remove list_price, week_no and month as they have high vif 
#from the last step of AIC model, use variables with '-' sign
model_mullaghome2 <- lm(tot_gmv ~ TV + Digital + Sponsorship + Content.Marketing + Online.marketing +
                          X.Affiliates + Radio + Other + gmv_lag_1 + gmv_change_from_w1 + gmv_change_from_w2 +
                          gmv_change_from_w3 + list_price_lag_1 + list_price_lag_2 + list_price_change_from_w2 +
                          list_price_change_from_w3 + content_ad_stock + affiliate_ad_stock +
                          product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                          product_analytic_vertical.xDockingStation + product_analytic_vertical.xFMRadio +
                          product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                          product_analytic_vertical.xSoundMixer + promotion_type.xChristmas...New.Year.Sale  +
                          promotion_type.xDaussera.sale + promotion_type.xNo_promotion  +
                          promotion_type.xPacman, data = train_home_mullag)
summary(model_mullaghome2)
vif(model_mullaghome2)

#Remove Digital as it has high vif and is also insignificant
model_mullaghome3 <- lm(tot_gmv ~ TV +Sponsorship + Content.Marketing + Online.marketing +
                          X.Affiliates + Radio + Other + gmv_lag_1 + gmv_change_from_w1 + gmv_change_from_w2 +
                          gmv_change_from_w3 + list_price_lag_1 + list_price_lag_2 + list_price_change_from_w2 +
                          list_price_change_from_w3 + content_ad_stock + affiliate_ad_stock +
                          product_analytic_vertical.xDJController + product_analytic_vertical.xDock +
                          product_analytic_vertical.xDockingStation + product_analytic_vertical.xFMRadio +
                          product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                          product_analytic_vertical.xSoundMixer + promotion_type.xChristmas...New.Year.Sale  +
                          promotion_type.xDaussera.sale + promotion_type.xNo_promotion  +
                          promotion_type.xPacman, data = train_home_mullag)
summary(model_mullaghome3)
vif(model_mullaghome3)

#Remove product_analytic_vertical.xDJController + product_analytic_vertical.xFMRadio as it has high vif and is also insignificant
model_mullaghome4 <- lm(tot_gmv ~ TV +Sponsorship + Content.Marketing + Online.marketing +
                          X.Affiliates + Radio + Other + gmv_lag_1 + gmv_change_from_w1 + gmv_change_from_w2 +
                          gmv_change_from_w3 + list_price_lag_1 + list_price_lag_2 + list_price_change_from_w2 +
                          list_price_change_from_w3 + content_ad_stock + affiliate_ad_stock +
                          product_analytic_vertical.xDock +
                          product_analytic_vertical.xDockingStation + 
                          product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                          product_analytic_vertical.xSoundMixer + promotion_type.xChristmas...New.Year.Sale  +
                          promotion_type.xDaussera.sale + promotion_type.xNo_promotion  +
                          promotion_type.xPacman, data = train_home_mullag)
summary(model_mullaghome4)
vif(model_mullaghome4)

#Remove product_analytic_vertical.xSoundMixer + promotion_type.xPacman as it has high vif and is also insignificant
model_mullaghome5 <- lm(tot_gmv ~ TV +Sponsorship + Content.Marketing + Online.marketing +
                          X.Affiliates + Radio + Other + gmv_lag_1 + gmv_change_from_w1 + gmv_change_from_w2 +
                          gmv_change_from_w3 + list_price_lag_1 + list_price_lag_2 + list_price_change_from_w2 +
                          list_price_change_from_w3 + content_ad_stock + affiliate_ad_stock +
                          product_analytic_vertical.xDock +
                          product_analytic_vertical.xDockingStation + 
                          product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                          promotion_type.xChristmas...New.Year.Sale  +
                          promotion_type.xDaussera.sale + promotion_type.xNo_promotion  +
                          promotion_type.xPacman, data = train_home_mullag)
summary(model_mullaghome5)
vif(model_mullaghome5)

#Remove list_price_change_from_w2 + list_price_change_from_w3 as it has high vif and is also insignificant
model_mullaghome6 <- lm(tot_gmv ~ TV +Sponsorship + Content.Marketing + Online.marketing +
                          X.Affiliates + Radio + Other + gmv_lag_1 + gmv_change_from_w1 + gmv_change_from_w2 +
                          gmv_change_from_w3 + list_price_lag_1 + list_price_lag_2 +
                          content_ad_stock + affiliate_ad_stock +
                          product_analytic_vertical.xDock +
                          product_analytic_vertical.xDockingStation + 
                          product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                          promotion_type.xChristmas...New.Year.Sale  +
                          promotion_type.xDaussera.sale + promotion_type.xNo_promotion  +
                          promotion_type.xPacman, data = train_home_mullag)
summary(model_mullaghome6)
vif(model_mullaghome6)

#Remove gmv_lag_1 as it has high vif and is also insignificant
model_mullaghome7 <- lm(tot_gmv ~ TV +Sponsorship + Content.Marketing + Online.marketing +
                          X.Affiliates + Radio + Other +  gmv_change_from_w1 + gmv_change_from_w2 +
                          gmv_change_from_w3 + list_price_lag_1 + list_price_lag_2 +
                          content_ad_stock + affiliate_ad_stock +
                          product_analytic_vertical.xDock +
                          product_analytic_vertical.xDockingStation + 
                          product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                          promotion_type.xChristmas...New.Year.Sale  +
                          promotion_type.xDaussera.sale + promotion_type.xNo_promotion  +
                          promotion_type.xPacman, data = train_home_mullag)
summary(model_mullaghome7)
vif(model_mullaghome7)

#Remove promotion_type.xChristmas...New.Year.Sale as it has high vif and is also insignificant
model_mullaghome8 <- lm(tot_gmv ~ TV +Sponsorship + Content.Marketing + Online.marketing +
                          X.Affiliates + Radio + Other +  gmv_change_from_w1 + gmv_change_from_w2 +
                          gmv_change_from_w3 + list_price_lag_1 + list_price_lag_2 +
                          content_ad_stock + affiliate_ad_stock +
                          product_analytic_vertical.xDock +
                          product_analytic_vertical.xDockingStation + 
                          product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                          promotion_type.xDaussera.sale + promotion_type.xNo_promotion  +
                          promotion_type.xPacman, data = train_home_mullag)
summary(model_mullaghome8)
vif(model_mullaghome8)

#Remove Radio and others as it has high vif 
model_mullaghome9 <- lm(tot_gmv ~ TV +Sponsorship + Content.Marketing + Online.marketing +
                          X.Affiliates + gmv_change_from_w1 + gmv_change_from_w2 +
                          gmv_change_from_w3 + list_price_lag_1 + list_price_lag_2 +
                          content_ad_stock + affiliate_ad_stock +
                          product_analytic_vertical.xDock +
                          product_analytic_vertical.xDockingStation + 
                          product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                          promotion_type.xDaussera.sale + promotion_type.xNo_promotion  +
                          promotion_type.xPacman, data = train_home_mullag)
summary(model_mullaghome9)
vif(model_mullaghome9)

#Remove content_ad_stock + promotion_type.xNo_promotion + promotion_type.xPacman as it has high vif and p value
model_mullaghome10 <- lm(tot_gmv ~ TV +Sponsorship + Content.Marketing + Online.marketing +
                           X.Affiliates + gmv_change_from_w1 + gmv_change_from_w2 +
                           gmv_change_from_w3 + list_price_lag_1 + list_price_lag_2 +
                           affiliate_ad_stock +
                           product_analytic_vertical.xDock +
                           product_analytic_vertical.xDockingStation + 
                           product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                           promotion_type.xDaussera.sale, data = train_home_mullag)
summary(model_mullaghome10)
vif(model_mullaghome10)

#Remove affiliate_ad_stock as it has high vif and p value
model_mullaghome11 <- lm(tot_gmv ~ TV +Sponsorship + Content.Marketing + Online.marketing +
                           gmv_change_from_w1 + gmv_change_from_w2 +
                           gmv_change_from_w3 + list_price_lag_1 + list_price_lag_2 +
                           X.Affiliates +
                           product_analytic_vertical.xDock +
                           product_analytic_vertical.xDockingStation + 
                           product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                           promotion_type.xDaussera.sale, data = train_home_mullag)
summary(model_mullaghome11)
vif(model_mullaghome11)

#Remove Online.marketing as it has high vif and p value
model_mullaghome12 <- lm(tot_gmv ~ TV +Sponsorship + Content.Marketing + 
                           gmv_change_from_w1 + gmv_change_from_w2 +
                           gmv_change_from_w3 + list_price_lag_1 + list_price_lag_2 +
                           X.Affiliates +
                           product_analytic_vertical.xDock +
                           product_analytic_vertical.xDockingStation + 
                           product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                           promotion_type.xDaussera.sale, data = train_home_mullag)
summary(model_mullaghome12)
vif(model_mullaghome12)

#Remove list_price_lag_1 and list_price_lag_2 as it has high vif and p value
model_mullaghome13 <- lm(tot_gmv ~ TV +Sponsorship + Content.Marketing + 
                           gmv_change_from_w1 + gmv_change_from_w2 +
                           gmv_change_from_w3 + 
                           X.Affiliates +
                           product_analytic_vertical.xDock +
                           product_analytic_vertical.xDockingStation + 
                           product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                           promotion_type.xDaussera.sale, data = train_home_mullag)
summary(model_mullaghome13)
vif(model_mullaghome13)

#Remove TV and Content.Marketing as it has high vif and p value
model_mullaghome14 <- lm(tot_gmv ~ Sponsorship +  
                           gmv_change_from_w1 + gmv_change_from_w2 +
                           gmv_change_from_w3 + 
                           X.Affiliates +
                           product_analytic_vertical.xDock +
                           product_analytic_vertical.xDockingStation + 
                           product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                           promotion_type.xDaussera.sale, data = train_home_mullag)
summary(model_mullaghome14)
vif(model_mullaghome14)

#Remove X.Affiliates and Sponsorship as it has high vif and p value
model_mullaghome15 <- lm(tot_gmv ~   
                           gmv_change_from_w1 + gmv_change_from_w2 +
                           gmv_change_from_w3 + 
                           product_analytic_vertical.xDock +
                           product_analytic_vertical.xDockingStation + 
                           product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                           promotion_type.xDaussera.sale, data = train_home_mullag)
summary(model_mullaghome15)
vif(model_mullaghome15)

#Remove gmv_change_from_w1 + gmv_change_from_w3 as it has high vif and p value
model_mullaghome16 <- lm(tot_gmv ~   
                           gmv_change_from_w2 +
                           product_analytic_vertical.xDock +
                           product_analytic_vertical.xDockingStation + 
                           product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xHomeAudioSpeaker +
                           promotion_type.xDaussera.sale, data = train_home_mullag)
summary(model_mullaghome16)
vif(model_mullaghome16)

#Remove product_analytic_vertical.xHiFiSystem as it has high vif and p value
model_mullaghome17 <- lm(tot_gmv ~   
                           gmv_change_from_w2 +
                           product_analytic_vertical.xDock +
                           product_analytic_vertical.xDockingStation + 
                           product_analytic_vertical.xHomeAudioSpeaker +
                           promotion_type.xDaussera.sale, data = train_home_mullag)
summary(model_mullaghome17)
vif(model_mullaghome17)

#Remove gmv_change_from_w2 as it has high vif and p value
model_mullaghome18 <- lm(tot_gmv ~   
                           product_analytic_vertical.xDock +
                           product_analytic_vertical.xDockingStation + 
                           product_analytic_vertical.xHomeAudioSpeaker +
                           promotion_type.xDaussera.sale, data = train_home_mullag)
summary(model_mullaghome18)
vif(model_mullaghome18)

#Remove product_analytic_vertical.xDock as it has high vif and p value
model_mullaghome19 <- lm(tot_gmv ~   
                           product_analytic_vertical.xDockingStation + 
                           product_analytic_vertical.xHomeAudioSpeaker +
                           promotion_type.xDaussera.sale, data = train_home_mullag)
summary(model_mullaghome19)
vif(model_mullaghome19)

#Remove promotion_type.xDaussera.sale as it has high p value
model_mullaghome20 <- lm(tot_gmv ~   
                           product_analytic_vertical.xDockingStation + 
                           product_analytic_vertical.xHomeAudioSpeaker, data = train_home_mullag)
summary(model_mullaghome20)
vif(model_mullaghome20)

final_home_mullag <- model_mullaghome20
#Multiple R-squared:  0.051,	Adjusted R-squared:  0.044

#_________________________________________________________________________________________________________________#
#prediction on test data
home_mullag_prediction <- predict(final_home_mullag, test_home_mullag[,-3])
test_home_mullag$predicted_gmv <- home_mullag_prediction

home_r <- cor(test_home_mullag$tot_gmv, test_home_mullag$predicted_gmv  )
home_rsquared <- home_r^2
home_rsquared   
#Rsquare on test =  0.012
#____________________________________________________________________________________________________________#
game_lm_cv <- cv.lm(data = weekly_ad_home_mullag , form.lm = final_model_mulhome, m =10)
#ms = 0.705

#_____________________________________________________________________________________________________________________#
#Plot Elasticity
elasticity <- function(var) {
  x <- as.numeric(final_home_mullag$coefficients[var] )
  return(x)
}

var_list <- list()

for(i in 2:length(final_home_mullag$coefficients)) {
  var_list[i-1] <- elasticity(names(final_home_mullag$coefficients)[i])
}

elasticity.outputs <- data.frame(names(final_home_mullag$coefficients[2:length(final_home_mullag$coefficients)]))
elasticity.outputs <- cbind(elasticity.outputs,do.call(rbind.data.frame, var_list))
colnames(elasticity.outputs) <- c("Variable","Elasticity")

elasticity.outputs$direction <- ifelse(elasticity.outputs$Elasticity > 0, "Positive", "Negative")
elasticity.outputs <- arrange( elasticity.outputs , -Elasticity)

ggplot(data=elasticity.outputs[, ], aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Home Audio -Multiplicative Lag Model") +xlab("Variables")

############################## MULTIPLICATIVE LAG MODELLING ######################################################
#################### 2. PRODUCT SUB CATEGORY: CAMERA ACCESSORY ###########################
weekly_ad_cam_mullag <- weekly_consumer_ad_lag_camera1
weekly_ad_cam_mullag <-na.omit(weekly_ad_cam_mullag)

weekly_ad_cam_mullag1  <- lapply (weekly_ad_cam_mullag[,1:35] ,function(x) ifelse ( x==0 , 0, log(abs(x)))*sign(x) )
weekly_ad_cam_mullag <- data.frame( cbind( weekly_ad_cam_mullag1 ,weekly_ad_cam_mullag[,36:97] ))


set.seed(200)


trainindices= sample(1:nrow(weekly_ad_cam_mullag), 0.7*nrow(weekly_ad_cam_mullag))

#Generate the train data set
train_cam_mullag = weekly_ad_cam_mullag[trainindices,]

#Similarly store the rest of the observations into an object "test".
test_cam_mullag = weekly_ad_cam_mullag[-trainindices,]

model_mullagcam1 <- lm(tot_gmv ~ ., data = train_cam_mullag)
summary(model_mullagcam1)
#Multiple R-squared:  0.311,	Adjusted R-squared:  0.232 

model_step_mullag_cam <- stepAIC(model_mullagcam1, direction = "both")
summary(model_step_mullag_cam)
vif(model_step_mullag_cam)

#Remove list_price and Radio as they have high vif
model_mullagcam2 <- lm(tot_gmv ~ week_no + Month + TV + Digital + Sponsorship + Content.Marketing +
                         Online.marketing + X.Affiliates + SEM + Other + NPS + discounted_mrp +
                         gmv_lag_2 + gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                         list_price_lag_2 + tv_ad_stock + dig_ad_stock + spon_ad_stock + content_ad_stock +
                         online_ad_stock + sem_ad_stock + product_analytic_vertical.xCameraAccessory +
                         product_analytic_vertical.xCameraBattery + product_analytic_vertical.xCameraBatteryCharger +
                         product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                         product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                         product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                         product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                         product_analytic_vertical.xFilter + product_analytic_vertical.xFlash +
                         product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                         product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope +
                         promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xNo_promotion +
                         promotion_type.xPacman + promotion_type.xRepublic.Day +
                         promotion_type.xValentine.s.Day, data = train_cam_mullag)
summary(model_mullagcam2)
vif(model_mullagcam2)

#Remove product_analytic_vertical.xCameraBatteryCharger and product_analytic_vertical.xFlash
#as they have high vif and p value
model_mullagcam3 <- lm(tot_gmv ~ week_no + Month + TV + Digital + Sponsorship + Content.Marketing +
                         Online.marketing + X.Affiliates + SEM + Other + NPS + discounted_mrp +
                         gmv_lag_2 + gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                         list_price_lag_2 + tv_ad_stock + dig_ad_stock + spon_ad_stock + content_ad_stock +
                         online_ad_stock + sem_ad_stock + product_analytic_vertical.xCameraAccessory +
                         product_analytic_vertical.xCameraBattery + 
                         product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                         product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                         product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                         product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                         product_analytic_vertical.xFilter + 
                         product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                         product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope +
                         promotion_type.xBig.Diwali.Sale + promotion_type.xBSD.5 + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xNo_promotion +
                         promotion_type.xPacman + promotion_type.xRepublic.Day +
                         promotion_type.xValentine.s.Day, data = train_cam_mullag)
summary(model_mullagcam3)
vif(model_mullagcam3)

#Remove promotion_type.xBig.Diwali.Sale + promotion_type.xValentine.s.Day
#as they have high p value and vif
model_mullagcam4 <- lm(tot_gmv ~ week_no + Month + TV + Digital + Sponsorship + Content.Marketing +
                         Online.marketing + X.Affiliates + SEM + Other + NPS + discounted_mrp +
                         gmv_lag_2 + gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                         list_price_lag_2 + tv_ad_stock + dig_ad_stock + spon_ad_stock + content_ad_stock +
                         online_ad_stock + sem_ad_stock + product_analytic_vertical.xCameraAccessory +
                         product_analytic_vertical.xCameraBattery + 
                         product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                         product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                         product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                         product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                         product_analytic_vertical.xFilter + 
                         product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                         product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope +
                         promotion_type.xBSD.5 + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xNo_promotion +
                         promotion_type.xPacman + promotion_type.xRepublic.Day, data = train_cam_mullag)
summary(model_mullagcam4)
vif(model_mullagcam4)

#Remove discounted_mrp as it has high vif and p value
model_mullagcam5 <- lm(tot_gmv ~ week_no + Month + TV + Digital + Sponsorship + Content.Marketing +
                         Online.marketing + X.Affiliates + SEM + Other + NPS + 
                         gmv_lag_2 + gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                         list_price_lag_2 + tv_ad_stock + dig_ad_stock + spon_ad_stock + content_ad_stock +
                         online_ad_stock + sem_ad_stock + product_analytic_vertical.xCameraAccessory +
                         product_analytic_vertical.xCameraBattery + 
                         product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                         product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                         product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                         product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                         product_analytic_vertical.xFilter + 
                         product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                         product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope +
                         promotion_type.xBSD.5 + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xNo_promotion +
                         promotion_type.xPacman + promotion_type.xRepublic.Day, data = train_cam_mullag)
summary(model_mullagcam5)
vif(model_mullagcam5)

#Remove promotion_type.xPacman as it has high vif and p value
model_mullagcam6 <- lm(tot_gmv ~ week_no + Month + TV + Digital + Sponsorship + Content.Marketing +
                         Online.marketing + X.Affiliates + SEM + Other + NPS + 
                         gmv_lag_2 + gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                         list_price_lag_2 + tv_ad_stock + dig_ad_stock + spon_ad_stock + content_ad_stock +
                         online_ad_stock + sem_ad_stock + product_analytic_vertical.xCameraAccessory +
                         product_analytic_vertical.xCameraBattery + 
                         product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                         product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                         product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                         product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                         product_analytic_vertical.xFilter + 
                         product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                         product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope +
                         promotion_type.xBSD.5 + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xNo_promotion +
                         promotion_type.xRepublic.Day, data = train_cam_mullag)
summary(model_mullagcam6)
vif(model_mullagcam6)

#remove Month + NPS + list_price_lag_2 + spon_ad_stock + promotion_type.xRepublic.Day
#as it has high p value
model_mullagcam7 <- lm(tot_gmv ~ week_no + TV + Digital + Sponsorship + Content.Marketing +
                         Online.marketing + X.Affiliates + SEM + Other +  
                         gmv_lag_2 + gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                         tv_ad_stock + dig_ad_stock + spon_ad_stock + content_ad_stock +
                         online_ad_stock + sem_ad_stock + product_analytic_vertical.xCameraAccessory +
                         product_analytic_vertical.xCameraBattery + 
                         product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                         product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                         product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                         product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                         product_analytic_vertical.xFilter + 
                         product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                         product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope +
                         promotion_type.xBSD.5 + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xNo_promotion, data = train_cam_mullag)
summary(model_mullagcam7)
vif(model_mullagcam7)


#Remove Content.Marketing + spon_ad_stock as it has high p value
model_mullagcam8 <- lm(tot_gmv ~ week_no + TV + Digital + Sponsorship + 
                         Online.marketing + X.Affiliates + SEM + Other +  
                         gmv_lag_2 + gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                         tv_ad_stock + dig_ad_stock +  content_ad_stock +
                         online_ad_stock + sem_ad_stock + product_analytic_vertical.xCameraAccessory +
                         product_analytic_vertical.xCameraBattery + 
                         product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                         product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                         product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                         product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                         product_analytic_vertical.xFilter + 
                         product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                         product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope +
                         promotion_type.xBSD.5 + 
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xNo_promotion, data = train_cam_mullag)
summary(model_mullagcam8)
vif(model_mullagcam8)

#Remove promotion_type.xBSD.5 + product_analytic_vertical.xCameraBattery + week_no + Other + gmv_lag_2
model_mullagcam9 <- lm(tot_gmv ~ TV + Digital + Sponsorship + 
                         Online.marketing + X.Affiliates + SEM +  
                         gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                         tv_ad_stock + dig_ad_stock +  content_ad_stock +
                         online_ad_stock + sem_ad_stock + product_analytic_vertical.xCameraAccessory +
                         product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                         product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                         product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                         product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                         product_analytic_vertical.xFilter + 
                         product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                         product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope +
                         promotion_type.xChristmas...New.Year.Sale + promotion_type.xNo_promotion, data = train_cam_mullag)
summary(model_mullagcam9)
vif(model_mullagcam9)

#Remove Sponsorship as it has high p value
model_mullagcam10 <- lm(tot_gmv ~ TV + Digital + 
                          Online.marketing + X.Affiliates + SEM +  
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                          tv_ad_stock + dig_ad_stock +  content_ad_stock +
                          online_ad_stock + sem_ad_stock + product_analytic_vertical.xCameraAccessory +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                          product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                          product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xFilter + 
                          product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                          product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope +
                          promotion_type.xChristmas...New.Year.Sale + promotion_type.xNo_promotion, data = train_cam_mullag)
summary(model_mullagcam10)
vif(model_mullagcam10)

#Remove dig_ad_stock as it has high p value
model_mullagcam11 <- lm(tot_gmv ~ TV + Digital + 
                          Online.marketing + X.Affiliates + SEM +  
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                          tv_ad_stock +  content_ad_stock +
                          online_ad_stock + sem_ad_stock + product_analytic_vertical.xCameraAccessory +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                          product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                          product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xFilter + 
                          product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                          product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope +
                          promotion_type.xChristmas...New.Year.Sale + promotion_type.xNo_promotion, data = train_cam_mullag)
summary(model_mullagcam11)
vif(model_mullagcam11)

#Remove promotion_type.xChristmas...New.Year.Sale + content_ad_stock as it has high p value
model_mullagcam12 <- lm(tot_gmv ~ TV + Digital + 
                          Online.marketing + X.Affiliates + SEM +  
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                          tv_ad_stock +
                          online_ad_stock + sem_ad_stock + product_analytic_vertical.xCameraAccessory +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                          product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                          product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xFilter + 
                          product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                          product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope +
                          promotion_type.xNo_promotion, data = train_cam_mullag)
summary(model_mullagcam12)
vif(model_mullagcam12)

#Remove promotion_type.xNo_promotion + sem_ad_stock as it has high p value
model_mullagcam13 <- lm(tot_gmv ~ TV + Digital + 
                          Online.marketing + X.Affiliates + SEM +  
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                          tv_ad_stock +
                          online_ad_stock + product_analytic_vertical.xCameraAccessory +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                          product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                          product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xFilter + 
                          product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                          product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope 
                        , data = train_cam_mullag)
summary(model_mullagcam13)
vif(model_mullagcam13)

#Remove Digital as it has high p value and vif
model_mullagcam14 <- lm(tot_gmv ~ TV +  
                          Online.marketing + X.Affiliates + SEM +  
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                          tv_ad_stock +
                          online_ad_stock + product_analytic_vertical.xCameraAccessory +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                          product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                          product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xFilter + 
                          product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                          product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope 
                        , data = train_cam_mullag)
summary(model_mullagcam14)
vif(model_mullagcam14)

#Remove SEM as it has high p value
model_mullagcam15 <- lm(tot_gmv ~ TV +  
                          Online.marketing + X.Affiliates +  
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                          tv_ad_stock +
                          online_ad_stock + product_analytic_vertical.xCameraAccessory +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                          product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                          product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xFilter + 
                          product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                          product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope 
                        , data = train_cam_mullag)
summary(model_mullagcam15)
vif(model_mullagcam15)

#Remove tv_ad_stock + online_ad_stock as it has high vif
model_mullagcam16 <- lm(tot_gmv ~ TV +  
                          Online.marketing + X.Affiliates +  
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                          product_analytic_vertical.xCameraAccessory +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                          product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                          product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xFilter + 
                          product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                          product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope 
                        , data = train_cam_mullag)
summary(model_mullagcam16)
vif(model_mullagcam16)

#Remove TV + Online.marketing + X.Affiliates as it has high vif and p value
model_mullagcam17 <- lm(tot_gmv ~   
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 +
                          product_analytic_vertical.xCameraAccessory +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                          product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                          product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xFilter + 
                          product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                          product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope 
                        , data = train_cam_mullag)
summary(model_mullagcam17)
vif(model_mullagcam17)

#Remove gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 as it has high p value
model_mullagcam18 <- lm(tot_gmv ~ 
                          product_analytic_vertical.xCameraAccessory +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                          product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                          product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xFilter + 
                          product_analytic_vertical.xLens + product_analytic_vertical.xSoftbox + 
                          product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope 
                        , data = train_cam_mullag)
summary(model_mullagcam18)
vif(model_mullagcam18)

#Remove product_analytic_vertical.xFilter  as it has high p value
model_mullagcam19 <- lm(tot_gmv ~ 
                          product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xLens +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraFilmRolls + product_analytic_vertical.xCameraHousing +
                          product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraMount +
                          product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xSoftbox + 
                          product_analytic_vertical.xStrap + product_analytic_vertical.xTelescope, 
                        data = train_cam_mullag)
summary(model_mullagcam19)
vif(model_mullagcam19)

#Remove product_analytic_vertical.xCameraFilmRolls +  product_analytic_vertical.xCameraMount
#product_analytic_vertical.xCameraRemoteControl + product_analytic_vertical.xStrap as it has high vif
model_mullagcam20 <- lm(tot_gmv ~ 
                          product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xLens +
                          product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraHousing +
                          product_analytic_vertical.xCameraMicrophone + 
                          product_analytic_vertical.xExtensionTube +
                          product_analytic_vertical.xSoftbox + 
                          product_analytic_vertical.xTelescope, 
                        data = train_cam_mullag)
summary(model_mullagcam20)
vif(model_mullagcam20)

#Remove product_analytic_vertical.xTelescope + product_analytic_vertical.xSoftbox
#product_analytic_vertical.xCameraHousing + product_analytic_vertical.xCameraBatteryGrip
model_mullagcam21 <- lm(tot_gmv ~ 
                          product_analytic_vertical.xCameraAccessory + product_analytic_vertical.xLens +
                          product_analytic_vertical.xCameraEyeCup +
                          product_analytic_vertical.xCameraMicrophone + 
                          product_analytic_vertical.xExtensionTube,
                        data = train_cam_mullag)
summary(model_mullagcam21)
vif(model_mullagcam21)

final_cam_mullag <- model_mullagcam21
#Multiple R-squared:  0.016,	Adjusted R-squared:  0.008 

#______________________________________________________________________________________________________________#
#prediction on test data
cam_mullag_prediction <- predict(final_cam_mullag, test_cam_mullag[,-3])
test_cam_mullag$predicted_gmv <- cam_mullag_prediction

cam_mullag_r <- cor(test_cam_mullag$tot_gmv, test_cam_mullag$predicted_gmv  )
cam_rsquared <- cam_mullag_r^2
cam_rsquared   
#Rsquare on test =  0.04
#____________________________________________________________________________________________________________#
cam_lm_cv <- cv.lm(data = weekly_ad_cam_mullag , form.lm = final_cam_mullag, m =10)
#ms = 1.53

#_____________________________________________________________________________________________________________________#
#Plot Elasticity
elasticity <- function(var) {
  x <- as.numeric(final_cam_mullag$coefficients[var] )
  return(x)
}

var_list <- list()

for(i in 2:length(final_cam_mullag$coefficients)) {
  var_list[i-1] <- elasticity(names(final_cam_mullag$coefficients)[i])
}

elasticity.outputs <- data.frame(names(final_cam_mullag$coefficients[2:length(final_cam_mullag$coefficients)]))
elasticity.outputs <- cbind(elasticity.outputs,do.call(rbind.data.frame, var_list))
colnames(elasticity.outputs) <- c("Variable","Elasticity")

elasticity.outputs$direction <- ifelse(elasticity.outputs$Elasticity > 0, "Positive", "Negative")
elasticity.outputs <- arrange( elasticity.outputs , -Elasticity)

ggplot(data=elasticity.outputs[, ], aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Camera Accessory -Multiplicative Lag Model") +xlab("Variables")

################################ MULTIPLICATIVE LAG MODELLING ###########################################################
#################### 3. PRODUCT SUB CATEGORY: GAMING ACCESSORY ###########################
weekly_ad_game_mullag <- weekly_consumer_ad_lag_game1
weekly_ad_game_mullag <-na.omit(weekly_ad_game_mullag)

weekly_ad_game_mullag1  <- lapply (weekly_ad_game_mullag[,1:35] ,function(x) ifelse ( x==0 , 0, log(abs(x)))*sign(x) )
weekly_ad_game_mullag <- data.frame( cbind( weekly_ad_game_mullag1 ,weekly_ad_game_mullag[,36:97] ))


set.seed(200)


trainindices= sample(1:nrow(weekly_ad_game_mullag), 0.7*nrow(weekly_ad_game_mullag))

#Generate the train data set
train_game_mullag = weekly_ad_game_mullag[trainindices,]

#Similarly store the rest of the observations into an object "test".
test_game_mullag = weekly_ad_game_mullag[-trainindices,]

model_mullaggame1 <- lm(tot_gmv ~ ., data = train_game_mullag)
summary(model_mullaggame1)
#Multiple R-squared:  0.86,	Adjusted R-squared:  0.84 

model_step_mullag_game <- stepAIC(model_mullaggame1, direction = "both")
summary(model_step_mullag_game)
vif(model_step_mullag_game)

#From the last step of AIC model, pick all variables that have - sign for the next step of modelling
#Remove list_price as it has high vif
model_mullaggame2 <- lm(tot_gmv ~ week_no + Month + TV + Content.Marketing + Online.marketing +
                          X.Affiliates + SEM + Radio + Other + NPS + discounted_mrp + gmv_lag_1 + gmv_lag_2 +
                          gmv_lag_3 + gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                          list_price_lag_2 + price_change_from_w1 + list_price_change_from_w2 + tv_ad_stock +
                          dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                          product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                          product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                          product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingKeyboard + product_analytic_vertical.xGamingMemoryCard +
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                          product_analytic_vertical.xMotionController + promotion_type.xBSD.5 + 
                          promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                          promotion_type.xNo_promotion + promotion_type.xPacman + promotion_type.xRepublic.Day +
                          promotion_type.xValentine.s.Day , data = train_game_mullag)
summary(model_mullaggame2)
vif(model_mullaggame2)

#Remove Month as it has high vif and p value
model_mullaggame3 <- lm(tot_gmv ~ week_no + TV + Content.Marketing + Online.marketing +
                          X.Affiliates + SEM + Radio + Other + NPS + discounted_mrp + gmv_lag_1 + gmv_lag_2 +
                          gmv_lag_3 + gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                          list_price_lag_2 + price_change_from_w1 + list_price_change_from_w2 + tv_ad_stock +
                          dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                          product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                          product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                          product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingKeyboard + product_analytic_vertical.xGamingMemoryCard +
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                          product_analytic_vertical.xMotionController + promotion_type.xBSD.5 + 
                          promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                          promotion_type.xNo_promotion + promotion_type.xPacman + promotion_type.xRepublic.Day +
                          promotion_type.xValentine.s.Day , data = train_game_mullag)
summary(model_mullaggame3)
vif(model_mullaggame3)

#Remove list_price_lag_2 + list_price_change_from_w2 as it has high p value and vif
model_mullaggame4 <- lm(tot_gmv ~ week_no + TV + Content.Marketing + Online.marketing +
                          X.Affiliates + SEM + Radio + Other + NPS + discounted_mrp + gmv_lag_1 + gmv_lag_2 +
                          gmv_lag_3 + gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                          price_change_from_w1  + tv_ad_stock +
                          dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                          product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                          product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                          product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingKeyboard + product_analytic_vertical.xGamingMemoryCard +
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                          product_analytic_vertical.xMotionController + promotion_type.xBSD.5 + 
                          promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                          promotion_type.xNo_promotion + promotion_type.xPacman + promotion_type.xRepublic.Day +
                          promotion_type.xValentine.s.Day , data = train_game_mullag)
summary(model_mullaggame4)
vif(model_mullaggame4)

#Remove product_analytic_vertical.xGamingMemoryCard + product_analytic_vertical.xMotionController
#as it has high p value and vif
model_mullaggame5 <- lm(tot_gmv ~ week_no + TV + Content.Marketing + Online.marketing +
                          X.Affiliates + SEM + Radio + Other + NPS + discounted_mrp + gmv_lag_1 + gmv_lag_2 +
                          gmv_lag_3 + gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                          price_change_from_w1  + tv_ad_stock +
                          dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                          product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                          product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                          product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                          promotion_type.xBSD.5 + 
                          promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                          promotion_type.xNo_promotion + promotion_type.xPacman + promotion_type.xRepublic.Day +
                          promotion_type.xValentine.s.Day , data = train_game_mullag)
summary(model_mullaggame5)
vif(model_mullaggame5)

#Remove gmv_lag_3 as it has high p value and vif
model_mullaggame6 <- lm(tot_gmv ~ week_no + TV + Content.Marketing + Online.marketing +
                          X.Affiliates + SEM + Radio + Other + NPS + discounted_mrp + gmv_lag_1 + gmv_lag_2 +
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                          price_change_from_w1  + tv_ad_stock +
                          dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                          product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                          product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                          product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                          promotion_type.xBSD.5 + 
                          promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                          promotion_type.xNo_promotion + promotion_type.xPacman + promotion_type.xRepublic.Day +
                          promotion_type.xValentine.s.Day , data = train_game_mullag)
summary(model_mullaggame6)
vif(model_mullaggame6)

#Remove Other as it has high vif
model_mullaggame7 <- lm(tot_gmv ~ week_no + TV + Content.Marketing + Online.marketing +
                          X.Affiliates + SEM + Radio + NPS + discounted_mrp + gmv_lag_1 + gmv_lag_2 +
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                          price_change_from_w1  + tv_ad_stock +
                          dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                          product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                          product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                          product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                          promotion_type.xBSD.5 + 
                          promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                          promotion_type.xNo_promotion + promotion_type.xPacman + promotion_type.xRepublic.Day +
                          promotion_type.xValentine.s.Day , data = train_game_mullag)
summary(model_mullaggame7)
vif(model_mullaggame7)

#Remove promotion_type.xPacman + promotion_type.xValentine.s.Day as it has high p value and vif
model_mullaggame8 <- lm(tot_gmv ~ week_no + TV + Content.Marketing + Online.marketing +
                          X.Affiliates + SEM + Radio + NPS + discounted_mrp + gmv_lag_1 + gmv_lag_2 +
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                          price_change_from_w1  + tv_ad_stock +
                          dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                          product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                          product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                          product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                          promotion_type.xBSD.5 + 
                          promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                          promotion_type.xNo_promotion + promotion_type.xRepublic.Day,
                        data = train_game_mullag)
summary(model_mullaggame8)
vif(model_mullaggame8)

#Remove X.Affiliates as it has high vif
model_mullaggame9 <- lm(tot_gmv ~ week_no + TV + Content.Marketing + Online.marketing +
                          SEM + Radio + NPS + discounted_mrp + gmv_lag_1 + gmv_lag_2 +
                          gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                          price_change_from_w1  + tv_ad_stock +
                          dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                          product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                          product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                          product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                          product_analytic_vertical.xGamingKeyboard + 
                          product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                          promotion_type.xBSD.5 + 
                          promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                          promotion_type.xNo_promotion + promotion_type.xRepublic.Day,
                        data = train_game_mullag)
summary(model_mullaggame9)
vif(model_mullaggame9)

#Remove Online.marketing as it has high vif and p value
model_mullaggame10 <- lm(tot_gmv ~ week_no + TV + Content.Marketing + 
                           SEM + Radio + NPS + discounted_mrp + gmv_lag_1 + gmv_lag_2 +
                           gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                           price_change_from_w1  + tv_ad_stock +
                           dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xBSD.5 + 
                           promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                           promotion_type.xNo_promotion + promotion_type.xRepublic.Day,
                         data = train_game_mullag)
summary(model_mullaggame10)
vif(model_mullaggame10)

#Remove week_no + Content.Marketing + Radio + gmv_lag_2 as it has high p value and vif
model_mullaggame11 <- lm(tot_gmv ~ TV +  
                           SEM + NPS + discounted_mrp + gmv_lag_1 + 
                           gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                           price_change_from_w1  + tv_ad_stock +
                           dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xBSD.5 + 
                           promotion_type.xChristmas...New.Year.Sale + promotion_type.xDaussera.sale + 
                           promotion_type.xNo_promotion + promotion_type.xRepublic.Day,
                         data = train_game_mullag)
summary(model_mullaggame11)
vif(model_mullaggame11)

#Remove  promotion_type.xBSD.5 + promotion_type.xChristmas...New.Year.Sale as it has high vif and p value
model_mullaggame12 <- lm(tot_gmv ~ TV +  
                           SEM + NPS + discounted_mrp + gmv_lag_1 + 
                           gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                           price_change_from_w1  + tv_ad_stock +
                           dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale + 
                           promotion_type.xNo_promotion + promotion_type.xRepublic.Day,
                         data = train_game_mullag)
summary(model_mullaggame12)
vif(model_mullaggame12)

#Remove TV + SEM + NPS as it has high vif
model_mullaggame13 <- lm(tot_gmv ~ discounted_mrp + gmv_lag_1 + 
                           gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                           price_change_from_w1  + tv_ad_stock +
                           dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale + 
                           promotion_type.xNo_promotion + promotion_type.xRepublic.Day,
                         data = train_game_mullag)
summary(model_mullaggame13)
vif(model_mullaggame13)

#Remove price_change_from_w1  + tv_ad_stock as they have high p value
model_mullaggame14 <- lm(tot_gmv ~ discounted_mrp + gmv_lag_1 + 
                           gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                           dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale + 
                           promotion_type.xNo_promotion + promotion_type.xRepublic.Day,
                         data = train_game_mullag)
summary(model_mullaggame14)
vif(model_mullaggame14)

#Remove discounted_mrp as it has high p value and vif
model_mullaggame15 <- lm(tot_gmv ~ gmv_lag_1 + 
                           gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                           dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale + 
                           promotion_type.xNo_promotion + promotion_type.xRepublic.Day,
                         data = train_game_mullag)
summary(model_mullaggame15)
vif(model_mullaggame15)

#Remove promotion_type.xRepublic.Day as it has high p value and vif
model_mullaggame16 <- lm(tot_gmv ~ gmv_lag_1 + 
                           gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                           dig_ad_stock + spon_ad_stock + content_ad_stock + affiliate_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingAccessoryKit + product_analytic_vertical.xGamingAdapter +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale + 
                           promotion_type.xNo_promotion,
                         data = train_game_mullag)
summary(model_mullaggame16)
vif(model_mullaggame16)

#Remove affiliate_ad_stock + product_analytic_vertical.xGamingAccessoryKit as it has high p value and vif
model_mullaggame17 <- lm(tot_gmv ~ gmv_lag_1 + 
                           gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                           dig_ad_stock + spon_ad_stock + content_ad_stock +
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingAdapter +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale + 
                           promotion_type.xNo_promotion,
                         data = train_game_mullag)
summary(model_mullaggame17)
vif(model_mullaggame17)

#Remove content_ad_stock and product_analytic_vertical.xGamingAdapter as it has high p value
model_mullaggame18 <- lm(tot_gmv ~ gmv_lag_1 + 
                           gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                           dig_ad_stock + spon_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale + 
                           promotion_type.xNo_promotion,
                         data = train_game_mullag)
summary(model_mullaggame18)
vif(model_mullaggame18)

#Remove promotion_type.xNo_promotion as it has high p value and vif
model_mullaggame19 <- lm(tot_gmv ~ gmv_lag_1 + 
                           gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                           dig_ad_stock + spon_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale,
                         data = train_game_mullag)
summary(model_mullaggame19)
vif(model_mullaggame19)

#Remove gmv_lag_1 as it has high vif
model_mullaggame20 <- lm(tot_gmv ~  
                           gmv_change_from_w1 + gmv_change_from_w2 + gmv_change_from_w3 + 
                           dig_ad_stock + spon_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale,
                         data = train_game_mullag)
summary(model_mullaggame20)
vif(model_mullaggame20)

#Remove gmv_change_from_1, 2, 3 as they have high p value
model_mullaggame21 <- lm(tot_gmv ~  
                           dig_ad_stock + spon_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale,
                         data = train_game_mullag)
summary(model_mullaggame21)
vif(model_mullaggame21)

#Remove spon_ad_stock as it has high vif and p value
model_mullaggame22 <- lm(tot_gmv ~  dig_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingKeyboard + 
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale,
                         data = train_game_mullag)
summary(model_mullaggame22)
vif(model_mullaggame22)

#Remove product_analytic_vertical.xGamingKeyboard as it has high p value
model_mullaggame23 <- lm(tot_gmv ~  dig_ad_stock + 
                           product_analytic_vertical.xCoolingPad + product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingChargingStation + product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale,
                         data = train_game_mullag)
summary(model_mullaggame23)
vif(model_mullaggame23)

#Remove product_analytic_vertical.xGamingChargingStation
model_mullaggame24 <- lm(tot_gmv ~  dig_ad_stock + product_analytic_vertical.xCoolingPad +
                           product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale,
                         data = train_game_mullag)
summary(model_mullaggame24)
vif(model_mullaggame24)

#Remove product_analytic_vertical.xGamingMouse
model_mullaggame25 <- lm(tot_gmv ~  dig_ad_stock + product_analytic_vertical.xCoolingPad +
                           product_analytic_vertical.xGamePad +
                           product_analytic_vertical.xGamingHeadset +
                           product_analytic_vertical.xGamingSpeaker +
                           promotion_type.xDaussera.sale,
                         data = train_game_mullag)
summary(model_mullaggame25)
vif(model_mullaggame25)

final_game_mullag <- model_mullaggame25
#Multiple R-squared:  0.439,	Adjusted R-squared:  0.431 

#________________________________________________________________________________________________________________#
#prediction on test data
game_mullag_prediction <- predict(final_game_mullag, test_game_mullag[,-3])
test_game_mullag$predicted_gmv <- game_mullag_prediction

game_r <- cor(test_game_mullag$tot_gmv, test_game_mullag$predicted_gmv  )
game_rsquared <- game_r^2
game_rsquared   
#Rsquare on test =  0.471

#________________________________________________________________________________________________________________#
mullag_game_cv <- cv.lm(data = train_game_mullag , form.lm = formula(tot_gmv~ dig_ad_stock + product_analytic_vertical.xCoolingPad +
                                                                       product_analytic_vertical.xGamePad +
                                                                       product_analytic_vertical.xGamingHeadset +
                                                                       product_analytic_vertical.xGamingSpeaker +
                                                                       promotion_type.xDaussera.sale), m = 10)
#ms = 1.79
#_____________________________________________________________________________________________________________________#
# Plot elasticity 

elasticity <- function(var) {
  x <- as.numeric(final_game_mullag$coefficients[var] )
  return(x)
}

var_list <- list()

for(i in 2:length(final_game_mullag$coefficients)) {
  var_list[i-1] <- elasticity(names(final_game_mullag$coefficients)[i])
}

elasticity.outputs <- data.frame(names(final_game_mullag$coefficients[2:length(final_game_mullag$coefficients)]))
elasticity.outputs <- cbind(elasticity.outputs,do.call(rbind.data.frame, var_list))
colnames(elasticity.outputs) <- c("Variable","Elasticity")

elasticity.outputs$direction <- ifelse(elasticity.outputs$Elasticity > 0, "Positive", "Negative")
elasticity.outputs <- arrange( elasticity.outputs , -Elasticity)

ggplot(data=elasticity.outputs[, ], aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Gaming Accessory -Multiplicative Lag Model") +xlab("Variables")

#########################################################################################################
#################################### KOYCK MODELLING #########################################
#################### 1. PRODUCT SUB CATEGORY: CAMERA ACCESSORY ###########################
str(CameraAccessory)
sum(is.na(CameraAccessory))
Cam_Access_Koyck <- CameraAccessory

# Creating lag Variable as per requirement of Koyck model 
Cam_Access_Koyck <- slide(Cam_Access_Koyck, Var = "tot_gmv",slideBy = -1)
str(Cam_Access_Koyck)

# Omit na if any and perform scaling operation
Cam_Acc_Koy_lagvar_omit <- na.omit(Cam_Access_Koyck)
Cam_Acc_Koy_lagvar_prt1 <- data.frame(scale(Cam_Acc_Koy_lagvar_omit[,c(1:15)]))
Cam_Acc_Koy_lagvar_prt2 <- data.frame(Cam_Acc_Koy_lagvar_omit[,16:77])
Cam_Acc_Koy_lagvar_prt3 <- data.frame(scale(Cam_Acc_Koy_lagvar_omit[,78]))

# Combine above three parts into one file back after scaling

Cam_Acc_Koy_lagvar <- cbind(Cam_Acc_Koy_lagvar_prt1, Cam_Acc_Koy_lagvar_prt2, Cam_Acc_Koy_lagvar_prt3)
str(Cam_Acc_Koy_lagvar)

# Month and weekno columns have been removed as they aren't required
Cam_Acc_Koy_lagvar <- Cam_Acc_Koy_lagvar[,-c(1,2)]

# Divide above dataset into train & test datasets
set.seed(200)
trainindices= sample(1:nrow(Cam_Acc_Koy_lagvar), 0.7*nrow(Cam_Acc_Koy_lagvar))
Cam_Acc_Koy_train = Cam_Acc_Koy_lagvar[trainindices,]
Cam_Acc_Koy_test = Cam_Acc_Koy_lagvar[-trainindices,]
str(Cam_Acc_Koy_train)
names(Cam_Acc_Koy_train)


#Model Building
Koycam_model1 <- lm(tot_gmv~.,Cam_Acc_Koy_train)
summary(Koycam_model1)


# Model bulding evaluation with stepAIC function
Koycam_model2 <- stepAIC(Koycam_model1,direction = "both")
summary(Koycam_model2)
vif(Koycam_model2)

# Building 3rd model with all of the StepAIC model variables

Koycam_model3<- lm(formula = tot_gmv ~ product_analytic_vertical.xCameraBag + 
                     promotion_type.xEid...Rathayatra.sale + product_analytic_vertical.xCameraBattery +
                     list_price + product_analytic_vertical.xFlash + Online.marketing + X.Affiliates +
                     Content.Marketing + discounted_mrp + NPS + promotion_type.xNo_promotion + TV + 
                     product_analytic_vertical.xCameraTripod + promotion_type.xChristmas...New.Year.Sale + 
                     product_analytic_vertical.xTeleconverter + product_analytic_vertical.xFlashShoeAdapter +
                     promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                     product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                     product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                     product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                     product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                     product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                     product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                     product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                     product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                     product_analytic_vertical.xCameraMount +
                     product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model3)
vif(Koycam_model3)

# Removing Online.marketing variables first as Online.marketing variable has 
# p value of List orice is high and vif is also high

Koycam_model4<- lm(formula = tot_gmv ~ product_analytic_vertical.xCameraBag + 
                     promotion_type.xEid...Rathayatra.sale + product_analytic_vertical.xCameraBattery +
                     list_price + product_analytic_vertical.xFlash + X.Affiliates +
                     Content.Marketing + discounted_mrp + NPS + promotion_type.xNo_promotion + TV + 
                     product_analytic_vertical.xCameraTripod + promotion_type.xChristmas...New.Year.Sale + 
                     product_analytic_vertical.xTeleconverter + product_analytic_vertical.xFlashShoeAdapter +
                     promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                     product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                     product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                     product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                     product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                     product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                     product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                     product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                     product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                     product_analytic_vertical.xCameraMount +
                     product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model4)
vif(Koycam_model4)

# Removing Content.Marketing variable as VIF and p value both are very high

Koycam_model5<- lm(formula = tot_gmv ~ product_analytic_vertical.xCameraBag + 
                     promotion_type.xEid...Rathayatra.sale + product_analytic_vertical.xCameraBattery +
                     list_price + product_analytic_vertical.xFlash + X.Affiliates +
                     discounted_mrp + NPS + promotion_type.xNo_promotion + TV + 
                     product_analytic_vertical.xCameraTripod + promotion_type.xChristmas...New.Year.Sale + 
                     product_analytic_vertical.xTeleconverter + product_analytic_vertical.xFlashShoeAdapter +
                     promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                     product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                     product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                     product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                     product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                     product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                     product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                     product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                     product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                     product_analytic_vertical.xCameraMount +
                     product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model5)
vif(Koycam_model5)

# Removing discounted_mrp as P value and vif both are high

Koycam_model6<- lm(formula = tot_gmv ~ product_analytic_vertical.xCameraBag + 
                     promotion_type.xEid...Rathayatra.sale + product_analytic_vertical.xCameraBattery +
                     list_price + product_analytic_vertical.xFlash + X.Affiliates +
                     NPS + promotion_type.xNo_promotion + TV + 
                     product_analytic_vertical.xCameraTripod + promotion_type.xChristmas...New.Year.Sale + 
                     product_analytic_vertical.xTeleconverter + product_analytic_vertical.xFlashShoeAdapter +
                     promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                     product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                     product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                     product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                     product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                     product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                     product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                     product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                     product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                     product_analytic_vertical.xCameraMount +
                     product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model6)
vif(Koycam_model6)

# Remove NPS as both vif and p values are high 

Koycam_model7<- lm(formula = tot_gmv ~ product_analytic_vertical.xCameraBag + 
                     promotion_type.xEid...Rathayatra.sale + product_analytic_vertical.xCameraBattery +
                     list_price + product_analytic_vertical.xFlash + X.Affiliates +
                     promotion_type.xNo_promotion + TV + 
                     product_analytic_vertical.xCameraTripod + promotion_type.xChristmas...New.Year.Sale + 
                     product_analytic_vertical.xTeleconverter + product_analytic_vertical.xFlashShoeAdapter +
                     promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                     product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                     product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                     product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                     product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                     product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                     product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                     product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                     product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                     product_analytic_vertical.xCameraMount +
                     product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model7)
vif(Koycam_model7)

# Remove list_price as both VIF anf p values are high 

Koycam_model8<- lm(formula = tot_gmv ~ product_analytic_vertical.xCameraBag + 
                     promotion_type.xEid...Rathayatra.sale + product_analytic_vertical.xCameraBattery +
                     product_analytic_vertical.xFlash + X.Affiliates +
                     promotion_type.xNo_promotion + TV + 
                     product_analytic_vertical.xCameraTripod + promotion_type.xChristmas...New.Year.Sale + 
                     product_analytic_vertical.xTeleconverter + product_analytic_vertical.xFlashShoeAdapter +
                     promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                     product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                     product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                     product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                     product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                     product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                     product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                     product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                     product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                     product_analytic_vertical.xCameraMount +
                     product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model8)
vif(Koycam_model8)

# Removing promotion_type.xEid...Rathayatra.sale and product_analytic_vertical.xFlash as p values are very high 

Koycam_model9<- lm(formula = tot_gmv ~ product_analytic_vertical.xCameraBag + 
                     product_analytic_vertical.xCameraBattery +
                     X.Affiliates +
                     promotion_type.xNo_promotion + TV + 
                     product_analytic_vertical.xCameraTripod + promotion_type.xChristmas...New.Year.Sale + 
                     product_analytic_vertical.xTeleconverter + product_analytic_vertical.xFlashShoeAdapter +
                     promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                     product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                     product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                     product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                     product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                     product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                     product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                     product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                     product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                     product_analytic_vertical.xCameraMount +
                     product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model9)
vif(Koycam_model9)

# Removing product_analytic_vertical.xCameraBag and product_analytic_vertical.xCameraBattery as 
# p values are very high 

Koycam_model10 <- lm(formula = tot_gmv ~ X.Affiliates +
                       promotion_type.xNo_promotion + TV + 
                       product_analytic_vertical.xCameraTripod + promotion_type.xChristmas...New.Year.Sale + 
                       product_analytic_vertical.xTeleconverter + product_analytic_vertical.xFlashShoeAdapter +
                       promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                       product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                       product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                       product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model10)
vif(Koycam_model10)

# Removing product_analytic_vertical.xCameraTripod as p value is very high 

Koycam_model11 <- lm(formula = tot_gmv ~ X.Affiliates +
                       promotion_type.xNo_promotion + TV + 
                       promotion_type.xChristmas...New.Year.Sale + 
                       product_analytic_vertical.xTeleconverter + product_analytic_vertical.xFlashShoeAdapter +
                       promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                       product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                       product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                       product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model11)
vif(Koycam_model11)

# Removing tv as both VIF and p values are very high 

Koycam_model12 <- lm(formula = tot_gmv ~ X.Affiliates +
                       promotion_type.xNo_promotion + 
                       promotion_type.xChristmas...New.Year.Sale + 
                       product_analytic_vertical.xTeleconverter + product_analytic_vertical.xFlashShoeAdapter +
                       promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                       product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                       product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                       product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model12)
vif(Koycam_model12)

# Removing product_analytic_vertical.xTeleconverter and product_analytic_vertical.xFlashShoeAdapter 
# as p values are very high 

Koycam_model13 <- lm(formula = tot_gmv ~ X.Affiliates +
                       promotion_type.xNo_promotion + 
                       promotion_type.xChristmas...New.Year.Sale + 
                       promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                       product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                       product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                       product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model13)
vif(Koycam_model13)

# Removing X.Affiliates and promotion_type.xNo_promotion as p values are very high 

Koycam_model14 <- lm(formula = tot_gmv ~ promotion_type.xChristmas...New.Year.Sale + 
                       promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                       product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                       product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                       product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model14)
vif(Koycam_model14)

# Removing promotion_type.xChristmas...New.Year.Sale as p value is very high 

Koycam_model15 <- lm(formula = tot_gmv ~ promotion_type.xDaussera.sale + product_analytic_vertical.xReflectorUmbrella + 
                       product_analytic_vertical.xCameraLEDLight + Digital + product_analytic_vertical.xSoftbox +
                       product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                       product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model15)
vif(Koycam_model15)

# Removing product_analytic_vertical.xReflectorUmbrella and product_analytic_vertical.xCameraLEDLight
# as p values are very high 

Koycam_model16 <- lm(formula = tot_gmv ~ promotion_type.xDaussera.sale + 
                       Digital + product_analytic_vertical.xSoftbox +
                       product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                       product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model16)
vif(Koycam_model16)

# Removing Digital as VIF is very high 

Koycam_model17 <- lm(formula = tot_gmv ~ promotion_type.xDaussera.sale + 
                       product_analytic_vertical.xSoftbox +
                       product_analytic_vertical.xCameraFilmRolls + Sponsorship + 
                       product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model17)
vif(Koycam_model17)

# Removing Sponsorship as p value is relatively very high 

Koycam_model18 <- lm(formula = tot_gmv ~ promotion_type.xDaussera.sale + 
                       product_analytic_vertical.xSoftbox +
                       product_analytic_vertical.xCameraFilmRolls + 
                       product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model18)
vif(Koycam_model18)

# Remove product_analytic_vertical.xSoftbox as p value is relatively very high 

Koycam_model19 <- lm(formula = tot_gmv ~ promotion_type.xDaussera.sale + 
                       product_analytic_vertical.xCameraFilmRolls + 
                       product_analytic_vertical.xCameraHousing + promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model19)
vif(Koycam_model19)

# Removing product_analytic_vertical.xCameraHousing as p value is relatively high

Koycam_model20 <- lm(formula = tot_gmv ~ promotion_type.xDaussera.sale + 
                       product_analytic_vertical.xCameraFilmRolls + 
                       promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraMicrophone + product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model20)
vif(Koycam_model20)

# Remove product_analytic_vertical.xCameraMicrophone as p values are relatively high 

Koycam_model21 <- lm(formula = tot_gmv ~ promotion_type.xDaussera.sale + 
                       product_analytic_vertical.xCameraFilmRolls + 
                       promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model21)
vif(Koycam_model21)

# Remove promotion_type.xDaussera.sale as p value is relatively very high 

Koycam_model22 <- lm(formula = tot_gmv ~ product_analytic_vertical.xCameraFilmRolls + 
                       promotion_type.xRakshabandhan.Sale +
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model22)
vif(Koycam_model22)

# Removing promotion_type.xRakshabandhan.Sale as p value is relatively high 

Koycam_model23 <- lm(formula = tot_gmv ~ product_analytic_vertical.xCameraFilmRolls + 
                       product_analytic_vertical.xCameraBatteryCharger + product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model23)
vif(Koycam_model23)

# Remove product_analytic_vertical.xCameraBatteryCharger as p value is high 

Koycam_model24 <- lm(formula = tot_gmv ~ product_analytic_vertical.xCameraFilmRolls + 
                       product_analytic_vertical.xFilter + 
                       product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model24)
vif(Koycam_model24)


# Remove product_analytic_vertical.xFilter as p value is high 

Koycam_model25 <- lm(formula = tot_gmv ~ product_analytic_vertical.xCameraFilmRolls + 
                       product_analytic_vertical.xCameraEyeCup +
                       product_analytic_vertical.xExtensionTube + product_analytic_vertical.xCameraRemoteControl +
                       product_analytic_vertical.xStrap + product_analytic_vertical.xCameraAccessory +
                       product_analytic_vertical.xCameraBatteryGrip + product_analytic_vertical.xTelescope +
                       product_analytic_vertical.xCameraMount +
                       product_analytic_vertical.xLens, data = Cam_Acc_Koy_train)
summary(Koycam_model25)
vif(Koycam_model25)

# Koycam_model25 is out final model as removing any other variables makes intercept itself insignificant 
# Multiple R-squared:  0.726,	Adjusted R-squared:  0.722
# -----------------------------------------------------------------------------------------------------------------

par(mfrow = c(2,2))
plot(Koycam_model25, main = "Final Camera Accessory - Koyck Model")
dev.off()

# Prediction using test dataset
Cam_Acc_Koy_predict <- predict(Koycam_model25, Cam_Acc_Koy_test)
RMSE(Cam_Acc_Koy_test$tot_gmv,Cam_Acc_Koy_predict)
Cam_Acc_Koy_r <- cor(Cam_Acc_Koy_test$tot_gmv, Cam_Acc_Koy_predict)
Cam_Acc_Koy_rsquared <- Cam_Acc_Koy_r^2
Cam_Acc_Koy_rsquared

# R square if test data prediction is  0.667

## Cross validation
Cam_Acc_Koy_crosvald <- cv.lm(data = Cam_Acc_Koy_train, form.lm = formula(Koycam_model25),m = 10,
                              main = " Camera Accessory Cross Validation")
attr(Cam_Acc_Koy_crosvald, "ms")
# ms value for cross validation = 0.289

# --------------- Deriving elasticity ----------------------------------------------------------------
elasticity <- function(var) {
  x <- as.numeric(Koycam_model25$coefficients[var] * mean(Cam_Acc_Koy_train[,var])/mean(Cam_Acc_Koy_train$tot_gmv))
  return(x)
}

Koycam_list <- list()

for(i in 2:length(Koycam_model25$coefficients)) {
  Koycam_list[i-1] <- elasticity(names(Koycam_model25$coefficients)[i])
}

elasticity_koycam <- data.frame(names(Koycam_model25$coefficients[2:length(Koycam_model25$coefficients)]))
elasticity_koycam <- cbind(elasticity_koycam,do.call(rbind.data.frame, Koycam_list))
colnames(elasticity_koycam) <- c("Variable","Elasticity")

elasticity_koycam$direction <- ifelse(elasticity_koycam$Elasticity > 0, "Positive", "Negative")

ggplot(data=elasticity_koycam, aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Koyck Model for Camera Accessory") +xlab("Variables")  

############################ KOYCK MODELLING #############################################################
# ###############################2. PRODUCT SUB CATEGORY: GAMING ACCESSORY #####################################
# --------------------------------------------------------------------------------------------------------------

str(GamingAccessory)
sum(is.na(GamingAccessory))
Game_Access_Koyck <- GamingAccessory

# Creating lag Variable as per requirement of Koyck model 
Game_Access_Koyck <- slide(Game_Access_Koyck, Var = "tot_gmv",slideBy = -1)
str(Game_Access_Koyck)

# Omit na if any and perform scaling operation
Game_Acc_Koy_lagvar_omit <- na.omit(Game_Access_Koyck)
Game_Acc_Koy_lagvar_prt1 <- data.frame(scale(Game_Acc_Koy_lagvar_omit[,c(1:15)]))
Game_Acc_Koy_lagvar_prt2 <- data.frame(Game_Acc_Koy_lagvar_omit[,16:77])
Game_Acc_Koy_lagvar_prt3 <- data.frame(scale(Game_Acc_Koy_lagvar_omit[,78]))

# Combine above three parts into one file bacl after scaling

Game_Acc_Koy_lagvar <- cbind(Game_Acc_Koy_lagvar_prt1, Game_Acc_Koy_lagvar_prt2, Game_Acc_Koy_lagvar_prt3)
str(Game_Acc_Koy_lagvar)

# Month and weekno columns have been removed as they aren't required
Game_Acc_Koy_lagvar <- Game_Acc_Koy_lagvar[,-c(1,2)]

# Divide above dataset into train & test datasets
set.seed(100)
trainindices= sample(1:nrow(Game_Acc_Koy_lagvar), 0.6*nrow(Game_Acc_Koy_lagvar))
Game_Acc_Koy_train = Game_Acc_Koy_lagvar[trainindices,]
Game_Acc_Koy_test = Game_Acc_Koy_lagvar[-trainindices,]
str(Game_Acc_Koy_train)
names(Game_Acc_Koy_train)


## Model Bulding
KoyGame_model1 <- lm(tot_gmv~.,Game_Acc_Koy_train)
summary(KoyGame_model1)

# Model bulding evaluation with stepAIC function
KoyGame_model2 <- stepAIC(KoyGame_model1,direction = "both")
summary(KoyGame_model2)
vif(KoyGame_model2)

# Building 3rd model with all of the StepAIC model variables

KoyGame_model3<- lm(formula = tot_gmv ~ product_analytic_vertical.xJoystickGamingWheel + 
                      promotion_type.xChristmas...New.Year.Sale + product_analytic_vertical.xGamingSpeaker +
                      Digital + NPS + promotion_type.xBSD.5 + SEM + TV + product_analytic_vertical.xGamingKeyboard +
                      Sponsorship + promotion_type.xIndependence.Sale + X.Affiliates + 
                      promotion_type.xRakshabandhan.Sale + promotion_type.xDaussera.sale + 
                      product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                      product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model3)
vif(KoyGame_model3)

# Removing SEM as VIF is very high and p value is also relatively high

KoyGame_model4<- lm(formula = tot_gmv ~ product_analytic_vertical.xJoystickGamingWheel + 
                      promotion_type.xChristmas...New.Year.Sale + product_analytic_vertical.xGamingSpeaker +
                      Digital + NPS + promotion_type.xBSD.5 + TV + product_analytic_vertical.xGamingKeyboard +
                      Sponsorship + promotion_type.xIndependence.Sale + X.Affiliates + 
                      promotion_type.xRakshabandhan.Sale + promotion_type.xDaussera.sale + 
                      product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                      product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model4)
vif(KoyGame_model4)

# Removing TV as VIF is very high and p value is also relatively high

KoyGame_model5<- lm(formula = tot_gmv ~ product_analytic_vertical.xJoystickGamingWheel + 
                      promotion_type.xChristmas...New.Year.Sale + product_analytic_vertical.xGamingSpeaker +
                      Digital + NPS + promotion_type.xBSD.5 + product_analytic_vertical.xGamingKeyboard +
                      Sponsorship + promotion_type.xIndependence.Sale + X.Affiliates + 
                      promotion_type.xRakshabandhan.Sale + promotion_type.xDaussera.sale + 
                      product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                      product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model5)
vif(KoyGame_model5)

# Removing product_analytic_vertical.xJoystickGamingWheel as p value is very high

KoyGame_model6<- lm(formula = tot_gmv ~ promotion_type.xChristmas...New.Year.Sale + product_analytic_vertical.xGamingSpeaker +
                      Digital + NPS + promotion_type.xBSD.5 + product_analytic_vertical.xGamingKeyboard +
                      Sponsorship + promotion_type.xIndependence.Sale + X.Affiliates + 
                      promotion_type.xRakshabandhan.Sale + promotion_type.xDaussera.sale + 
                      product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                      product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model6)
vif(KoyGame_model6)

# Removing product_analytic_vertical.xGamingSpeaker as p value is very high 

KoyGame_model7<- lm(formula = tot_gmv ~ promotion_type.xChristmas...New.Year.Sale + 
                      Digital + NPS + promotion_type.xBSD.5 + product_analytic_vertical.xGamingKeyboard +
                      Sponsorship + promotion_type.xIndependence.Sale + X.Affiliates + 
                      promotion_type.xRakshabandhan.Sale + promotion_type.xDaussera.sale + 
                      product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                      product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model7)
vif(KoyGame_model7)

# Removing product_analytic_vertical.xGamingKeyboard as p value is high 

KoyGame_model8<- lm(formula = tot_gmv ~ promotion_type.xChristmas...New.Year.Sale + 
                      Digital + NPS + promotion_type.xBSD.5 + 
                      Sponsorship + promotion_type.xIndependence.Sale + X.Affiliates + 
                      promotion_type.xRakshabandhan.Sale + promotion_type.xDaussera.sale + 
                      product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                      product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model8)
vif(KoyGame_model8)

# Removing Digital as its vif an p value both are high 

KoyGame_model9<- lm(formula = tot_gmv ~ promotion_type.xChristmas...New.Year.Sale + 
                      NPS + promotion_type.xBSD.5 + 
                      Sponsorship + promotion_type.xIndependence.Sale + X.Affiliates + 
                      promotion_type.xRakshabandhan.Sale + promotion_type.xDaussera.sale + 
                      product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                      product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model9)
vif(KoyGame_model9)

# Removing Sponsorship and NPS as p value and vif both are high 

KoyGame_model10<- lm(formula = tot_gmv ~ promotion_type.xChristmas...New.Year.Sale + 
                       promotion_type.xBSD.5 + 
                       promotion_type.xIndependence.Sale + X.Affiliates + 
                       promotion_type.xRakshabandhan.Sale + promotion_type.xDaussera.sale + 
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                       product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model10)
vif(KoyGame_model10)

# Removing promotion_type.xChristmas...New.Year.Sale and promotion_type.xBSD.5 as p value is high 

KoyGame_model11<- lm(formula = tot_gmv ~ promotion_type.xIndependence.Sale + X.Affiliates + 
                       promotion_type.xRakshabandhan.Sale + promotion_type.xDaussera.sale + 
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                       product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model11)
vif(KoyGame_model11)

# Removing X.Affiliates as its p value is relatively high 

KoyGame_model12<- lm(formula = tot_gmv ~ promotion_type.xIndependence.Sale +
                       promotion_type.xRakshabandhan.Sale + promotion_type.xDaussera.sale + 
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                       product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model12)
vif(KoyGame_model12)

# Removing promotion_type.xRakshabandhan.Sale as its p value is relatively high 

KoyGame_model13<- lm(formula = tot_gmv ~ promotion_type.xIndependence.Sale +
                       promotion_type.xDaussera.sale + 
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                       product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model13)
vif(KoyGame_model13)

# Removing promotion_type.xIndependence.Sale as its p value is relatively high 

KoyGame_model14<- lm(formula = tot_gmv ~ promotion_type.xDaussera.sale + 
                       product_analytic_vertical.xGamingMouse + product_analytic_vertical.xGamingHeadset +
                       product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model14)
vif(KoyGame_model14)

# Removing promotion_type.xDaussera.sale as its p value is relatively high 

KoyGame_model15<- lm(formula = tot_gmv ~  product_analytic_vertical.xGamingMouse + 
                       product_analytic_vertical.xGamingHeadset +
                       product_analytic_vertical.xGamePad, data = Game_Acc_Koy_train)
summary(KoyGame_model15)
vif(KoyGame_model15)

# KoyGame_model15 is the final model with following r square and adjusted r square values:
# Multiple R-squared:  0.647,	Adjusted R-squared:  0.645 

par(mfrow = c(2,2))
plot(KoyGame_model15, main = "Final Gaming Accessory - Koyck Model")
dev.off()

# Prediction using test dataset
Game_Acc_Koy_predict <- predict(KoyGame_model15, Game_Acc_Koy_test)
RMSE(Game_Acc_Koy_test$tot_gmv,Game_Acc_Koy_predict)
Game_Acc_Koy_r <- cor(Game_Acc_Koy_test$tot_gmv, Game_Acc_Koy_predict)
Game_Acc_Koy_rsquared <- Game_Acc_Koy_r^2
Game_Acc_Koy_rsquared

# R square if test data prediction is  0.6

## Cross validation
Game_Acc_Koy_crosvald <- cv.lm(data = Game_Acc_Koy_train, form.lm = formula(KoyGame_model15),m = 10,
                               main = " Gaming Accessory Cross Validation")
attr(Game_Acc_Koy_crosvald, "ms")
# ms value for cross validation = 0.379

# --------------- Deriving elasticity ----------------------------------------------------------------
elasticity <- function(var) {
  x <- as.numeric(KoyGame_model15$coefficients[var] * mean(Game_Acc_Koy_train[,var])/mean(Game_Acc_Koy_train$tot_gmv))
  return(x)
}

KoyGame_list <- list()

for(i in 2:length(KoyGame_model15$coefficients)) {
  KoyGame_list[i-1] <- elasticity(names(KoyGame_model15$coefficients)[i])
}

elasticity_koyGame <- data.frame(names(KoyGame_model15$coefficients[2:length(KoyGame_model15$coefficients)]))
elasticity_koyGame <- cbind(elasticity_koyGame,do.call(rbind.data.frame, KoyGame_list))
colnames(elasticity_koyGame) <- c("Variable","Elasticity")

elasticity_koyGame$direction <- ifelse(elasticity_koyGame$Elasticity > 0, "Positive", "Negative")

ggplot(data=elasticity_koyGame, aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Koyck Model for Gaming Accessory") +xlab("Variables")  

############################### KOYCK MODELLING ###################################################
# ###############################3. PRODUCT SUB CATEGORY: HOME AUDIO #####################################
# --------------------------------------------------------------------------------------------------------------


str(HomeAudio)
sum(is.na(HomeAudio))
Haud_Access_Koyck <- HomeAudio

# Creating lag Variable as per requirement of Koyck model 
Haud_Access_Koyck <- slide(Haud_Access_Koyck, Var = "tot_gmv",slideBy = -1)
str(Haud_Access_Koyck)

# Omit na if any and perform scaling operation
Haud_Acc_Koy_lagvar_omit <- na.omit(Haud_Access_Koyck)
Haud_Acc_Koy_lagvar_prt1 <- data.frame(scale(Haud_Acc_Koy_lagvar_omit[,c(1:15)]))
Haud_Acc_Koy_lagvar_prt2 <- data.frame(Haud_Acc_Koy_lagvar_omit[,16:77])
Haud_Acc_Koy_lagvar_prt3 <- data.frame(scale(Haud_Acc_Koy_lagvar_omit[,78]))

# Combine above three parts into one file bacl after scaling

Haud_Acc_Koy_lagvar <- cbind(Haud_Acc_Koy_lagvar_prt1, Haud_Acc_Koy_lagvar_prt2, Haud_Acc_Koy_lagvar_prt3)
str(Haud_Acc_Koy_lagvar)

# Month and weekno columns have been removed as they aren't required
Haud_Acc_Koy_lagvar <- Haud_Acc_Koy_lagvar[,-c(1,2)]

# Divide above dataset into train & test datasets
set.seed(100)
trainindices= sample(1:nrow(Haud_Acc_Koy_lagvar), 0.6*nrow(Haud_Acc_Koy_lagvar))
Haud_Acc_Koy_train = Haud_Acc_Koy_lagvar[trainindices,]
Haud_Acc_Koy_test = Haud_Acc_Koy_lagvar[-trainindices,]
str(Haud_Acc_Koy_train)
names(Haud_Acc_Koy_train)


## Model Building
KoyHaud_model1 <- lm(tot_gmv~.,Haud_Acc_Koy_train)
summary(KoyHaud_model1)

# Model building evaluation with stepAIC function
KoyHaud_model2 <- stepAIC(KoyHaud_model1,direction = "both")
summary(KoyHaud_model2)
vif(KoyHaud_model2)

# Building 3rd model with all of the StepAIC model variables

KoyHaud_model3<- lm(formula = tot_gmv ~ promotion_type.xEid...Rathayatra.sale + 
                      product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xSoundMixer +
                      product_analytic_vertical.xDJController + Content.Marketing + SEM + 
                      product_analytic_vertical.xDockingStation + product_analytic_vertical.xDock +
                      product_analytic_vertical.xFMRadio + Sponsorship +
                      product_analytic_vertical.xHomeAudioSpeaker, data = Haud_Acc_Koy_train)
summary(KoyHaud_model3)
vif(KoyHaud_model3)

# Removing Content.Marketing as both VIF and p values are high 

KoyHaud_model4<- lm(formula = tot_gmv ~ promotion_type.xEid...Rathayatra.sale + 
                      product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xSoundMixer +
                      product_analytic_vertical.xDJController + SEM + 
                      product_analytic_vertical.xDockingStation + product_analytic_vertical.xDock +
                      product_analytic_vertical.xFMRadio + Sponsorship +
                      product_analytic_vertical.xHomeAudioSpeaker, data = Haud_Acc_Koy_train)
summary(KoyHaud_model4)
vif(KoyHaud_model4)

# Removing SEM as both VIF and p values are high 

KoyHaud_model5<- lm(formula = tot_gmv ~ promotion_type.xEid...Rathayatra.sale + 
                      product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xSoundMixer +
                      product_analytic_vertical.xDJController + 
                      product_analytic_vertical.xDockingStation + product_analytic_vertical.xDock +
                      product_analytic_vertical.xFMRadio + Sponsorship +
                      product_analytic_vertical.xHomeAudioSpeaker, data = Haud_Acc_Koy_train)
summary(KoyHaud_model5)
vif(KoyHaud_model5)

# Removing promotion_type.xEid...Rathayatra.sale as p value are high 

KoyHaud_model6<- lm(formula = tot_gmv ~ product_analytic_vertical.xHiFiSystem + product_analytic_vertical.xSoundMixer +
                      product_analytic_vertical.xDJController + 
                      product_analytic_vertical.xDockingStation + product_analytic_vertical.xDock +
                      product_analytic_vertical.xFMRadio + Sponsorship +
                      product_analytic_vertical.xHomeAudioSpeaker, data = Haud_Acc_Koy_train)
summary(KoyHaud_model6)
vif(KoyHaud_model6)

# Removing product_analytic_vertical.xHiFiSystem and product_analytic_vertical.xSoundMixer as they have high 
# p values 

KoyHaud_model7<- lm(formula = tot_gmv ~ product_analytic_vertical.xDJController + 
                      product_analytic_vertical.xDockingStation + product_analytic_vertical.xDock +
                      product_analytic_vertical.xFMRadio + Sponsorship +
                      product_analytic_vertical.xHomeAudioSpeaker, data = Haud_Acc_Koy_train)
summary(KoyHaud_model7)
vif(KoyHaud_model7)

# Removing product_analytic_vertical.xDJController as p value is high 

KoyHaud_model8<- lm(formula = tot_gmv ~ product_analytic_vertical.xDockingStation + 
                      product_analytic_vertical.xDock +
                      product_analytic_vertical.xFMRadio + Sponsorship +
                      product_analytic_vertical.xHomeAudioSpeaker, data = Haud_Acc_Koy_train)
summary(KoyHaud_model8)
vif(KoyHaud_model8)

# Removing product_analytic_vertical.xDockingStation and product_analytic_vertical.xDock
# as p values are very high 

KoyHaud_model9<- lm(formula = tot_gmv ~ product_analytic_vertical.xFMRadio + Sponsorship +
                      product_analytic_vertical.xHomeAudioSpeaker, data = Haud_Acc_Koy_train)
summary(KoyHaud_model9)
vif(KoyHaud_model9)

# Removing Sponsorship as p value is high 

KoyHaud_model10 <- lm(formula = tot_gmv ~ product_analytic_vertical.xFMRadio + 
                        product_analytic_vertical.xHomeAudioSpeaker, data = Haud_Acc_Koy_train)
summary(KoyHaud_model10)
vif(KoyHaud_model10)

# Hence, KoyHaud_model10 is final model with following values:
# Multiple R-squared:  0.846,	Adjusted R-squared:  0.845

# Prediction using test dataset
Haud_Acc_Koy_predict <- predict(KoyHaud_model10, Haud_Acc_Koy_test)
RMSE(Haud_Acc_Koy_test$tot_gmv,Haud_Acc_Koy_predict)
Haud_Acc_Koy_r <- cor(Haud_Acc_Koy_test$tot_gmv, Haud_Acc_Koy_predict)
Haud_Acc_Koy_rsquared <- Haud_Acc_Koy_r^2
Haud_Acc_Koy_rsquared

# R square if test data prediction is  0.843

## Cross validation
Haud_Acc_Koy_crosvald <- cv.lm(data = Haud_Acc_Koy_train, form.lm = formula(KoyHaud_model10),m = 10,
                               main = " Home Audio Cross Validation")
attr(Haud_Acc_Koy_crosvald, "ms")
# ms value for cross validation = 0.162

# --------------- Deriving elasticity ----------------------------------------------------------------
elasticity <- function(var) {
  x <- as.numeric(KoyHaud_model10$coefficients[var] * mean(Haud_Acc_Koy_train[,var])/mean(Haud_Acc_Koy_train$tot_gmv))
  return(x)
}

KoyHaud_list <- list()

for(i in 2:length(KoyHaud_model10$coefficients)) {
  KoyHaud_list[i-1] <- elasticity(names(KoyHaud_model10$coefficients)[i])
}

elasticity_koyHaud <- data.frame(names(KoyHaud_model10$coefficients[2:length(KoyHaud_model10$coefficients)]))
elasticity_koyHaud <- cbind(elasticity_koyHaud,do.call(rbind.data.frame, KoyHaud_list))
elasticity_koyHaud
colnames(elasticity_koyHaud) <- c("Variable","Elasticity")

elasticity_koyHaud$direction <- ifelse(elasticity_koyHaud$Elasticity > 0, "Positive", "Negative")

ggplot(data=elasticity_koyHaud, aes(x=reorder(Variable,Elasticity),y=Elasticity)) +
  geom_bar(position="dodge",stat="identity") + 
  coord_flip() +
  ggtitle("Koyck Model for Home Audio") +xlab("Variables")  


########################################END OF CODE#################################
