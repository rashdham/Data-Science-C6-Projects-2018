library(ggplot2)
library(ggthemes)
library(dplyr)
library(scales)
library(RH2)


# This is our master frame and will be used throughout the analysis
loan<-read.csv("loan.csv",stringsAsFactors = F, na.strings=c("", " ", "NA", "N/A"))
View(loan)

# View the structure, head and tail of the dataset

str(loan)
head (loan)
tail(loan)

##########################################################################################

# Data Frame cleaning goes here


# Get rid of all columns having only 1 unique value

loan <- loan[vapply(loan, function(x) length(unique(x)) > 1, logical(1L))]
View(loan)

# URL column is not needed without a login/ passwd, remove url column

loan <- subset(loan, select = -c(url) )
View(loan)

# We are not going to do any kind of text analysis so getting rid of the desc column and we will not lose any important information by removing this column

loan <- subset(loan, select = -c(desc)) 
View(loan)

# The following columns contain only 0, NA. If we impute NA to 0, they boil down to
# columns having only 1 value = 0. So get rid of them as they fail to provide any value

# collections_12_mths_ex_med,
# chargeoff_within_12_mths,
# tax_liens

loan <- subset(loan, select = -c(collections_12_mths_ex_med, chargeoff_within_12_mths, tax_liens) )
View(loan)

# We can get rid of member_id as we can clearly see that all loans are individual loans
# and so just the loan Id will suffice. Lets get rid of the redundant member_id as there is a 1 - 1
# mapping from loan Id to member Id

loan <- subset(loan, select = -c(member_id))
View(loan)


# Let us find out which columns are non-numeric

num_data <- data.frame(data.matrix(loan))
numeric_columns <- sapply(num_data,function(x){mean(as.numeric(is.na(x)))<0.5})
warnings()
rm(num_data)


# Convert all non-numeric columns to upper

loan[,!numeric_columns] <- mutate_all(loan[,!numeric_columns], funs(toupper))
rm(numeric_columns)
View(loan)


# Employer Name Cleaning based on discrepencies seen in manual shifting

loan$emp_title <- gsub(" AND ", "&", loan$emp_title)
loan$emp_title <- gsub("LLC", "", loan$emp_title)
loan$emp_title <- gsub("LLP", "", loan$emp_title)
loan$emp_title <- gsub("INC", "", loan$emp_title)
loan$emp_title <- gsub("\\UNITED STATES", "US", loan$emp_title)

loan$emp_title <- gsub("\\.", "", loan$emp_title)
loan$emp_title <- gsub("\\,", "", loan$emp_title)
loan$emp_title <- gsub("\\'", "", loan$emp_title)
loan$emp_title <- gsub("\\:", "", loan$emp_title)
loan$emp_title <- gsub("\\-", "", loan$emp_title)
loan$emp_title <- gsub("\\)", "", loan$emp_title)
loan$emp_title <- gsub("\\(", "", loan$emp_title)
loan$emp_title <- gsub("\\(", "", loan$emp_title)

loan$emp_title <- gsub("[[:space:]]", "", loan$emp_title)

loan$emp_title[which(loan$emp_title == "USAIRFORCE")] <- "USAF"
loan$emp_title[which(loan$emp_title == "USARMY")] <- "ARMY"
loan$emp_title[which(loan$emp_title == "USNAVY")] <- "NAVY"
loan$emp_title[which(loan$emp_title == "USPOSTALSERVICE")] <- "USPS"
loan$emp_title[which(loan$emp_title == "UNITEDPARCELSERVICE")] <- "UPS"
loan$emp_title[which(loan$emp_title == "VERIZONWIRELESS")] <- "VERIZON"
loan$emp_title[which(loan$emp_title == "SELFEMPLOYED")] <- "SELF"
loan$emp_title[which(loan$emp_title == "THEHOMEDEPOT")] <- "HOMEDEPOT"
View(loan)

# Convert columns containing % to numeric

loan$int_rate <- as.numeric(gsub("%", "", loan$int_rate))
loan$revol_util <- as.numeric(gsub("%", "", loan$revol_util))
View(loan)

# On understanding the loan grade system, it was found that loan grade or grade column determines the 
# interest rate. Which means we already have nicely categorized loan rate of interest
# based on loan grades. Therefore we may get rid of the int_rate column as well

loan <- subset(loan, select = -c(int_rate) )
View(loan)


# Order the data frame so we can read and understand the data dictionary in its order

loan <- loan[c(sort(colnames(loan)))]
View(loan)


# Data Frame cleaning ends here
write.csv(loan, file = "cleanLoan.csv")

##############################################################################
##############################################################################

#Created subset for further analysis whever required

chargedoffloan<-loan[which(toupper(loan$loan_status) == "CHARGED OFF"), ]
View(chargedoffloan)
write.csv(chargedoffloan, file = "chargedoffloan.csv")

fullypaidloan<-loan[-which(toupper(loan$loan_status) == "CHARGED OFF"), ]
View(fullypaidloan)
write.csv(fullypaidloan, file = "fullypaidloan.csv")

################################################################################
################################################################################

# uni-variate analysis starts here

#
# Open Account
#
boxplot(loan$open_acc, horizontal = TRUE, axes = FALSE, staplewex = 1)
text(x = boxplot.stats(loan$open_acc)$stats, labels = boxplot.stats(loan$open_acc)$stats, y = 1.25)
summary(loan$open_acc)
ggplot(loan, aes(x=loan$open_acc)) + geom_bar(stat = "count") + xlab("Open Accounts") + ylab("Count") + ggtitle("Histogram of Open Accounts")



#
# Address state analysis for charged off loans in each state
#
ggplot(loan, aes(reorder(addr_state, -table(addr_state)[addr_state]))) + geom_bar(stat = "count") + scale_y_continuous(trans='log2') + geom_text(stat='count',aes(label=..count..),vjust=-0.5)+ xlab("State as per the Address") + ylab("Count of Applicants in each State") + ggtitle("Applicants on the basis of States ")


#
# Home ownership univariate analysis
# Maximum defaulters are the once who live on rent

ggplot(loan, aes(reorder(home_ownership, -table(home_ownership)[home_ownership]))) + geom_bar(stat="count") + scale_y_continuous(trans='log2') + geom_text(stat='count',aes(label=..count..),vjust=-0.5)+ xlab("Home Ownership")+ylab("Applicants Count") + ggtitle("Home Ownership of the Applicants") 

tmp1 <- count(chargedoffloan, home_ownership)
tmp1$home_ownership <- paste( tmp1$home_ownership, ": ", percent(tmp1$n/sum(tmp1$n)))
bp <- ggplot(tmp1, aes(x="", y=tmp1$n, fill=home_ownership)) + geom_bar(width = 1,stat = "identity") 
bp+ coord_polar("y", start=0) + ggtitle("Home Ownership of the Applicants") 
rm(bp)
rm(tmp1)


#
# Check Verification status
# We should ensure the a systme is put in place for source verification
ggplot(loan, aes(reorder(verification_status, -table(verification_status)[verification_status]))) + geom_bar(stat="count") +geom_text(stat='count',aes(label=..count..),vjust=-0.5)+xlab("Verification Status of Applicant ")+ ylab("Applicants Count")+ ggtitle("Verification Status of Applicant's Income")



#
# Employee title and length analysis

tmp <- loan[loan$emp_length != "N/A", ]
tmp$emp_length <- gsub("< 1 YEAR", "0 YEARS", tmp$emp_length)
tmp$emp_length <- gsub("10\\+ YEARS", "BEYOND 10 YEARS", tmp$emp_length)
ggplot(data = tmp, aes(emp_length, fill= loan_status)) + geom_bar(stat = "count") + geom_text(stat='count',aes(label = ..count..), position = position_stack (vjust = 0.5))  +  xlab("Number of Years") + ylab("Applicants") + ggtitle("No of Years for which the Applicants are employed") + scale_y_continuous(trans='log2')
rm(tmp)


#
# Earliest Credit Line Analysis
# Time starts from 1970-01-01, since our dates are before that, we have a problem
# so, lets not use the Date format, instead make our own Year format and see the 

#
t1 <- loan # make a copy
t1$yr <- as.numeric(substr(loan$earliest_cr_line, 5, 6)) #extract the year 
t1$yr <- ifelse(t1$yr >20 & t1$yr <=99, t1$yr+1900, t1$yr+2000) #add 1900 or 2000
t2 <- group_by(t1, yr) # group by yr
t2 <- summarise(t2, cnt = length(yr)) # get no of instances

ggplot(t2, aes(x=t2$yr, y=t2$cnt)) + geom_bar(stat = "identity") + geom_text(aes(label=t2$cnt),vjust=-0.5) +xlab("Inquries") + ylab("No. of Inquiries") + ggtitle("Freq of Inquiries in last 6 months") 

rm(t1)
rm(t2)

#
# Loan Issue Date Analysis
#
t1 <- loan # make a copy
t1$yr <- as.numeric(substr(loan$issue_d, 5, 6)) #extract the year 
t1$yr <- ifelse(t1$yr >20 & t1$yr <=99, t1$yr+1900, t1$yr+2000) #add 1900 or 2000
t2 <- group_by(t1, yr) # group by yr
t2 <- summarise(t2, cnt = length(yr)) # get no of instances
ggplot(t2, aes(x=t2$yr, y=t2$cnt)) + geom_bar(stat = "identity") + geom_text(aes(label=t2$cnt),vjust=-0.5) +xlab("Years") + ylab("Count") + ggtitle("Freq of Issued Loans binned by Year") 

summary(t2)

rm(t1)
rm(t2)

#
# Last Credit Pull Date Analysis
#
t1 <- loan # make a copy
t1$yr <- as.numeric(substr(loan$last_credit_pull_d, 5, 6)) #extract the year 
t1$yr <- ifelse(t1$yr >20 & t1$yr <=99, t1$yr+1900, t1$yr+2000) #add 1900 or 2000
t2 <- group_by(t1, yr) # group by yr
t2 <- summarise(t2, cnt = length(yr)) # get no of instances

ggplot(t2, aes(x=t2$yr, y=t2$cnt)) + geom_bar(stat = "identity") + geom_text(aes(label=t2$cnt),vjust=-0.5) +xlab("Years") + ylab("Count") + ggtitle("Freq of Last Credit Pulls binned by Year") 
# Warning for 2 rows are validate becuase credit_pull column is blank for 2 rows.

summary(t2)

rm(t1)
rm(t2)



#
# Funded Amount & Funded Amount invested 
#
nrow(loan[loan$funded_amnt == loan$funded_amnt_inv, ])
boxplot(loan$funded_amnt, horizontal = TRUE, axes = FALSE, staplewex = 1)
text(x = boxplot.stats(loan$funded_amnt)$stats, labels = boxplot.stats(loan$funded_amnt)$stats, y = 1.25)
summary(loan$funded_amnt)
boxplot(loan$funded_amnt_inv,horizontal = TRUE, axes = FALSE, staplewex = 1)
text(x = boxplot.stats(loan$funded_amnt_inv)$stats, labels = boxplot.stats(loan$funded_amnt_inv)$stats, y = 1.25)
summary(loan$funded_amnt_inv)


#
# DTI Ratio Analysis
#
boxplot(loan$dti, horizontal = TRUE, axes = FALSE, staplewex = 1)
text(x = boxplot.stats(loan$dti)$stats, labels = boxplot.stats(loan$dti)$stats, y = 1.25)
summary(loan$dti)

####################################################################################
####################################################################################

# Analysis on DEFAULTERS
# Grade & Sub-Grade
# Maximum loans are defaulted for B Grade interest rates
ggplot(data = chargedoffloan, aes(grade)) + geom_bar(stat="count")+ geom_text(stat='count',aes(label=..count..),position=position_dodge(width=0.9), vjust=-.5) + xlab("Grade") + ylab("Count of Applicants") + ggtitle("No of Applicants in each Grade") + geom_smooth(aes(y=..count..,group = 1),stat="count",color="blue",size=1.2)
ggplot(data = chargedoffloan, aes(sub_grade, fill = grade)) + geom_bar(stat="count") +geom_text(stat='count',aes(label=..count..),position=position_dodge(width=0.9),vjust=-0.25)+ xlab("Sub Grade") + ylab("Count of Applicants") + ggtitle("No of Applicants in each Sub Grade") + theme_bw() + geom_smooth(aes(y=..count..,group = 1),stat="count",color="red",size=1.2)



# Army personals are the maximum defaulter
emp_frame <- count(chargedoffloan, emp_title)
emp_frame <- emp_frame[ -which(is.na(emp_frame$emp_title)), ]
emp_frame <- head(arrange(emp_frame, desc(n)), 10)
ggplot(data = emp_frame, aes(reorder(emp_title, -n), n)) + geom_bar(stat="identity") + geom_text(aes(label=n),vjust=-0.5) +xlab("Employee Title") + ylab("Count of Applicants") + ggtitle("Companies in which the Applicants are working")
rm(emp_frame)



#
# What percentage of rows in loan df have a non zero value? 
#
nrow(loan[loan$collection_recovery_fee != 0, ])
nrow(loan)

#
# What percentage of rows in chargedoffloan df have a non zero value? 
#
nrow(chargedoffloan[chargedoffloan$collection_recovery_fee != 0, ])
nrow(chargedoffloan)

#
# What percentage of rows in fullypaidloan df have a non zero value? 
#
nrow(fullypaidloan[fullypaidloan$collection_recovery_fee != 0, ])
nrow(fullypaidloan)




#
# What percentage of rows in loan df have a non zero value? 
#
nrow(loan[loan$delinq_2yrs != 0, ])
nrow(loan)

#
# What percentage of rows in chargedoffloan df have a non zero value? 
#
nrow(chargedoffloan[chargedoffloan$delinq_2yrs != 0, ])
nrow(chargedoffloan)

#
# What percentage of rows in fullypaidloan df have a non zero value? 
#
nrow(fullypaidloan[fullypaidloan$delinq_2yrs != 0, ])
nrow(fullypaidloan)

#######################################################################################
#######################################################################################

#
# bi-variate for home ownership
#

ggplot(loan, aes(x= loan_status,  group=home_ownership)) + 
  geom_bar(aes(y = ..prop.., fill = factor(..x..)), stat="count") +
  geom_text(aes( label = scales::percent(..prop..),
                 y= ..prop.. ), stat= "count", vjust = -.5) +
  labs(y = "Percent", fill="Loan Status") +
  facet_grid(~home_ownership) +
  scale_y_continuous(labels = scales::percent)


#
# bi-variate for Purpose
#

ggplot(loan, aes(x= loan_status,  group=purpose)) + 
  geom_bar(aes(y = ..prop.., fill = factor(..x..)), stat="count") +
  geom_text(aes( label = scales::percent(..prop..),
                 y= ..prop.. ), stat= "count", vjust = -.5) +
  labs(y = "Percent", fill="Status") +
  facet_grid(~purpose) +
  scale_y_continuous(labels = scales::percent)+
  scale_x_discrete (labels = c("COF", "CRR", "FLP"))

#
# Check loan purpose
#
ggplot(loan, aes(purpose,  fill = loan_status)) + geom_bar() +scale_x_discrete(labels = abbreviate)+ xlab("Purpose given by applicant") + ylab("Count of Applicants") +ggtitle("Reasons for which the Loan was taken")


#
# bi-variate for Grade
#

ggplot(loan[loan$emp_length != "N/A",], aes(x= loan_status,  group=grade)) + 
  geom_bar(aes(y = ..prop.., fill = factor(..x..)), stat="count") +
  geom_text(aes( label = scales::percent(..prop..),
                 y= ..prop.. ), stat= "count", vjust = -.5) +
  labs(y = "Percent", fill="Status") +
  facet_grid(~grade) +
  scale_y_continuous(labels = scales::percent)+
  scale_x_discrete(labels = c("COF", "CRR", "FLP"))


#
# bi-variate for Emp_length
#

ggplot(loan[loan$emp_length != "N/A",], aes(x= loan_status,  group=emp_length)) + 
  geom_bar(aes(y = ..prop.., fill = factor(..x..)), stat="count") +
  geom_text(aes( label = scales::percent(..prop..),
                 y= ..prop.. ), stat= "count", vjust = -.5) +
  labs(y = "Percent", fill="Status") +
  facet_grid(~emp_length) +
  scale_y_continuous(labels = scales::percent)+
  scale_x_discrete(labels = c("COF", "CRR", "FLP"))

#
# bi-variate for Verification
#

ggplot(loan, aes(x= loan_status,  group=verification_status)) + 
  geom_bar(aes(y = ..prop.., fill = factor(..x..)), stat="count") +
  geom_text(aes( label = scales::percent(..prop..),
                 y= ..prop.. ), stat= "count", vjust = -.5) +
  labs(y = "Percent", fill="Status") +
  facet_grid(~verification_status) +
  scale_y_continuous(labels = scales::percent)+
  scale_x_discrete(labels = c("COF", "CRR", "FLP"))


#
# bi-variate for emp_title
#

emp_frame <- count(loan, emp_title)
emp_frame <- emp_frame[ -which(is.na(emp_frame$emp_title)), ]
emp_frame <- head(arrange(emp_frame, desc(n)), 10)

tmp <- loan
tmp1 <- tmp[which(tmp$emp_title %in% emp_frame$emp_title), ]

ggplot(tmp1, aes(x= loan_status,  group=emp_title)) + 
  geom_bar(aes(y = ..prop.., fill = factor(..x..)), stat="count") +
  geom_text(aes( label = scales::percent(..prop..),
                 y= ..prop.. ), stat= "count", vjust = -.5) +
  labs(y = "Percent", fill="Status") +
  facet_grid(~emp_title) +
  scale_y_continuous(labels = scales::percent)+
  scale_x_discrete(labels= c("OF", "CRR", "FLP"))

rm(emp_frame)
rm(tmp)
rm(tmp1)


#
# bi-variate for Address State
#
ggplot(loan, aes(x=loan$addr_state, y = (..count..)/sum(..count..), fill=factor(loan_status))) + geom_bar(position="fill") + scale_y_continuous(labels = percent) + xlab("Address State") + ylab("Applicants  Percentage")+ ggtitle("Status of Loan on basis of State") 


####################################################################################################
####################################################################################################

#
# Scatter plot for multivariate 
#
ggplot(loan, aes(x = loan_amnt, y = purpose, col = loan_status )) + geom_point( alpha = 0.5 ) + geom_jitter()

# Analysis of loan status for purpose type - Debt Consolidation
# as we could not infere from scatter plot above

debt_conl <-loan[which(loan$purpose == "DEBT_CONSOLIDATION"), ]
ggplot(debt_conl, aes(x = loan_status, y = (..count..),fill=loan_status)) + geom_bar(stat = "count") + geom_text(stat='count',aes(label=..count..),vjust=-0.5) + ggtitle("Count of loan status for purpose DEBT_CONSOLIDATION")


#Function to calculate median and quantiles based on loan status

Loan_Status_Summary <- function(x){
  print("FULLY PAID")
  print(summary(loan[which(loan$loan_status == "FULLY PAID"),x]))
  print("CHARGED OFF")
  print(summary(loan[which(loan$loan_status == "CHARGED OFF"),x]))
  print("CURRENT")
  print(summary(loan[which(loan$loan_status == "CURRENT"),x]))
}


#Replacing Outliers
qnt <- quantile(loan$annual_inc, probs=c(.25, .75), na.rm = T)
caps <- quantile(loan$annual_inc, probs=c(.05, .95), na.rm = T)
H <- 1.5 * IQR(loan$annual_inc, na.rm = T)
loan$annual_inc[loan$annual_inc < (qnt[1] - H)] <- caps[1]
loan$annual_inc[loan$annual_inc > (qnt[2] + H)] <- caps[2]

Loan_Status_Summary("annual_inc")


loan %>%
  ggplot(aes(y=annual_inc)) +
  geom_boxplot(aes(x=loan_status),width=0.6)+
  stat_summary(geom="text", fun.y=quantile,aes(x=loan_status,label=sprintf("%1.1f", ..y..)),position=position_nudge(x=0.2), size=3.5,vjust = -0.5)



#revol_util : percentage utilization of revolving balance
#higher the utilization of revolving balance, the borrower tends to default much more
Loan_Status_Summary("revol_util")

loan %>%
  ggplot(aes(y=revol_util)) +
  geom_boxplot(aes(x=loan_status),width=0.6)+
  stat_summary(geom="text", fun.y=quantile,aes(x=loan_status,label=sprintf("%1.1f", ..y..)),position=position_nudge(x=0.2), size=3.5,vjust = -0.5)


# Loan status based on monthly debt to income ratio. Higher dti means higher debt than income 
# Loan funded with higher dti have more chances to default. Both median and mean loan amount is high for defaulted loans.
Loan_Status_Summary("dti")

loan %>%
  ggplot(aes(y=dti)) +
  geom_boxplot(aes(x=loan_status),width=0.6)+
  stat_summary(geom="text", fun.y=quantile,aes(x=loan_status,label=sprintf("%1.1f", ..y..)),position=position_nudge(x=0.2), size=3.5,vjust = -0.5)


# Correlation among variables

continuous_vars <- loan[,c("loan_amnt","funded_amnt","installment","annual_inc","dti","inq_last_6mths","open_acc","pub_rec","revol_bal","total_acc","total_pymnt","total_rec_prncp")]

cormat <- round(cor(continuous_vars),2)

get_lower_tri<-function(cormat){
  cormat[upper.tri(cormat)] <- NA
  return(cormat)
}
# Get upper triangle of the correlation matrix
get_upper_tri <- function(cormat){
  cormat[lower.tri(cormat)]<- NA
  return(cormat)
}

upper_tri <- get_upper_tri(cormat)

reorder_cormat <- function(cormat){
  # Use correlation between variables as distance
  dd <- as.dist((1-cormat)/2)
  hc <- hclust(dd)
  cormat <-cormat[hc$order, hc$order]
}

library(reshape2)
cormat <- reorder_cormat(cormat)

upper_tri <- get_upper_tri(cormat)

melted_cormat <- melt(upper_tri, na.rm = TRUE)

ggplot(melted_cormat, aes(Var2, Var1, fill = value))+
  geom_tile(color = "white")+
  scale_fill_gradient2(low = "red", high = "green", mid = "white", 
                       midpoint = 0, limit = c(-1,1), space = "Lab") +
  theme_minimal()+ 
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                   size = 12, hjust = 1))+
  coord_fixed()+
  geom_text(aes(Var2, Var1, label = value), color = "black", size = 4) +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    panel.grid.major = element_blank(),
    panel.border = element_blank(),
    panel.background = element_blank(),
    axis.ticks = element_blank(),
    legend.justification = c(1, 0),
    legend.position = c(0.6, 0.7),
    legend.direction = "horizontal")+
  guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                               title.position = "top", title.hjust = 0.5))

#########################################################################################
#########################################################################################
